import numpy as np
import aux_funcs
from skimage import color
from skimage import io
from skimage.transform import resize
import logging
import time

def th_construct_image(name, param_dict):


    logging.info("Thread %s: starting", name)
    time.sleep(2)

    # these values can't be changed

    D_lens = param_dict['D_lens']  # aperture size
    focal_length = param_dict['focal_length']  # focal length
    du = param_dict['du']
    wvl1 = param_dict['wvl1']  # wavelength #1
    ma_size = param_dict['ma_size']  # meta atom size

    fnum = focal_length / D_lens  # F-number

    ma_num = int(D_lens / ma_size)  # meta atoms per cross-section of aperture
    ma_num_r = int(0.5 * D_lens / ma_size)  # meta atoms per cross-section of half-aperture

    # let's select pixel size in sensor plane - we try to make it a least several time smaller than wavelengths under study

    size1 = ma_num * wvl1 * fnum  # size in sensor plane for wavelength #1 - such size is selected in order to maintain aperture size equal to amount of meta atoms
    num_pix1 = int(size1 / du)  # amount of pixels in sensor plane
    apert_pix1 = int(size1 / (wvl1 * fnum))  # we demonstrate that aperture size in pixels is equal to meta atoms amount

    print(
        f'for the wavelength {1e6 * wvl1:.1f} um aperture size is equal to {apert_pix1} meta atoms with image plane size {num_pix1}x{num_pix1} pixels')

    param_dict_meta_1 = {'wvl': wvl1, 'D_lens': D_lens, 'focal_length': focal_length, 'du': du, 'size': size1}

    # laod transmittance / optical phase difference data

    trans_d = []
    phase_d = []
    with open('data/trans_1.txt') as file1:
        for i in file1.readlines():
            trans_d.append(float(i))

    transmittance = aux_funcs.get_2d_rotated(trans_d, num_pix1)  # 2D distribution of transmittance
    param_dict_meta_1['transmittance'] = transmittance

    with open('data/phase_1.txt') as file1:
        for i in file1.readlines():
            phase_d.append(float(i))

    phase_d = [i + np.pi for i in phase_d]
    phase_difference = [wvl1 * i/(2*np.pi) for i in phase_d]                                  # phase difference between ideal one (related to aberration-free case) and simulated one
    phase_difference = np.asarray(phase_difference)

    phase_difference = aux_funcs.get_2d_rotated(phase_difference, num_pix1)
    Wa1_r, Ha1_r, PSF1_r, u1_r, fu1_x_r  = aux_funcs.get_normalized_psf(param_dict_meta_1, phase_difference)             # wavefront, coherent transfer function (CTF), PSF, coordinates in image plane, coordinates in aperture plane in reciprocal space

    image = color.rgb2gray(io.imread('data/scene.png'))                           # grayscaling loaded image
    im1 = resize(image, (num_pix1, num_pix1))                                       # resizing image
    Ig1 = (im1/(np.max(im1))).astype(np.float32)                                  # normalizing image

    PSF1_r = PSF1_r.astype(np.float32)
    z1_r = np.fft.irfft2(np.fft.rfft2(Ig1) * np.fft.rfft2(PSF1_r, Ig1.shape))     # convolution
    z1_r = np.fft.fftshift(z1_r)                                                  # shifting

    param_dict.update({'Ha1_r':Ha1_r, 'PSF1_r':PSF1_r, 'u1_r':u1_r, 'z1_r':z1_r, 'ma_num_r':ma_num_r})
    logging.info("Thread %s: finishing", name)
    return None