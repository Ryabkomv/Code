
param_dict = {'k':1.38e-23,              # Boltzmann constant':,
              'c1': 3.742e8,             # c1 coefficient for black body radiation calculation
              'c2': 1.439e4,             # c2 coefficient for black body radiation calculation
              'c3': 1.884e27,            # c3 coefficient for black body radiation calculation

               'lambda_start': 8,        # wavelength #1 in wavelength range (in um)
               'lambda_r': 12,           # wavelength #2 in wavelength range (in um)

               'D_lens': 1.92e-3,        # input apeture size - metalens diameter
               'focal_length': 2e-3,     # focal distance
               'G': 3.7e-8,              # total thermal conductance
               'TCR': 0.025,             # temperature coeffcienct of resistance
               'w': 30,                  # IR modulation frequency
               'C': 1e-10,               # thermal capacitance of a single pixel
               'fi': 20,                 # imaging frame rate
               'fs': 1.66e-2,            # shutter frequency - uniformity correction frequency
               'T1': 300,                # detector temperature
               'xl': 32,                 # amount of lines
               'xc': 32,                 # amount of columns
               'Rbol': 1e6,              # pixel resistivity
               'Rroic': 1e6,             # input impedance of the ROIC
               'pixel_size': 12e-6,      # pixel side

               'wvl1':8e-6,              # the 1st wavelength for test image reconstruction
               'du': 1e-6,               # decreased pixel size for reconstruction purposes
               'ma_size': 8e-6,          # meta atom size

               'beta': 0.7,              # pixel fill-factor
               'phi': 0.8,               # optics transmission
               'eps': 0.9,               # infrared absorption rate of the bolometer membrane

               'tiN' : {'cp': 600, 'rho': 5440, 't': 3e-8, 'G':29},
               'aSi': {'cp': 678, 'rho': 2320, 't': 1e-7, 'G':3},
               'SiO2': {'cp': 730, 'rho': 2200, 't': 1e-7, 'G':1.4,
                        't_30':1e-6, 't_diel':0.15e-6, 'post_s':1.8e-12, 'layer_s':121e-12, 'layer_fill':0.9},

               'Vq': 2e-6,
               'Vamp': 0.8e-6,
               'Iroic': 8e-11,
               'K_val': 4e-12,           # 1/f noise constant dimensionless
               'Vbias': 1.5,             # SAIT DR
               'gamma': 1.25,
               'freq_req': 30,

               'Nadc': 16,  # ADC resolution [bits]
               'Vref': 1.5  # ADC reference voltage (assuming equal to Vbias) [V]
               }
