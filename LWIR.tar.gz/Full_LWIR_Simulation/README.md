# Full_LWIR_Simulation
The project performs LWIR simulation by running consecutively several scripts describing different parameters of the LWIR. The order is the next one - **metalens simulation, image construction, absorber simulation and NETD calculation**. The steps share a same set of the system's parameters which are updated after completion of each step of the full simulation process. Currently one process - metalens simulation is not fully operational and is available from the separate repositories being developed now. Metalens simulation part currently runs a random MEEP script for testing purposes. This script will be replaced with an actual one later.

# Packages required

> **See also:** [Clean installation on Ubuntu Desktop 22.04.2 LTS](#clean-installation-on-ubuntu-desktop-22042-lts)

> **Note:** You can use [Docker](#running-the-simulation-inside-docker-container) to install all requirements automatically inside clean Linux environment.

## Main

To use **main_module.py in Linux/WSL environment** MEEP solver required (see [Meep installation manual](https://meep.readthedocs.io/en/latest/Installation/)). To use it in **Windows** COMSOL installation required.

MEEP solver or COMSOL selected automatically depending on environment used.

Also `python3-tk` and `scikit-image` packages required:

    apt install python3-tk
    pip install scikit-image

## ROIC noise simulation
To perform ROIC noise simulation using SPICE install `PyLTSpice` package:

    pip config set global.proxy http://proxy.rnd.samsung.ru:8080
    pip install PyLTSpice

Also you have [LTspice XVII](https://www.analog.com/en/design-center/design-tools-and-calculators/ltspice-simulator.html) software to be installed. To run the simulation under Linux, install LTSpice under `wine`:

> **Note:** WSL2 required to run installation on Windows Subsystem for Linux because of both 32- and 64-bit `wine` packages usage.

    dpkg --add-architecture i386
    apt update
    apt install wine wine32

Then download [LTspice](https://www.analog.com/en/design-center/design-tools-and-calculators/ltspice-simulator.html) and run:

    wine msiexec /package LTspice64.msi /quiet

To check the LTspice installation under `wine`, run:

    wine ~/.wine/drive_c/Program\ Files/ADI/LTspice/LTspice.exe

If the software installed properly, LTSpice GUI should appear:
![LTspice XVII GUI](img/LTspice_GUI.png)

Then close the window and run the simulation.

# Before using
The `P_out_slit1.7z` file in `data_comsol` folder should be unpacked first (original file size is more than 200 Mb).

# Troubleshooting
For correct use of `test_study.mph` COMSOL model may be needed to start it with COMSOL application and manually set paths to the files describing material layers (`import_Al.txt`, `import_TiN.txt` etc.)

# Running the simulation inside Docker container

**Docker** container provides clean environment with all software dependencies required to run the simulation. You can use Docker installed on `chip` server `(106.109.8.88)`in SRR.

> **Note 1:** Currently this method to run the simulation supported in **Linux** only.
>
> **Note 2:** If SRR proxy usage is not required (e. g. behind the SVPN) please comment out or remove following lines in `Dockerfile`:
>
>       ENV http_proxy "http://proxy.rnd.samsung.ru:8080"
>       ENV https_proxy "http://proxy.rnd.samsung.ru:8080"
> **Note 3:** `Europe/Moscow` timezone is hardcoded inside the `Dockerfile` so if your timezone is different please change it in following `Dockerfile` line:
>
>       RUN DEBIAN_FRONTEND=noninteractive TZ=Europe/Moscow apt-get -y install tzdata
> (Use `TZ identifier` column from [this table](https://en.wikipedia.org/wiki/List_of_tz_database_time_zones#List))

1. Allow `X11` server connection:

        xhost +local:*

2. Build the Docker Image running the following command:

        docker build -t lwir-container .

3. Run the container:

        sudo docker run -it -e DISPLAY=$DISPLAY -v /tmp/.X11-unix/:/tmp/.X11-unix/ lwir-container

4. Then you will see the simulation process and results. When simulation will be completed, you can use `bash` command line for debugging. To stop the container, enter the `exit` command.

# Clean installation on Ubuntu Desktop 22.04.2 LTS

> **Note.** If `gnome-terminal` fails to start, add the following line to the end of `/etc/default/locale` file and reboot the system:

    LC_ALL="en_US.UTF-8"

## Root section
    $ su -

### Proxy setup
    # echo http_proxy=http://proxy.rnd.samsung.ru:8080 >> /etc/environment
    # echo https_proxy=http://proxy.rnd.samsung.ru:8080 >> /etc/environment
    # . /etc/environment

### Packages installation
    # apt update
    # apt upgrade
    # apt install git wine64
    
## User section

### Miniconda and Meep installation
> **Note.** You can install [full *Anaconda* package (860 MB)](https://repo.anaconda.com/archive/Anaconda3-2023.03-1-Linux-x86_64.sh) instead of *Miniconda* (70 MB) at this step.

    $ wget https://repo.anaconda.com/miniconda/Miniconda3-latest-Linux-x86_64.sh
    $ chmod +x Miniconda3-latest-Linux-x86_64.sh
    $ ./Miniconda3-latest-Linux-x86_64.sh

(close and open again the terminal)

    (base)$ conda create -n mp -c conda-forge pymeep pymeep-extras
    (base)$ conda activate mp

### Python packages installation
    (mp)$ pip install PyLTSpice scikit-image

### Repository cloning
    (mp)$ git clone https://github.sec.samsung.net/LWIR/Full_LWIR_Simulation.git

### LTspice installation and testing
    (mp)$ msiexec /package Full_LWIR_Simulation/data/LTspice64.msi /quiet
    (mp)$ wine ~/.wine/drive_c/Program\ Files/ADI/LTspice/LTspice.exe

If the software installed properly, LTSpice GUI should appear. Close the LTspice window.

### Starting the simulation
    (mp)$ cd Full_LWIR_Simulation
    (mp)$ python3 main_module.py