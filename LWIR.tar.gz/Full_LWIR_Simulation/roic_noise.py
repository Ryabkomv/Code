# -*- coding: utf-8 -*-
"""
Created on Mon May 29 15:12:21 2023

@author: p.ivshin
"""
from PyLTSpice import sim, SimRunner, SpiceEditor, RawRead
from PyLTSpice.LTSteps import LTSpiceLogReader
import matplotlib.pyplot as plt
import numpy as np
import sys
import os

# Noise analysis range [Hz]
FREQ_FROM = 100
FREQ_TO = 100000

# Noise integration range [Hz]
INTEG_FROM = 19980
INTEG_TO = 20980

# Bandwidth for integration [Hz]
BANDWIDTH = 1000

# Temperature [°C]
TEMP = 20

# Circuit file without extension where:
# * Vin is AC small-signal voltage source
# * out is the output node name
CIRCUIT_NAME = 'data/pixel+amp'

# Actual LTSpice executables file names
SPICE_EXE_WIN = "c:\Program Files\ADI\LTspice\LTspice.exe"
SPICE_EXE_LINUX = os.path.expanduser('~') + "/.wine/drive_c/Program Files/ADI/LTspice/LTspice.exe"
SPICE_EXE_DARWIN = "/Applications/LTspice.app/Contents/MacOS/LTspice" # not checked on MAC OS X

def get_roic_noise(circuitname = CIRCUIT_NAME,
                       freq_from = FREQ_FROM, freq_to = FREQ_TO,
                       integ_from = INTEG_FROM, integ_to = INTEG_TO,
                       fi = 0, xl = 0, xc = 0, bandwidth = BANDWIDTH,
                       temp = TEMP):
    """
    Calculate ROIC noise using small-signal SPICE simulation.

    Args:
        circuitname (str, optional): LTspice circuit file. Defaults to CIRCUIT_NAME.

        freq_from (float, optional): lower frequency limit for noise vs. frequency dependency [Hz]. Defaults to FREQ_FROM.
        freq_to (float, optional): higher frequency limit for noise vs. frequency dependency [Hz]. Defaults to FREQ_TO.
        integ_from (float, optional): lower noise integration limit [Hz]. Defaults to INTEG_FROM.
        integ_to (float, optional): higher noise integration limit [Hz]. Defaults to INTEG_TO.

        fi (int, optional): imaging frame rate [Hz]. Defaults to 0.
        xl (int, optional): amount of lines [1]. Defaults to 0.
        xc (int, optional): amount of columns [1]. Defaults to 0.

        bandwidth (float, optional): bandwidth for integration [Hz]. Used only if fi, xl and xc are defined. Defaults to BANDWIDTH.
        temp (float, optional): detector temperature [°C]. Defaults to TEMP.

    Raises:
        Exception: if platform is unsupported, LTspice executable is not found
            or wine is not installed (on Linux)
    
    Returns:
        V_rms: RMS noise
        V_avg: average noise
        x, y:  noise vs. frequency dependency
    """    
    # TODO: add voltage, resistance parameters etc.
    # Checking for a platform and loading the non-default simulator executable file name
    if(sys.platform == 'win32'):
        spice_exe = SPICE_EXE_WIN
    elif(sys.platform == 'linux'):
        spice_exe = SPICE_EXE_LINUX
    elif(sys.platform == 'darwin'):
        spice_exe = SPICE_EXE_DARWIN
    else:
        raise Exception('Unsupported platform')

    # Trying to create simulator with default parameters
    LTC = SimRunner()
      
    # Error handling
    if (len(LTC.simulator.spice_exe) < 1):  # assuming error on Windows or Mac OS X
        if(os.path.isfile(spice_exe)):
            LTC = SimRunner(simulator = sim.ltspice_simulator.LTspice.create_from(spice_exe))
        else:
            raise Exception('LTspice executable not found at %s', spice_exe)
    else:
        if (LTC.simulator.spice_exe[0] == 'wine'):  # assuming Linux
            if(not os.path.isfile(LTC.simulator.spice_exe[1])):
                if(os.path.isfile(spice_exe)):
                    LTC.simulator.spice_exe[1] = spice_exe
                else:
                    raise Exception('LTspice executable not found at %s', spice_exe)
    print("Using simulator in %s" % LTC.simulator.spice_exe)
    # Creating netlist: first simulator call
    # We need check for simulator and wine (if we use Linux) availability
    try:
        LTC.create_netlist(CIRCUIT_NAME + '.asc')
    except FileNotFoundError as e:
        if(LTC.simulator.spice_exe[0] == 'wine'):
            raise Exception("""wine is not installed. Please install using
# dpkg --add-architecture i386
# apt update
# apt install wine wine32""") from None
        else:
            raise FileNotFoundError(e)
    # Frequency range from fi, xl and xc parameters
    if(not(fi == 0 or xl == 0 or xc == 0)):
        freq = fi * xl * xc
        integ_from = freq - bandwidth / 2
        integ_to = freq + bandwidth / 2
        if(freq_from > integ_from): freq_from = integ_from
        if(freq_to < integ_to): freq_to = integ_to
    print("Frequency range: from %d to %d Hz" % (integ_from, integ_to)) # debug
    # Adding parameters to netlist
    netlist = SpiceEditor(CIRCUIT_NAME + '.net')
    netlist.set_parameters(temp = temp)
    netlist.add_instructions(
        ".noise V(out) Vin dec 100 {0} {1}".format(freq_from, freq_to),
        ".measure noise RMS integ V(onoise) from {0} to {1}".format(integ_from, integ_to),
        ".measure noise AVG integ V(onoise) from {0} to {1}".format(integ_from, integ_to)
    )
    
    LTC.run(netlist)
    
    for raw, log in LTC:
        print("Raw file: %s, Log file: %s" % (raw, log))
    
    LTR = RawRead(raw)
    x = LTR.get_wave('frequency')
    y = LTR.get_wave('V(onoise)')

    meas = LTSpiceLogReader(log)
    V_rms = meas['rms'][0]
    V_avg = meas['avg'][0]
    # TODO: add AVG/MAX/MIN/PP 

    return V_rms, V_avg, x, y

def plot_noise(x, y, integ_from = INTEG_FROM, integ_to = INTEG_TO):
    fig, ax = plt.subplots()
    ax.set_title('ROIC noise vs. frequency')
    ax.set_xlabel('Frequency [Hz]')
    ax.set_ylabel('Noise [V/Hz^(1/2)]')
    ax.grid(visible = True)
    ylim0 = min(y)
    ax.vlines([integ_from, integ_to], ylim0, np.interp([integ_from, integ_to], x, y), colors = 'black', linestyles = 'dotted')
    ax.fill_between(x, y, ylim0, where = ((x >= integ_from) & (x <= integ_to)))
    ax.plot(x, y)
    fig.set_dpi(150)
    plt.savefig(fname = 'roic_noise.svg', dpi = 300, format = 'svg')
    plt.show()

if __name__ == "__main__":
    [V_rms, V_avg, x, y] = get_roic_noise()
    plot_noise(x, y)
    print("Frequency range: from %d to %d Hz" % (INTEG_FROM, INTEG_TO))
    print("RMS noise value within given frequency range: %0.8f V (%0.0f µV)" %
          (V_rms, V_rms*1e6))
    print("Average noise value within given frequency range: %0.8f V (%0.0f µV)" %
          (V_avg, V_avg*1e6))
