
import time
import logging
import mph
import os

# function for getting time response of a bolometer structure
def get_response_time(file_name, param_dict):
    t = []
    p1 = []
    with open(file_name, 'r') as f:
        for i in f.readlines():
            if (len(i)!=0) and '%' not in i:
                res = i.split()
                t.append(float(res[0]))
                p1.append(float(res[1]) - 300)
    threshold_1 = 0.9*p1[-1]
    for i, j in enumerate(p1):
        if j > threshold_1:
            tau = t[i]
            param_dict['tau_therm'] = tau * 1e-3
            break
    # return tau, t, p1

def get_heat_capacity(param_dict):
    x_side = param_dict['pixel_size']
    fill_factor = param_dict['beta']
    tiN = param_dict['tiN']
    aSi = param_dict['aSi']
    SiO2 = param_dict['SiO2']
    C_post = SiO2['post_s'] * SiO2['t_30'] * SiO2['cp'] * SiO2['rho']
    C_layer = SiO2['layer_fill'] * SiO2['layer_s'] * SiO2['t_diel'] * SiO2['cp'] * SiO2['rho']
    C_diel = 4*C_post + 2*C_layer
    C_tiN = fill_factor * (x_side ** 2) * tiN['t'] * tiN['cp'] * tiN['rho']
    C_aSi = (x_side ** 2) * aSi['t'] * aSi['cp'] * aSi['rho']
    total_C = C_tiN + C_aSi + C_diel
    response_time = param_dict['tau_therm']
    G = total_C / response_time

    # Update parameters dictionary

    param_dict['G'] = G
    param_dict['C'] = total_C
    print(f'Thermal capacity: \nTiN :   {(1e10 * C_tiN):.3f}e-10 J/K \nC_aSi : {(1e10 * C_aSi):.3f}e-10 J/K')
    print(f'\nTotal thermal capacity: \n{(1e10 * total_C):.3f}e-10 J/K')
    print(f'\nThermal conductance G: \n{(1e8 * G):.3f}e-8 W/K')

def comsol_model_adjustment():
    client = mph.start()
    pymodel = client.load("data_comsol/test_study.mph")
    model = pymodel.java

    correct_dir = os.getcwd() + "\\data_comsol\\"
    power_file = 'P_out_slit1.txt'
    struct_file = 'pixels.gds'
    full_filename = ''.join((correct_dir, power_file))
    struct_filename = ''.join((correct_dir, struct_file))

    for _i in ('imp2', 'imp3', 'imp4', 'imp5', 'imp6'):
        model.component('comp1').geom('geom1').feature(_i).set('filename', struct_filename)
    model.component('comp1').func('int1').set('filename', full_filename)

    model.save()

def th_simulate_absorbance(name, param_dict):
    logging.info("Thread %s: starting", name)
    time.sleep(2)

    export_file = 'time_response.txt'
    folder_name = 'data_comsol/'

    comsol_model_adjustment()

    client = mph.start()
    model = client.load("data_comsol/test_study.mph")
    model.studies()
    model.solve('Study 2')
    model.export('Plot 1', export_file)

    file_name_tau = folder_name + export_file
    get_response_time(file_name_tau, param_dict)
    get_heat_capacity(param_dict)

    print(f'response time tau {param_dict["tau_therm"]:.3f} s')
    print('absorbance has been calculated...')

    # write simulation data to files trans_1.txt / phase_1.txt
    logging.info("Thread %s: finishing", name)
    return None
