import logging
import threading
import sys

import numpy as np
import matplotlib.pyplot as plt
import matplotlib
matplotlib.use('TkAgg')

from model_parameters import param_dict
import image_reconstruction
import netd_calculation

def plotting_data():
    ma_num_r, du = param_dict['ma_num_r'], param_dict['du']
    Ha1_r, PSF1_r, u1_r, z1_r = param_dict['Ha1_r'], param_dict['PSF1_r'], param_dict['u1_r'], param_dict['z1_r']

    centre_coord1 = int(0.5 * np.shape(PSF1_r)[0])  # coordinates of the image centre to make cross-section plots
    slice_1 = slice(centre_coord1 - ma_num_r, centre_coord1 + ma_num_r)
    fig, axs  = plt.subplots(1, 3, figsize=(15, 10), sharey=False)

    imr1 = axs[0].imshow(np.angle(Ha1_r)[slice_1, slice_1])
    fig.colorbar(imr1, ax=axs[0], label='Phase difference, rad')
    axs[0].set_title(f'Phase difference in aperture plane \nfor {1e6 * param_dict["wvl1"]} um wavelength')

    axs[1].imshow(z1_r)
    axs[1].set_title(f'Scene reconstructed \nfor {1e6 * param_dict["wvl1"]} um wavelength')

    axs[2].plot(1e3 * u1_r, PSF1_r[centre_coord1][:], label='8 um wavelength')
    axs[2].set_xlim((-80 * 1e3 * du, 80 * 1e3 * du))
    axs[2].set_title('PSF')
    axs[2].set_xlabel('sensor position, mm')
    axs[2].legend()
    plt.show()

if __name__ == "__main__":

    if(sys.platform == 'win32'):
        import absorber_simulation
        th_list = [
        threading.Thread(target=image_reconstruction.th_construct_image, args=('IMAGE CONSTRUCTION', param_dict)),
        threading.Thread(target=absorber_simulation.th_simulate_absorbance,
                             args=('ABSORBER SIMULATION', param_dict)),
        threading.Thread(target=netd_calculation.th_calculate_netd, args=('NETD CALCULATION', param_dict))]
    elif(sys.platform == 'linux'):
        import metalens_simulation
        th_list = [
        threading.Thread(target=metalens_simulation.th_metalens_transmittance, args=('METALENS SIMULATION', param_dict)),
        threading.Thread(target=image_reconstruction.th_construct_image, args=('IMAGE CONSTRUCTION', param_dict)),
        threading.Thread(target=netd_calculation.th_calculate_netd, args=('NETD CALCULATION', param_dict))]
    else:
        raise Exception("Platform not supported")

    # update parameters
    netd_calculation.get_full_param_dict(param_dict)

    format = "%(asctime)s: %(message)s"
    logging.basicConfig(format=format, level=logging.INFO,
                        datefmt="%H:%M:%S")

    logging.info("Main    : before creating thread")

    logging.info("Main    : before running thread")
    for th_ in th_list:
        th_.start()
        th_.join()
    logging.info("Main    : all done")

    plotting_data()
