#!/bin/sh
rm *.log *.raw *.net roic_noise.svg main_module-ez-*.h5
