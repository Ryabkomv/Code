#!/bin/sh
# Start the simulation
python3 main_module.py
# Start the interactive shell for debugging purposes
bash

