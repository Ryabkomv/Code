
import logging
import time
import numpy as np
import roic_noise
from model_parameters import param_dict

c1 = param_dict['c1']
c2 = param_dict['c2']
c3 = param_dict['c3']

def get_full_param_dict(param_dict):

    # auxiliary variables

    Vadc = param_dict['Vq'] / (12 ** 0.5)
    Ibias = param_dict['Vbias'] / param_dict['Rbol']
    Reff = param_dict['Rbol'] * param_dict['Rroic'] / (param_dict['Rbol'] + param_dict['Rroic'])
    dP_dT = get_radiance_contrast(param_dict['lambda_start'], param_dict['lambda_r'], param_dict['T1'])
    A = param_dict['pixel_size'] ** 2  # pixel area
    tau_therm = param_dict['C']/param_dict['G']                                                                # thermal time constant of a bolometer pixel
    fr = param_dict['xl'] * param_dict['fi']                                                                   # read-out integration frequency
    fbol = 1 / (4 * tau_therm)                                                                                 # bolometer thermal integration frequency
    f_eff = np.min([fr, fbol])
    F = param_dict['focal_length'] / param_dict['D_lens']  # F-number
    R = param_dict['TCR'] * param_dict['beta'] * param_dict['eps'] * Reff * Ibias / (param_dict['G'] * (1 + param_dict['w'] ** 2 * tau_therm ** 2) ** 0.5)  # bolometer responsivity

    # update dictionary with variables

    param_dict.update({'Vadc':Vadc, 'Ibias':Ibias, 'Reff':Reff, 'dP_dT':dP_dT, 'A':A, 'tau_therm':tau_therm, 'fr':fr, 'fbol':fbol, 'f_eff':f_eff, 'F':F, 'R':R})

def get_bb_spc_radiance(wvl, T):
    return c1 / ((wvl ** 5) * np.exp(c2 / (wvl * T)) - 1)

def get_bb_photon_flux(wvl, T):
    return c3 / ((wvl ** 4) * np.exp(c2 / (wvl * T)) - 1)

def get_temp_deriv(wvl, T):
    numerator = c1 * c2 * np.exp(c2 / (wvl * T))
    denominator = (wvl ** 6) * (T ** 2) * (np.exp(c2 / (wvl * T)) - 1) ** 2
    return numerator / denominator

def get_flux_deriv(wvl, T):
    return c3 * c2 * np.exp(c2 / (wvl * T)) / ((wvl ** 5) * (T ** 2) * np.exp(c2 / (wvl * T)) - 1) ** 2

def get_radiance_contrast(wvl_start, wvl_stop, T, n_samples=1000):
    lambda_distr = np.linspace(wvl_start, wvl_stop, n_samples)
    delta_wvl = lambda_distr[1] - lambda_distr[0]
    P_distr = [get_temp_deriv(wvl, T) for wvl in lambda_distr]
    return delta_wvl * np.sum(P_distr)  # radiance contrast in W/(m**2 * K)

# 1/f noise voltage
def get_1f_noise(K_val, Vbias, Rbol, gamma, freq_req):
    return (K_val * Vbias ** 2 / (freq_req ** gamma)) ** 0.5

# Johnson noise voltage
def get_johnson_noise(k, T1, Rbol, fr, Rroic):
    return 2 * (k * T1 * Rbol * fr) ** 0.5 * (Rroic / (Rroic + Rbol))

# Thermal noise voltage
def get_thermal_noise(TCR, beta, Reff, Ibias, G, w, tau_therm, f_eff, T1, eps, k, R):
    return (2 * k ** 0.5 * R * T1 * (G * f_eff) ** 0.5) / (beta * eps)

# ROIC noise voltage
def get_roic_noise(Rbol, Rroic, Vamp, Vadc, Iroic):
    Reff = Rbol * Rroic / (Rbol + Rroic)
    return (Vamp ** 2 + Vadc ** 2 + Reff ** 2 * Iroic ** 2) ** 0.5

# ROIC noise voltage using SPICE simulation
def get_roic_noise(Nadc, Vref):
    Vroic1 = roic_noise.get_roic_noise(fi = param_dict['fi'],
                                       xl = param_dict['xl'], xc = param_dict['xc'],
                                       temp = param_dict['T1']-273)[0] # integral RMS noise using SPICE simulation
    Vq = Vref / 2 ** Nadc   # Input referred ADC quantization interval aka LSB
    Vadc = Vq / 12 ** 0.5   # Noise voltage of each ADC
    return (Vroic1 ** 2 + Vadc ** 2) ** 0.5

def th_calculate_netd(name, param_dict):

    logging.info("Thread %s: starting", name)
    time.sleep(2)
    print('1/f noise calculation')
    v_1f = get_1f_noise(param_dict['K_val'], param_dict['Vbias'], param_dict['Rbol'], param_dict['gamma'], param_dict['freq_req'])
    print('Johnson noise calculation')
    v_johnson = get_johnson_noise(param_dict['k'], param_dict['T1'], param_dict['Rbol'], param_dict['fr'], param_dict['Rroic'])
    print('Thermal noise calculation')
    v_thermal = get_thermal_noise(param_dict['TCR'], param_dict['beta'], param_dict['Reff'], param_dict['Ibias'], param_dict['G'], param_dict['w'], param_dict['tau_therm'], param_dict['f_eff'], param_dict['T1'], param_dict['eps'], param_dict['k'], param_dict['R'])
    print('ROIC noise calculation')
    v_roic = get_roic_noise(param_dict['Nadc'], param_dict['Vref'])
    # v_roic = get_roic_noise(param_dict['Rbol'], param_dict['Rroic'], param_dict['Vamp'], param_dict['Vadc'], param_dict['Iroic']) # without SPICE simulation
    # FULL NETD
    Vn = (v_1f ** 2 + v_johnson ** 2 + v_thermal ** 2 + v_roic ** 2) ** 0.5
    NETD = (4 * param_dict['F'] * Vn) / (param_dict['R'] * param_dict['A'] * param_dict['phi'] * param_dict['dP_dT'])
    print(f'V_1f - {1e6 * v_1f:.3f} uV')
    print(f'V johnson - {1e6 * v_johnson:.3f} uV')
    print(f'V thermal - {1e6 * v_thermal:.3f} uV')
    print(f'V ROIC - {1e6 * v_roic:.3f} uV')
    print(f'V full - {1e6 * Vn:.3f} uV')
    print(f'NETD is {1e3 * NETD:.3f} mK')

    print("NETD has been caluclated")

    print(f'Parameters: G - {param_dict["G"]}')
    print(f'Parameters: C - {param_dict["C"]}')
    print(f'Parameters: tau - {param_dict["tau_therm"]}')
    logging.info("Thread %s: finishing", name)

# wvl_range_um = np.linspace(1, 22, 1000)












