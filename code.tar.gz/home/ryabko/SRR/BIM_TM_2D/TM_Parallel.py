#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Feb  9 13:24:07 2024

@author: ryabko
"""

from mpi4py import MPI
import scipy.special as sc
import numpy as np
import matplotlib.pyplot as plt
import time

comm = MPI.COMM_WORLD
size = comm.Get_size()
rank = comm.Get_rank()
start_time = MPI.Wtime()

def RCS(xx,N):
    roX = -1
    roY = 0

    s = np.sum((1j*(nx*roX+ny*roY)*xx[0:N] - mu1*xx[N:]/k1)*np.exp(1j*k1*((x+dx/2)*roX+(y+dy/2)*roY))*dl)

    return k1*s*np.conj(s)/4

def Amn(N,rad):

    # R2x = np.tile(x, (N,1)).T - np.tile(x, (N,1)) + 0.5*dl*(np.tile(cosMy, (N,1)).T-2*np.tile(cosMy, (N,1)))
    # R2y = np.tile(y, (N,1)).T - np.tile(y, (N,1)) + 0.5*dl*(np.tile(sinMy, (N,1)).T-2*np.tile(sinMy, (N,1)))
   
    R2x = np.tile(x+0.5*dl*cosMy, (N,1)).T - np.tile(x+dl*cosMy, (N,1)) #+ 0.5*dl*(np.tile(cosMy, (N,1)).T-2*np.tile(cosMy, (N,1)))
    R2y = np.tile(y+0.5*dl*sinMy, (N,1)).T - np.tile(y+dl*sinMy, (N,1)) #+ 0.5*dl*(np.tile(sinMy, (N,1)).T-2*np.tile(sinMy, (N,1)))
    R2 =  np.sqrt(R2x**2 + R2y**2)
    
    R1x = R2x + dl*np.tile(cosMy, (N,1))
    R1y = R2y + dl*np.tile(sinMy, (N,1))
    R1 =  np.sqrt(R1x**2 + R1y**2)
    
    Rx = R2x + 0.5*dl*np.tile(cosMy, (N,1))
    Ry = R2y + 0.5*dl*np.tile(sinMy, (N,1))
    R =  np.sqrt(Rx**2 + Ry**2)

    b = np.concatenate((np.exp(-1j*k1*(x+1*dx/2)), x*0))
    
    diagD = 0.25j*v2*dl*(1-(np.log(k2*gamma*dl/4)-1)*2j/np.pi)
    diagB = -0.25j*v1*dl*(1-(np.log(k1*gamma*dl/4)-1)*2j/np.pi)
    
    B = -0.25j*v1*dl*sc.hankel2(0,k1*R)
    D =  0.25j*v2*dl*sc.hankel2(0,k2*R)
    
    A =  -(sc.hankel2(0,k1*R1)-sc.hankel2(0,k1*R2))*0.25j *(np.tile(nx, (N,1))*Rx+np.tile(ny, (N,1))*Ry) / (np.tile(lx, (N,1))*Rx+np.tile(ly, (N,1))*Ry)
    C =   (sc.hankel2(0,k2*R1)-sc.hankel2(0,k2*R2))*0.25j *(np.tile(nx, (N,1))*Rx+np.tile(ny, (N,1))*Ry) / (np.tile(lx, (N,1))*Rx+np.tile(ly, (N,1))*Ry)
    for m in range(N):
        B[m,m]=diagB
        D[m,m]=diagD
        A[m][m] = 0.5
        C[m][m] = 0.5
        
    return np.block([[A, B], [C, D]]), b
    
gamma = 1.781
f = 300e6
c = 3e8
lam = c/f
k0 = 2*np.pi/lam


mu1 = mu2 = 1
epsilon1 = 1
epsilon2 = 4

k1 = k0*np.sqrt(epsilon1*mu1)
k2 = k0*np.sqrt(epsilon2*mu2)

v1 = mu1
v2 = mu2
a = np.linspace(0.3/k0, 5.65/k0,100)

N  = 200 #number of dielectric cylinder segments
R = np.array(a*0)
cnt = 0

t = time.time()

phi = np.array(2*np.pi*np.arange(N)/N)




## start parallel
radius = a[rank]
dl = 2*np.pi*radius/N # the length of the segment
   
x = (radius*np.cos(phi))
y = radius*np.sin(phi)

dx=np.diff(x)
dy=np.diff(y)
dx = np.insert(dx,N-1,(x[0]-x[-1]))
dy = np.insert(dy,N-1,(y[0]-y[-1]))

lx = dx/np.sqrt(dx**2+dy**2)
ly = dy/np.sqrt(dx**2+dy**2)

nx = ly
ny = -lx


theta = np.arctan(dy/dx)

cosMy = np.cos(theta)*np.sign(dx)
sinMy = np.sin(theta)*np.sign(dx)
    
A,b=Amn(N,radius)

Ez = np.linalg.solve(A,b)

R[rank] = np.real(RCS(Ez,N))

# if (rank>0):
#     comm.send(R[rank],dest=rank)
# else if (rank ==0):
    
numDataPerRank = 1

# sendbuf = np.linspace(rank*numDataPerRank+1,(rank+1)*numDataPerRank,numDataPerRank)
# print('Rank: ',rank, ', sendbuf: ',R[rank])

recvbuf = None
if rank == 0:
    recvbuf = np.empty(numDataPerRank*size, dtype='d')  

comm.Gather(R[rank], recvbuf, root=0)

if rank == 0:
    # print('Rank: ',rank, ', recvbuf received: ',recvbuf)
    # plt.plot(k1*a,R/lam)
    np.savetxt('myarray.txt', [k1*a, recvbuf/lam])
    end_time = MPI.Wtime()
    print(end_time-start_time)
    

