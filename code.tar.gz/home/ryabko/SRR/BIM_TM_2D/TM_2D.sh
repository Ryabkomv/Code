#!/bin/bash
#echo "The current directory is:"
#pwd
#echo "The user logged in is:"
#whoami
mpirun -n 100 python -W ignore TM_Parallel.py
python PlotData.py
shotwell RCS.png
