# Boundary integral method: TM scattering on 2D dielectric cylinder

Code replicates the first result from the [paper](https://ieeexplore.ieee.org/document/1141624)

## How to use

run [TM_2D.sh](TM_2D.sh)

```
mpirun -n 100 python -W ignore TM_Parallel.py
python PlotData.py
shotwell RCS.png
```

First line runs the main [BIM code](TM_Parallel.py). It calculates the scattering for different cylinder sizes in parallel and saves data in to the [text file](myarray.txt)

Next [python file](PlotData.py) uses the saved data to build the image

Last line visualizes the result. For comparison there is a reference image from the paper

<img src="RCS.png" height ="250">  <img src="Ref.png" height ="250">




## Theory

Brief theory is described in the above mentioned [paper](https://ieeexplore.ieee.org/document/1141624). For more detailes refer to the [book](https://confluence-eu.sec.samsung.net/download/attachments/619449669/volakis_jl_sertel_k_integral_equation_methods_for_electromag.pdf?version=1&modificationDate=1704808123677&api=v2) Chapter 5.4

### 1. Form integral equations by matching the fields and derrivatieves at the boundary.

<img src = "IEB.png" height = "100">
For each boundary use the field expression on the boundary approaching from the inside and outside: 2 equations with 2 unknowns.

### 2. Descretize the integral equations.
Expresses the solution as a sum of basis functionsand perform the point matching at the boundary.
Among the methods are MOM, Nystrom etc.
MOM uses some basis functions then scalar product with usually same basis function: aka Galerkin method
Nystrom uses quadratures for each segment integration: [Gauss Laguere](https://en.wikipedia.org/wiki/Gauss%E2%80%93Laguerre_quadrature), [Fejer](https://people.math.ethz.ch/~waldvoge/Papers/fejer.pdf) etc. 

Additional work is needed for singularity treatment at the self and adjacent segments. Naive way used in the code, is to use tailor expansion. More advanced approach is [singularity removal](https://projecteuclid.org/journals/journal-of-integral-equations-and-applications/volume-26/issue-2/A-collocation-method-for-a-hypersingular-boundary-integral-equation-via/10.1216/JIE-2014-26-2-197.full)

### 3. Form sytem of linear equations. 

<img src ="SLAU.png" height = "70">

where:

<img src ="COEFF.png" height = "300">

Solve for fields and derrivatives and use them along with Green's expression to find the fields at any point.


