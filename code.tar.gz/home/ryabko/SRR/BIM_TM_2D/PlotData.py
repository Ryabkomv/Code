#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Feb  9 15:46:18 2024

@author: ryabko
"""
import numpy as np
import matplotlib.pyplot as plt

k = np.loadtxt('myarray.txt')
plt.yscale("log")  
plt.plot(k[0],k[1])
plt.grid()
plt.title('Backscattered RCS from dielectric cilinder.\n TM polarization in 2D.', fontsize=18)
plt.xlabel('k*radius', fontsize=14)
plt.ylabel(r'$\frac{RCS}{\lambda}$', fontsize=18)
plt.savefig('RCS.png')