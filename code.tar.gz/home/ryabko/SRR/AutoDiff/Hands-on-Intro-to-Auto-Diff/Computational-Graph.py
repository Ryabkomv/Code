#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Oct  2 15:36:24 2023

@author: ryabko
"""

import warnings

import numpy as np
import compgraph as cg

%matplotlib inline
warnings.filterwarnings('ignore')

cg.reset()  # resets the nodes counts to 0 to start from 0 at each visualization

x = cg.variable(np.pi / 4, name='x')
c = x**2

for i in range(6):
    if (i%2):
       
        c = c*i
    else:
        
        c=c*c

a = cg.sin(c)
b = cg.sin(c)

y = a ** b

print("y = {}".format(y))

cg.visualize_at(y, figsize=(10, 4))