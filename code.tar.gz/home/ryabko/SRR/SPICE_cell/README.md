# SPICE_cell
Single cell SPICE simulations

## Contents

### Cell heating
Bolometer heating simulation using electrical analogy method for thermal circuit

#### Simulation without thermal feedback (bolometer resistance = const)

* `heating.asc` **LTspice schematics file**
* `heating.plt` LTspice plot settings
* `Rtherm2.asy` LTspice symbol for bolometer with thermal output
* `thermalR2.txt` SPICE model for bolometer with thermal output

#### Simulation with thermal feedback (bolometer resistance = R(T))

* `heating3.asc` **LTspice schematics file**
* `heating3.plt` LTspice plot settings
* `Rtherm3.asy` LTspice symbol for bolometer with thermal output and feedback input
* `thermalR3.txt` SPICE model for bolometer with thermal output and feedback input

![heating3.asc](img/heating3.png)

* `heating.xlsx` simulation results:

![heating.xlsx](img/heating3chart.png)

![heating.xlsx](img/heating3deltaT.png)

#### Miscellaneous

* `delbak.cmd` script to delete temporary files from working directory

### Single pixel simulation

#### Resistance vs. temperature dependency:

* `R_vs_temp.png` source chart image
* `R_vs_temp.bmp` image for GetData digitizing software
* `R_vs_temp.gdw` GetData file
* `R_vs_temp.txt` digitizing results
* `R_vs_temp.xlsx` results with R(T) trendline equation

* `R_vs_temp.wxmx` R(T) equation test
* `R_vs_temp.asc` R(T) equation test

#### Single cell simulations, temperature-dependent

* `pixel+amp.asc` **LTspice schematics file, noise simulation**
* `pixel+amp_article.asc` **LTspice schematics file**
* `pixel+amp.plt` LTspice plot settings

![pixel+amp.asc](img/pixel%2Bamp.png)

![pixel+amp.raw.asc](img/pixel%2Bamp.raw.png)

* `pixel+amp_tran.asc` **LTspice schematics file, transient simulation**
* `pixel+amp_tran.asc` transient simulation plot settings

![pixel+amp_tran.raw](img/pixel%2Bamp.tran.raw.png)

#### Miscellaneous

* `delbak.cmd` script to delete temporary files from working directory

### `img`
Images to use in this document.

## Software required
* [LTspice XVII](https://www.analog.com/en/design-center/design-tools-and-calculators/ltspice-simulator.html)
* [wxMaxima](https://wxmaxima-developers.github.io/wxmaxima/download.html)
* [GetData](https://getdata-graph-digitizer.com/ru/download.php)
* [MS Excel](https://www.microsoft.com/en-us/microsoft-365/excel)
