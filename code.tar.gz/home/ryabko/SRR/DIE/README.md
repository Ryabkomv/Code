# DIE
DIE = **D**ifferentiate **I**t **E**ngine. A tool for inverse design with adjoint gradients based on GPU-accelerated FDTD

Please, use latest update of fdtd-z from [local repo](https://github.sec.samsung.net/LWIR/GPU_FDTD) with float32 bug fix
