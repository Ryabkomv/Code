# -*- coding: utf-8 -*-
"""
Created on Thu Nov 30 14:55:36 2023

@author: a.sofronov
"""

import numpy as np

class adam:
    def __init__(self, solver, x0, alpha = 0.001, beta1 = 0.9, beta2=0.999, eps=1E-8, save_path = None, force_binarity = False):
        self.solver = solver
        self.x0 = x0
                
        self.b1 = beta1
        self.b2 = beta2
        self.a = alpha
        self.eps = eps
        
        self.m = np.zeros(x0.shape)
        self.v = np.zeros(x0.shape)
        self.x = np.copy(x0)
        self.g = np.zeros(x0.shape)
        
        self.force_binarity = force_binarity
    
    def run(self, T, target = 1E-4, U0 = 1E-2, post_iters = 0, beta_min = 10.0, beta_max = 3000.0):
        
        gamma = 0.95
        C = (1.0/U0 - 1.0)/beta_max
        for t in np.arange(T):
            if (self.force_binarity):
                beta = (beta_max - beta_min)*(np.exp((t/T)**2) - 1.0)/(np.exp(1.0)-1.0) + beta_min
                un_bin = self.solver.unbinarity(beta, self.x)
                C = gamma*C + (1.0 - gamma)*(1.0/un_bin - 1.0)/beta
                beta_max = gamma*beta_max + (1.0 - gamma)*(1.0/U0 - 1.0)/C
            else:
                beta = beta_min
            
            f0, self.g = self.solver.target_function(self.x, beta)
            self.m = self.b1*self.m + (1.0-self.b1)*self.g
            self.v = self.b2*self.v + (1.0-self.b2)*self.g**2
            mhat = self.m/(1.0-self.b1**(1+t))
            vhat = self.v/(1.0-self.b2**(1+t))
            self.x = self.x - self.a*mhat/(vhat**0.5 + self.eps)
        for t1 in np.arange(post_iters):
            f0, self.g = self.solver.target_function(self.x, beta_max)
            if f0<=target:
                return self.x
            self.m = self.b1*self.m + (1.0-self.b1)*self.g
            self.v = self.b2*self.v + (1.0-self.b2)*self.g**2
            mhat = self.m/(1.0-self.b1**(1+(T+t1)))
            vhat = self.v/(1.0-self.b2**(1+(T+t1)))
            self.x = self.x - self.a*mhat/(vhat**0.5 + self.eps)            
        return self.x
            