import numpy as np

class Source:
    def __init__(self,  ## original cell size along
                 xx,    ##  x,
                 yy,    ##  y, and
                 zz,    ##  z, number of points
                 pos,   ## position [points] in direction  dir
                 tt,    ## Number of timesteps
                 dt,    ## timestep,  [um]
                 omega, ## UNITS:  rad/um   central frequency and  
                 phase = 0,  ## phase
                 dir: int = 0,  ## 0 = x, 1 = y, 2 = z
                 ):
        self.tt = tt
        self.dt = dt
        if pos%2:
            pos +=1  
        ###  ^ ^   Source pos MUST BE EVEN, otherwise all out fields = 0
        
        
        ## Source fields passed to the fdtd_z() are "current sources" in terms of original Maxwell equations.
        ## In case of sources in (x-z) or (y-z) planes, along y and x respectively, we can specify two transverse 
        ## components of the current source term J, namely Ex and Ez, or Ey and Ez, respectively.
        
        ## Realization is simple Ez[src_pos,t] = Ez[src_pos,t] + Jz[src_pos,t] and Ex[src_pos,t] = Ex[src_pos,t] + Jx[src_pos,t] 
        
        ## See Update.h, __dhce__ void YPlaneSrc(), lines 250-290
        ## where srccoeff is just a wafeworm (i.e. sin(wt) at current time step), 
        ## and ysrc contains original source fields array passed to fdtd_z() transformed to internal diamond structure
        
        ## It is the same as "Additive Source" from Understanding FDTD by John Schneider 2022, p. 3.8, Eq. (3.28), p. 48-49
        
        ## Note that original cuda kernel implements only y-source in (x-z) plane. 
        ## x-source in (y-z) plane is implemented in python wrapper by mirroring the entire computational cell 
        ## along the diagonal x=y to swap x and y 
        ## See fdtd_jax.py, def fdtdz(), lines 305-321
        
        ## The problem is that when we want to use a combination of different output modes (which are real) 
        ## with a different df/da coeficients (which are complex) for adjoint source, we need to specify 
        ## different phases of time-dependence for different parts of src_fields array to take into account 
        ## these different complex coefficients (src_field itself should be real) 
        ## It looks impossible in current implementation of cuda kernel.
        ## So, we need to run separate simulation for each output..
        ## Or, for symmetric structures, we can use the same phases since the output transmissions should be the same
        
        self.omega = omega
        self.phase = phase
        
        if (dir == 0):
            self.source_field = np.zeros((2, 1, yy, zz), np.float32)                                                        
            self.source_waveform = np.zeros((tt, 2), np.float32)
            self.source_waveform[:, 0] = self.ramped_sin(self.omega, phase)
            self.source_waveform[:, 1] = self.ramped_sin(self.omega, phase)           
            self.source_position = pos
    
    def set_phase(self, phase):
            self.phase = phase
            self.source_waveform[:, 0] = self.ramped_sin(self.omega, phase)#self._waveform(omega, w)
            self.source_waveform[:, 1] = self.ramped_sin(self.omega, phase)
            
    def ramped_sin(self, omega, phase = 0, width = 2, delay=1):
        """Sine function with a gradual ramp, inspired by MEEP's continuous source.
        See https://meep.readthedocs.io/en/latest/FAQ/#why-doesnt-the-continuous-wave-cw-source-produce-an-exact-single-frequency-response

        """
        tt = self.tt
        t = omega * self.dt * np.arange(tt, dtype=np.float32)   
        width = 10
        delay = 1
        return ((1 + np.tanh(t / width - delay)) / 2) * np.sin(t + phase)