import os

#os.environ['XLA_PYTHON_CLIENT_PREALLOCATE']='false'
#os.environ['XLA_PYTHON_CLIENT_PREALLOCATE']='true'
#os.environ['XLA_PYTHON_CLIENT_MEM_FRACTION']='.10'

import numpy as np
from boundaries import Boundaries
from source import Source
from modes import modes

import autograd.numpy as npa
from autograd import tensor_jacobian_product

import fdtdz_jax
import jax
#import jax.profiler

def evn(i:int):   ## ensure i is even
    if i % 2 != 0:
        i +=1
    return i

## C-style struct to hold mode data
class ModeData:
    def __init__(self,
                 eps: np.ndarray,    ## wg cross-section (3,yy,zz)
                 j0: int,             ## 
                 k0: int,            ## position and
                 dj: int,            ## size of the wg in eps array
                 dk: int             ## in pixels
                 ):
        self.eps = np.copy(eps)
        self.mode_yy = eps.shape[1]
        self.j0 = j0
        self.k0 = k0
        self.dj = dj
        self.dk = dk
        self.fields = []
        self.neffs  = []
        self.freqs  = []
        self.orders = []
        yy = eps.shape[1]
        zz = eps.shape[2]
        self.J = np.zeros((2,1,yy,zz))  
        
    def append(self, 
               freq: float,         ## 1/um
               neff: float,         ## neff
               fields: np.ndarray,  ## mode fields, (6,eps.shape[1], eps.shape[2])
               order: int = 1       ## mode order
               ):
        self.neffs.append(neff + 0)
        self.fields.append(np.copy(fields))
        self.freqs.append(freq)
        self.orders.append(order)
        
    def __getitem__(self, idx:int): ## operator[], returns patch for source array as expected by fdtdz()
        if idx >= 0 and idx < len(self.fields):
            self.J[0,0,:,:] = - np.real(self.fields[idx][5,:,:])  # Jy = - Hz
            self.J[1,0,:,:] =   np.real(self.fields[idx][4,:,:])  # Jz =   Hy
        return self.J
        
## C-style struct to hold intermediate simulation results during iterations
## simulation itself is supposed to return only target function and it's gradients
class Iter_info:
    def __init__(self, 
                 t: list[complex] = 0,
                 T: list[float] = 0,
                 x: np.ndarray = None,
                 x_pr: np.ndarray = None,
                 fE: list[np.ndarray] = None,
                 aE: list[np.ndarray] = None,):
        self.t = t   ## amplitude transmission at each output
        self.T = T   ## power transmission at each output
        self.x = x
        self.x_pr = x_pr
        self.fE = fE
        self.aE = aE

class Model:
    def __init__(self, 
                 resolution: float,  ## desired resolution, px/um
                 freqs: np.ndarray,  ## Frequencies at each input, 1/um
                 Nin: int = 2,
                 Nout: int = 2,
                 wg_width: float = 0.5,   ## um
                 wg_height: float = 0.22, ## um
                 arm_separation: float = 1.6, ## um
                 wg_length: float = 2, #1.5, # 3.0 ## um
                 aspect: float = 1.0, 
                 Si: float = 3.4,
                 SiO2: float = 1.44,
                 mode_size: float = 1.6,   ## expected mode size
                 use_reduced_precision: bool = True,
                 time_coeff: int = 5000,
                 ):
        self.SiO2 = SiO2
        self.Si = Si
        
        #pml_widths = (10,10)
        pml_widths = (6,6)
        self.use_float16 = use_reduced_precision            
        zz = (128 if use_reduced_precision else 64) - sum(pml_widths)        
        
        ## let's make 0.5 um x 0.22 um waveguide to occupy 
        ## exactly some integer number of cells:
        w_um = wg_width
        h_um = wg_height
        w_px = evn(int(w_um*resolution))
        h_px = 8 if resolution > 40 else 4  # we want to stretch z-axis 
                                            # and use only 8 or 4 cells along z 
                                            # to represent the height of the waveguide
        if use_reduced_precision:
            h_px = h_px + h_px      # with float16 we have 2x z extent available...                          
                                    
        dx_um = w_um/w_px
        ## This is actual resolution that makes w_um fit to integer number of cells
        resolution = 1/dx_um

        dz_um = h_um/h_px
        dz = dz_um/dx_um   ## dz in fdtdz units where size of cell dx=dy=1
        
        self.dz = dz 
        
        
        mode_yy = evn(int(zz*dz)) ## make the in-plane mode size equal physically to z mode size
            
        ## Defining the cross-section of waveguide
        cross_eps = SiO2 **2 * np.ones((3, mode_yy, zz))    
        j0 = int((mode_yy - w_px)/2)
        k0 = int((zz - h_px)/2)
        cross_eps[:,j0:j0+w_px,k0:k0+h_px] = Si**2
        
        ## Saving bottom and top positions of silicon layer inside SiO2 cladding
        self.k_b = k0
        self.k_t = k0 + h_px
        
        ## Calculating modes
        self.mode_data = ModeData(cross_eps, j0, k0, w_px, h_px)
        for f in freqs:
            neff, fields = modes(cross_eps, 1/f, resolution, 1, dz)
            self.mode_data.append(f, neff, fields)
            
              
        ## Magic absorber parameters that works with Si/SiO2 waveguide at resolution 50 px/um 
        abs_width = 60
        smth = 0.005E-2
        self.abs_width = abs_width
        
        arm_separation = evn(int(arm_separation*resolution))/resolution
        design_region_height = arm_separation * np.max([Nin, Nout])
        design_region_width = design_region_height*aspect
        height_um = design_region_height 
        width_um = design_region_width + 2*(wg_length + abs_width/resolution)
        
        y_pos_in_um = arm_separation*np.arange(Nin) 
        y_pos_in_um = y_pos_in_um - np.mean(y_pos_in_um) # centering inputs vertically
        y_pos_out_um = arm_separation*np.arange(Nout) 
        y_pos_out_um = y_pos_out_um - np.mean(y_pos_out_um) # centering outputs vertically
        wg_center_x_um = - 0.5*(design_region_width + wg_length)       
        
        xx = evn(int(width_um * resolution) )
        yy = evn(int((height_um + mode_size) * resolution) + 2*abs_width)
                
        self.res = resolution
        self.xx = xx
        self.yy = yy
        self.zz = zz
        self.xx_c = xx//2
        self.yy_c = yy//2
        self.zz_c = zz//2
        
        self.design_region_height = design_region_height
        self.design_region_width = design_region_width
                
        self.bnds = Boundaries(xx = self.xx, 
                               yy = self.yy, 
                               zz = self.zz, 
                               dz = dz, 
                               pml_widths=pml_widths, 
                               abs_width=abs_width, 
                               abs_smoothness=smth)
        
        Sc = 0.95
        self.dt = Sc/3**0.5  # [fdtd-z units]
        self.tt = time_coeff
        
        wls_px = 1/np.asarray(freqs) * self.res  ## wavelength in pixels
        self.freqs = 1/wls_px  
        
        qT = 1*int(0.25/np.mean(self.freqs)/self.dt)      ## Quarter of period  [fdtd-z units]     
        
        if qT<1:
            qT = 1
            print('Time resolution is too low to distinguish 1/4 of period...')
                
        self.output_steps = (self.tt-1-qT, self.tt, qT)           
        self.t1 = (self.tt-1-qT)   # [fdtd-z units]
        self.t2 = (self.tt-1)      # [fdtd-z units]
        out_num = 2
        self.time_outputs = 2
        
        ## Arrays initialization
        self.mask = np.zeros((xx, yy))
        self.eps = np.ones((3, xx, yy, zz))
        self.out = np.zeros((out_num, 3, self.xx, self.yy, self.zz))
        ## Output: (n, 3, xx0, yy0, zz0) 3 fields components over simulation cell at n timesteps
     
     
     
  ###################/***************  Normalization
  
        self.inputs = []
        self.outputs = []
        self.adj_srcs = []
        for y in y_pos_in_um:
            self.add_waveguide((wg_center_x_um, y, 0), 
                                wg_length, 
                                input=True, 
                                output=False)
            self.add_waveguide((0, y, 0), 
                                design_region_width,
                                input=False, 
                                output=False)
            self.add_waveguide((-wg_center_x_um, y, 0),
                                wg_length, 
                                input=False, 
                                output=True)
        self.build_epsilon()

        self.alpha0 = []
        self.alpha0m = []
        
        for idx in range(len(self.inputs)):
            ap, am = self.run(idx)
            self.alpha0.append(ap)        
            self.alpha0m.append(am)       
                         
        ## This is for debugging perposes only. Check if it can be deleted safely..                         
        self.norm_eps = np.copy(self.eps)
        self.norm_out = np.copy(self.out)
        self.norm_fd_out =  fd_fields(self.out,  self.freqs[idx], self.t1*self.dt, self.t2*self.dt)
        self.norm_outputs = np.copy(self.outputs)
        
        
        ### Prepare for run....
        self.mask[...] = 0
        self.out[...]  = 0
        self.inputs    = []
        self.outputs   = []           
        self.adj_srcs  = []

        ##  Adding objects        
        for y in y_pos_in_um:
            self.add_waveguide((wg_center_x_um, y, 0), 
                                wg_length, 
                                input = True, 
                                output=False)
        for y in y_pos_out_um:
            self.add_waveguide((-wg_center_x_um, y, 0), 
                               wg_length,
                               input=False, 
                               output=True)
            
        self.add_design_region((design_region_width, design_region_height))
        i1,i2, j1, j2 = self.des_reg_idxs 
        self.Si_mask = np.ones((i2-i1,j2-j1))
        self.Si_mask[0,:] = self.mask[i1,j1:j2]
        self.Si_mask[-1,:] = self.mask[i2,j1:j2]
        self.Si_mask[:,0] = 0
        self.Si_mask[:,-1] = 0
        self.build_epsilon()        
    ## // __init__()
        
    def build_epsilon(self):        
        self.eps[...] = self.SiO2**2
        k1 = self.k_b 
        k2 = self.k_t
        msk = np.stack([self.mask] * (k2-k1), axis = -1) ## Extrude 2D mask to 3D material distributions
        self.eps[2,:,:,k1:k2] = self.SiO2**2 * (1-msk) + self.Si**2 * msk
        self.eps[1,:,:,k1:k2] = self.SiO2**2 * (1-msk) + self.Si**2 * msk
        self.eps[0,:,:,k1:k2] = self.SiO2**2 * (1-msk) + self.Si**2 * msk
        
    def add_waveguide(self, 
                      center: tuple,        ##  (x,y,z), um  
                      length: float,        ##  um
                      input: bool = True,   ##  is input waveguide
                      output: bool = False, ##  is output waveguide, both can be True to monitor reflections
                      direction: int = 0,   ##  0 = x, 1 = y, 2 = z
                      ):
        if (direction == 0):
            ## 1. eps[wg] = Si
            
            j1 = self.j(center[1]) - self.mode_data.mode_yy//2 + self.mode_data.j0
            j2 = j1 + self.mode_data.dj
            i1 = self.i(center[0] - length/2)
            i2 = self.i(center[0] + length/2) + 1
            self.mask[i1:i2, j1 : j2] =  1.0     
            
            ## 2. src_field[wg] = mode for input wg
            
            j1m = self.j(center[1]) - self.mode_data.mode_yy//2
            j2m = j1m + self.mode_data.mode_yy
            if (input):
                fr_idx = len(self.inputs)
                w = 2*np.pi* self.freqs[fr_idx] 
                src = Source(xx = self.xx, 
                             yy = self.yy, 
                             zz = self.zz, 
                             pos = self.i(center[0]) - 3, 
                             tt = self.tt, 
                             dt = self.dt, 
                             omega = w) 
                self.mask[:i1,j1:j2] = 1.0     # extend waveguide into absorber
                src.source_field[:,:,j1m:j2m,:] = self.mode_data[fr_idx]
                self.inputs.append(src)
            
            if (output):
                ## Append "views" of original 5D array to the output list
                ## Each "view" is kind of 2D monitor with shape (tt, 3, 3, mode_yy, mode_zz)
                ## and represents 3 field components vs time in the 3 adjacent cross-section planes of waveguide 
                ## This is actually a reference to the part of 5D array
                ## and will be updated after out[...] = fdtdz(...)
                
                self.mask[i2:,j1:j2] = 1.0 # extend waveguide into absorber
                self.outputs.append(self.out[:, :, self.i(center[0])+3:self.i(center[0])+3+3, j1m:j2m, :])
                
                w = 2*np.pi* self.freqs[0]   
                adj_src = Source(xx = self.xx, 
                             yy = self.yy, 
                             zz = self.zz, 
                             pos = self.i(center[0])+3+1, 
                             tt = self.tt, 
                             dt = self.dt, 
                             omega = w) 
                
                adj_src.source_field[:,:,j1m:j2m,:] = self.mode_data[0]
                self.adj_srcs.append(adj_src)
    
    def add_design_region(self, 
                          size: tuple,     ##  (width along x, height along y)
                          center: tuple = (0,0,0),   ##  (x,y,z), um  
                          ):
        i1 = self.i(center[0] - size[0]/2)
        i2 = self.i(center[0] + size[0]/2)
        j1 = self.j(center[1] - size[1]/2)
        j2 = self.j(center[1] + size[1]/2)
        self.des_reg_idxs = (i1,i2, j1, j2)
        self.mask[i1:i2, j1:j2] = 0.5
    
    def update_weights(self, 
                       x: np.ndarray):
        i1,i2, j1, j2 = self.des_reg_idxs
        i2 = i1 + x.shape[0]
        j2 = j1 + x.shape[1]
        self.mask[i1:i2, j1:j2] = x
        self.build_epsilon()
    
    def _idx(self, x, dir):
        ## Converts physical coord x to indexes along dir
        ## x=0, y=0, z=0 is at the center of the grid
        c = 0
        size = 0
        scalar_input = np.isscalar(x)
        if (scalar_input):
           x = np.array([x])
        if(dir == 0):
            c = self.xx_c
            size = self.xx
        elif(dir == 1):
            c = self.yy_c
            size = self.yy
        else:
            c = self.zz_c
            size = self.zz
        
        i = np.array(c + np.ceil(x*self.res).astype(int), dtype=int)
        i[i>=size] = size-1
        i[i<0] = 0
        
        if(scalar_input):
            return i[0]
        else:
            return i
    def i(self, x):
        return self._idx(x, 0)
    def j(self, y):
        return self._idx(y, 1)
    def k(self, z):
        return self._idx(z, 2)

    def structure_xy(self, z, c = 0):
        return self.eps[c,:,:,self.k(z)]
    def structure_xz(self, y, c = 0):
        return self.eps[c,:,self.j(y),:]
    def structure_yz(self, x, c = 0):
        return self.eps[c,self.i(x), :, :]    
    
    def run(self, in_idx):
        src = self.inputs[in_idx]
        self.out[:,:,:,:,:], out_, buf_, cbuf_, msk_, src_   = fdtdz_jax.fdtdz( 
                epsilon = self.eps,
                dt = self.dt,
                source_field = src.source_field,
                source_waveform = src.source_waveform,
                source_position = src.source_position,
                absorption_mask = self.bnds.abs_mask ,
                pml_kappa = self.bnds.pml_kappa,
                pml_sigma = self.bnds.pml_sigma,
                pml_alpha = self.bnds.pml_alpha,
                pml_widths = self.bnds.pml_widths,
                output_steps = self.output_steps,
                use_reduced_precision = self.use_float16,
                launch_params=((2, 4), (8, 8), 4, (8, 6)),
                offset=(0, 0, 0),
                )      
        self.fd_out =  fd_fields(self.out, self.freqs[in_idx], self.t1*self.dt, self.t2*self.dt)
        ap = []
        am = []
        modes = self.mode_data.fields[in_idx]
        for out_idx in range(len(self.outputs)):
            fields = fd_fields(self.outputs[out_idx], self.freqs[in_idx], self.t1*self.dt, self.t2*self.dt)  # (3, 3, mode_yy, mode_zz) array Fourier fields
            p, m = alpha(modes, fields, self.res, self.freqs[in_idx]*self.res, self.dz)
            ap.append(p)
            am.append(m)
        return ap, am                            
    
    def full_run(self, 
                 x: np.ndarray,
                 info: Iter_info = None, 
                 separate_channels: bool = False):
        
        TT = 0.48 ## target transmission
        TF = 0
        
        self.update_weights(x)
        ap, am = self.run(0)
        i1,i2, j1, j2 = self.des_reg_idxs
        k1 = self.k_b 
        k2 = self.k_t
        E_dr_f = np.copy(self.fd_out[:, i1:i2, j1:j2, k1:k2])
        if info != None:
            info.fE = [E_dr_f[0,:,:,:], E_dr_f[1,:,:,:], E_dr_f[2,:,:,:]]
        
        delta_eps = self.Si**2 - self.SiO2**2
        dfdp = x * 0
        if separate_channels: 
            for i in range(len(self.outputs)):
                alpha = ap[i]/np.abs(self.alpha0[0])
                TF += (TT -  np.abs(alpha)**2)**2
                
                sign = -1     
                coef = -2*(TT - np.abs(alpha)**2) * np.conj(alpha)
                coef_phase = - np.angle(coef)
                coef_abs = (- np.abs(coef)) * sign
                    
                src = self.adj_srcs[i]
                src.set_phase(coef_phase)
                source_field = - coef_abs * src.source_field
                
                self.out[:,:,:,:,:], _, _, _, _, _   = fdtdz_jax.fdtdz( 
                    epsilon = self.eps,
                    dt = self.dt,
                    source_field = source_field,
                    source_waveform = src.source_waveform,
                    source_position = src.source_position,
                    absorption_mask = self.bnds.abs_mask ,
                    pml_kappa = self.bnds.pml_kappa,
                    pml_sigma = self.bnds.pml_sigma,
                    pml_alpha = self.bnds.pml_alpha,
                    pml_widths = self.bnds.pml_widths,
                    output_steps = self.output_steps,
                    use_reduced_precision = self.use_float16,
                    launch_params=((2, 4), (8, 8), 4, (8, 6)),
                    offset=(0, 0, 0),
                    )      
                adj_fd = fd_fields(self.out, self.freqs[0], self.t1*self.dt, self.t2*self.dt)
                E_dr_a = sign * np.copy(adj_fd[:, i1:i2, j1:j2, k1:k2])
                vtx = np.sum(E_dr_a[0,:,:,:]*E_dr_f[0,:,:,:], axis = 2)
                vty = np.sum(E_dr_a[1,:,:,:]*E_dr_f[1,:,:,:], axis = 2)
                vtz = np.sum(E_dr_a[2,:,:,:]*E_dr_f[2,:,:,:], axis = 2)
                self.fd_adj_out = adj_fd
                dfdp +=  2 * np.real( - delta_eps * (vtx + vty + vtz) )
        else:
            alpha = ap/np.abs(self.alpha0[0])
            TF = np.sum((TT -  np.abs(alpha)**2)**2)
            
            sign = -1     
            src = self.adj_srcs[0]
            source_field = 0 * src.source_field
            coef = -2*(TT - np.abs(alpha)**2) * np.conj(alpha)
            coef_phase = np.mean( - np.angle(coef))
            coef_abs = (- np.abs(coef)) * sign
                
            for i in range(len(self.outputs)):
                source_field += - coef_abs[i] * self.adj_srcs[i].source_field
                self.adj_srcs[i].set_phase(coef_phase)    
            
            self.out[:,:,:,:,:], _, _, _, _, _   = fdtdz_jax.fdtdz( 
                epsilon = self.eps,
                dt = self.dt,
                source_field = source_field,
                source_waveform = src.source_waveform,
                source_position = src.source_position,
                absorption_mask = self.bnds.abs_mask ,
                pml_kappa = self.bnds.pml_kappa,
                pml_sigma = self.bnds.pml_sigma,
                pml_alpha = self.bnds.pml_alpha,
                pml_widths = self.bnds.pml_widths,
                output_steps = self.output_steps,
                use_reduced_precision = self.use_float16,
                launch_params=((2, 4), (8, 8), 4, (8, 6)),
                offset=(0, 0, 0),
                )   
            
            adj_fd = fd_fields(self.out, self.freqs[0], self.t1*self.dt, self.t2*self.dt)
            E_dr_a = sign * np.copy(adj_fd[:, i1:i2, j1:j2, k1:k2])
            vtx = np.sum(E_dr_a[0,:,:,:]*E_dr_f[0,:,:,:], axis = 2)
            vty = np.sum(E_dr_a[1,:,:,:]*E_dr_f[1,:,:,:], axis = 2)
            vtz = np.sum(E_dr_a[2,:,:,:]*E_dr_f[2,:,:,:], axis = 2)
            self.fd_adj_out = adj_fd
            dfdp +=  2 * np.real( - delta_eps * (vtx + vty + vtz) )
            
        if info != None:
            info.aE = [E_dr_a[0,:,:,:], E_dr_a[1,:,:,:], E_dr_a[2,:,:,:]]
            info.t = [val for val in ap/np.abs(self.alpha0[0])]
            info.T = [np.abs(val)**2 for val in ap/np.abs(self.alpha0[0])]
        return TF, dfdp
        
        
    
def fd_fields(td_fields, f, t1, t2):
    
    ## td_fields: "views" of original 5D array of electric fields
    ## in two adjacent planes along wg axis (x)
    ## shape (2, 3, mon_xx,  mode_yy, mode_zz)
    ##  idxs:
    ##   0: 2 last time steps at t1 and t2
    ##   1: 3 field components: Ex, Ey, Ez
    ##   2: (y-z) planes adjacent in x direction
    ##   3: mode size along y
    ##   4: mode size along z
    
    ## returns shape (3, mon_xx, mode_yy, mode_zz) array with forier-transformed fields
    f1 = td_fields[0,...]
    f2 = td_fields[1,...]
    wt1 = 2*np.pi*f*t1 
    wt2 = 2*np.pi*f*t2
    M = np.array([[np.sin(wt1), np.cos(wt1)],[np.sin(wt2), np.cos(wt2)]])
    invM = np.linalg.inv(M)
    return invM[0,0]*f1 + invM[0,1]*f2 + 1j*(invM[1,0]*f1 + invM[1,1]*f2)


def alpha(modes, fields, res, freq, dz = 1.0):
    ## modes: (6, m_yy, m_zz) 6 components of mode fields 
    ## fields: (3, 3, m_yy, m_zz) 3 components of electric field which coupling to the mode is computed,
    ##                                captured at 3 adjacent (y-z) planes
    ## res: resolution, px/um
    ## freq: frequency,  1/um
    ## dz: dz/dx - vertical stretching
    
    ex   = modes[0,...]
    ey   = modes[1,...]
    ez   = modes[2,...]
    hx   = modes[3,...]  ## magnetic fields are located at the same points 
    hy   = modes[4,...]  ## with corresponding E components.
    hz   = modes[5,...]  ## They are unrolled inside modes()
    
    Ex  = 0.5 * (fields[0,0,...] + fields[0,1,...]) 
    Ey  = fields[1,1,...] 
    Ez  = fields[2,1,...]
    Ex1 = 0.5 * (fields[0,1,...] + fields[0,2,...])
    Ey1 = fields[1,2,...]
    Ez1 = fields[2,2,...]
    
    ## Now we have to put all field components at the same point
    ## originally, Ex, Ey, and Ez are at (0.5,0,0), (0, 0.5, 0), and (0, 0, 0.5) points of Yee cell
    ## Let it be at (0,0,0) point of the Yee cell...
    ey = 0.5 * (ey + np.roll(ey, 1, axis = 0))
    ez = 0.5 * (ez + np.roll(ez, 1, axis = 1))
    hy = 0.5 * (hy + np.roll(hy, 1, axis = 0))
    hz = 0.5 * (hz + np.roll(hz, 1, axis = 1))   
    ## ex and hx are translationally invariant along x since they are modes of wg 
    
    Ey = 0.5 * (Ey + np.roll(Ey, 1, axis = 0))
    Ez = 0.5 * (Ez + np.roll(Ez, 1, axis = 1))
    Ey1 = 0.5 * (Ey1 + np.roll(Ey1, 1, axis = 0))
    Ez1 = 0.5 * (Ez1 + np.roll(Ez1, 1, axis = 1))
    
    ex = ex[1:-1, 1:-1]
    ey = ey[1:-1, 1:-1]
    ez = ez[1:-1, 1:-1]
    hx = hx[1:-1, 1:-1]
    hy = hy[1:-1, 1:-1]
    hz = hz[1:-1, 1:-1]
    Ex = Ex[1:-1, 1:-1]
    Ey = Ey[1:-1, 1:-1]
    Ez = Ez[1:-1, 1:-1]
    Ex1 = Ex1[1:-1, 1:-1]
    Ey1 = Ey1[1:-1, 1:-1]
    Ez1 = Ez1[1:-1, 1:-1]
    
   ## Nm = 0.5*np.abs(np.sum(ey*np.conj(hz) - ez*np.conj(hy)))  ## OWT Eq. (11-12)
    Nm = 0.5*abs(np.trapz(np.trapz(ey*np.conj(hz) - ez*np.conj(hy) , axis=0),axis=0))
    
    #Edothm = np.sum(Ey*np.conj(hz) - Ez*np.conj(hy))
    Edothm = np.trapz(np.trapz(Ey*np.conj(hz) - Ez*np.conj(hy), axis=0), axis=0)
    
    dEydx = (Ey1 - Ey)*res
    dEzdx = (Ez1 - Ez)*res
       
    dExdy = (np.roll(Ex,-1, axis = 0) - Ex)*res
    dExdy[0,:] = 0
    dExdy[-1,:] = 0
    
    dExdz = (np.roll(Ex,-1, axis = 1) - Ex)*res/dz
    dExdz[:,0] = 0
    dExdz[:,-1] = 0
    
    #emdotH1 = 1j*np.sum( np.conj(ey) * (dEydx - dExdy) - np.conj(ez)*(dExdz - dEzdx) )/(2*np.pi*freq)
    emdotH1 = 1j* np.trapz( np.trapz(np.conj(ey) * (dEydx - dExdy) - np.conj(ez)*(dExdz - dEzdx), axis=0), axis = 0 )/(2*np.pi*freq)
    
    a_f = 0.25 * (Edothm + emdotH1) / Nm
    a_b = 0.25 * (Edothm - emdotH1) / Nm
    
    return a_f, a_b

## Differentiable mapping of initial design to filtered/projected one.
## For a while, we use projection functions from meep.adjoint
def mapping(x: np.ndarray,   ## 2D array!!!
            beta: float, 
            model: Model):
    #return x
    from filters import get_conic_radius_from_eta_e, conic_filter, tanh_projection
    eta_e = 0.55
    eta = 0.5
    minimum_length = 0.1
    filter_radius = get_conic_radius_from_eta_e(minimum_length, eta_e)
    filtered_field = conic_filter(
        x,
        filter_radius,
        model.design_region_width,
        model.design_region_height,
        model.res,
    )
    # mirror symmetry..
    filtered_field = 0.5 * (filtered_field + npa.fliplr(filtered_field))
    #projection
    projected_field = tanh_projection(filtered_field, beta, eta)
    return projected_field

## Class for compatility with adam optimizer from adam.py 
## It should implement only 2 functions:
##  - unbinarity(beta, x) , returns the unbinarity of un-filtered un-projected design with a given beta
##  - target_function(x, beta) , returns the target function value (scalar) and it's gradient with respect to x 
##                               at a given un-filtered un-projected design x and projection parameter beta

## Saving optimization history can be implemented here as well

class Solver_wrapper:
    def __init__(self,
                 model: Model, 
                 out_path: str = None):
        self.model = model
        self.history = []
        self.cnt = 0
        if out_path == None:
            save_dir = 'def_output'
            script_path = os.path.dirname(os.path.realpath(__file__))
            self.save_path = os.path.join(script_path, save_dir)
            if not os.path.isdir(self.save_path): os.makedirs(self.save_path) 
        else:
            self.save_path = out_path

    def unbinarity(self, beta, x):
        p = mapping(x, beta, 
                    self.model)
        return npa.sum(1.0 - npa.power((2.0*p-1.0),200.0))/len(p.flatten())

    def target_function(self, x, beta):
        info = Iter_info()
        self.cnt += 1
        
        #x = 0.5*(x + np.fliplr(x))
        x_pr = mapping(x,beta, self.model)
        
        x_pr[:,0]  = 1
        x_pr[:,-1] = 1
        x_pr[0,:]  = 1
        x_pr[-1,:] = 1 
        x_pr = x_pr * self.model.Si_mask
        
        info.x = np.copy(x)
        info.x_pr = np.copy(x_pr)
        
        tf, dfdp = model.full_run(x_pr, info)
        
        #dfdp = 0.5*(dfdp + np.fliplr(dfdp))
        
        total_grad = tensor_jacobian_product(mapping, 0)(x, beta, 
                                                      model,
                                                      dfdp)
        
        ## Ensure that p_masked edges of design region do not change anything...
        total_grad[:,0] = 0
        total_grad[:,-1] = 0
        total_grad[0,:] = 0
        total_grad[-1,:] = 0
        
        i1, i2, j1, j2 = model.des_reg_idxs
        Nx = i2 - i1
        Ny = j2 - j1
        ## Saving history
        hist = {
            'iteration': self.cnt,
            'x_pr':info.x_pr,  
            'x':   info.x,  
            'beta': beta,
            'obj': tf,
            'inputs': [0],
            'r': [0],
            't':info.T,
            'obj_by_in_channel': info.t,
            'Nx':Nx,
            'nNx':Nx,
            'Ny':Ny,
            'nNy':Ny,
            'binarity': self.unbinarity(beta, x),
            'C':1,
            'grad': total_grad,
            'fE': info.fE,
            'aE': info.aE
            }
        
        np.save(self.save_path + '/history' + str(self.cnt) + '.npy',hist)
        print()
        print()
        print('Iteration # ' + str(self.cnt) + ' finished.')
        print()
        print()
        return tf, total_grad
        

### Test

import matplotlib.pyplot as plt
import matplotlib.animation as animation

N_in = 1
freqs = np.ones(N_in)/(1.55)

use_reduced_precision = False and True  ## or -> float16 / and -> float32
z = 54 if use_reduced_precision else 22

tmax = 5000
model = Model(50, freqs,
            Nin = N_in,
            Nout = 2,
            mode_size=1.6,
            use_reduced_precision = use_reduced_precision ,
            time_coeff= tmax if use_reduced_precision else tmax, 
            SiO2=1.44)


solver = Solver_wrapper(model,'def_output')

i1, i2, j1, j2 = model.des_reg_idxs
x = 0.5 * np.ones((i2-i1, j2-j1))

from time import time
from adam import adam

opt = adam(solver, x, force_binarity=True, alpha=0.001)

t1 = time()
opt.run(T = 100, post_iters = 100, beta_min=20, beta_max=1000)

print('Total time for 200 iterations: ' + str(time() - t1) + 'sec')
