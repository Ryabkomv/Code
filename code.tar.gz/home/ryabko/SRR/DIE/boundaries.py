import numpy as np

def safe_div(x, y):
  return np.zeros_like(x) if y == 0 else x / y

class Boundaries:    
    def __init__(self,
                 xx,  # Cell size in x direction [points]
                 yy,  # Cell size in y direction [points]
                 zz,  # Cell size in z direction [points]
                 dz = 1,
                 pml_widths = (10,10),   # points, PML in z direction
                 abs_width = 20,         # points, Absorber in xy directions
                 abs_smoothness = 1*1E-2#0.1*1E-2  # was 1E-2
                 ):
        self.xx = xx
        self.yy = yy
        self.zz = zz
        
        self.abs_mask = self.absorption_mask(abs_width, abs_smoothness)
        self.pml_kappa = dz*np.ones((zz, 2), np.float32) ## this is the size of unit cell in z direction
                                                         ## i.e. dz (dx = dy = 1) 
        self.pml_sigma = self.pml_sigma_values(pml_widths, zz)
        self.pml_alpha = 0.05 * np.ones((zz, 2), np.float32)   
        self.pml_widths = pml_widths
        self.abs_width = abs_width
  
    def pml_sigma_values(self, pml_widths, ln_R = 16.0, m = 4.0):
        """Conductivity values for PML boundary condition along the z-axis."""
        offset = np.array([[0], [0.5]], dtype=np.float32)
        z = np.arange(self.zz, dtype = np.float32) + offset
        z = np.stack([safe_div(pml_widths[0] - z, pml_widths[0]), 
                        safe_div(z + 0.5 - self.zz + pml_widths[1], pml_widths[1])], axis=-1)
        z = np.max(np.clip(z, a_min=0, a_max=None), axis=-1)
        return ((m + 1) * ln_R * z**m).T
    ## For impedance-mathcing with the simulation default material, 
    ## we need to multiply it by n of background material!
    ## sigma(z) = (z/d)^m  (- (m+1)*lnR / 2\eta d), \eta = (mu/eps)^0.5 = (1/n) (mu0/eps0)^0.5 = 1/n in meep units
    
    def absorption_profiles(self, numcells, width, smoothness):
        """1D quadratic profile for adiabatic absorption boundary conditions."""
        center = (numcells - 1) / 2
        offset = np.array([[0], [0.5]], dtype=np.float32)
        pos = np.arange(numcells, dtype=np.float32) + offset
        pos = np.abs(pos - center) - center + width
        pos = np.clip(pos, a_min=0, a_max=None)
        return smoothness * np.power(pos, 2)
    
    def cross_profiles(self, x, y):
        """Combine two 1D absorption profiles into a 2D profile."""
        return np.max(np.meshgrid(x, y, indexing='ij'), axis=0, keepdims=True)

    def absorption_mask(self, width, smoothness):
        """Adiabatic absorption boundary condition in the x-y plane."""
        x = self.absorption_profiles(self.xx, width, smoothness)
        y = self.absorption_profiles(self.yy, width, smoothness)
        return np.concatenate([self.cross_profiles(x[0], y[1]), 
                                self.cross_profiles(x[1], y[0]), 
                                self.cross_profiles(x[1], y[1])])
 