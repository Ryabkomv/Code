import numpy as np
import matplotlib.pyplot as plt
from scipy.sparse import diags, linalg, csc_matrix


def modes(eps, wl, res, nmodes = 1, vertical_stretching = 1):
    ## eps - 3D np.ndaray with shape = (3, Nx, Ny) , 
    ##       cross-section of waveguide with eps_xx, eps_yy, eps_zz 
    ##       components after subpixel averaging
    ## wl - vacuum wavelength [um]
    ## res - resolutin pixels/um
    ## vertical_stretching - dz/dx
    ## 
    ## Returns neff, np.ndarray((6, Nx, Ny)) with 6 field components 
    ## representing mode fields at the same grid as eps
    
    ## order is: 
    # [0,:,:] - E component along the waveguide direction (longitudinal component)
    # [1,:,:] - E component along first axis of eps (first transverse component)
    # [2,:,:] - E component along second axis of eps (second transverse component)
    # [3,:,:] - H component along the waveguide direction (longitudinal component)
    # [4,:,:] - H component along first axis of eps (first transverse component)
    # [5,:,:] - H component along second axis of eps (second transverse component)
    
    ## IMPORTANT: H field components are unrolled to the same positions as E field components
    ## inside Yee cell!!
    ## Ex and Hx are at (0.5, 0, 0)
    ## Ey and Hy are at (0, 0.5, 0)
    ## Ez and Hz are at (0, 0, 0.5)
    
    ## TODO: 
    ## Accept nmodes > 1, and add one more dimension to output arrays representing different modes.
    ## Need to sort the modes over effective index before return...

    def yeeder2d(grid_size, resolution, k=None):
        """
        Function that computes the scipy sparse derivative matrices on the 2D Yee Grid
        Arguments:
            grid_size = two-tuple of the size of the grid
            resolution = two-tuple of the grid resolution (i.e. incremental step)
            k = incident waves

        Returns:
        Derivative matrices with Dirichlet conditions in the x and y direction (DEx, DEy, DHx, DHy)
        """
        # Extracting grid parameters
        Nx = grid_size[0]
        Ny = grid_size[1]
        dx = resolution[0]
        dy = resolution[1]

        # Default indicent wave
        if k is None:
            k_incident = np.zeros(2)

        # Matrix size and zero matrix
        M = int(Nx * Ny)

        ### Building DEx
        if Nx == 1:
            DEx = -1j * k_incident[0] * np.eye(M)
        else:
            d0 = - np.ones(M)
            d1 = np.ones(M - 1)
            d1[range(Nx - 1, M - 1, Nx)] = 0
            DEx = (1 / dx) * diags([d0, d1], [0, 1])


        ### Building DEy
        if Ny == 1:
            DEy = -1j * k_incident[1] * np.eye(M)
        else:
            d0 = - np.ones(M)
            d1 = np.ones(int(M - Nx))
            DEy = (1 / dy) * diags([d0, d1], [0, Nx])


        ### Build DHx and DHy
        DHx = - DEx.transpose()
        DHy = - DEy.transpose()

        # Transforming to sparse matrices
        DEx = csc_matrix(DEx)
        DEy = csc_matrix(DEy)
        DHx = csc_matrix(DHx)
        DHy = csc_matrix(DHy)

        return DEx, DEy, DHx, DHy
    
    # Extract tensor elements on yee grid
    ERxx = eps[0,:,:] 
    ERyy = eps[1,:,:]
    ERzz = eps[2,:,:]

    URxx = 1 + eps[0,:,:] * 0
    URyy = 1 + eps[0,:,:] * 0
    URzz = 1 + eps[0,:,:] * 0

    # Flatten arrays column major style
    ERxx = ERxx.flatten('F')
    ERyy = ERyy.flatten('F')
    ERzz = ERzz.flatten('F')
    URxx = URxx.flatten('F')
    URyy = URyy.flatten('F')
    URzz = URzz.flatten('F')

    # Calculating the multiplicative inverse of the permeability and permittivity matrices
    ERxx_i = 1 / ERxx
    ERyy_i = 1 / ERyy
    ERzz_i = 1 / ERzz
    URxx_i = 1 / URxx
    URyy_i = 1 / URyy
    URzz_i = 1 / URzz

    # Creating a Sparse Diagonal and transforming it to an array
    ERxx = diags(ERxx, 0)
    ERyy = diags(ERyy, 0)
    ERzz = diags(ERzz, 0)
    URxx = diags(URxx, 0)
    URyy = diags(URyy, 0)
    URzz = diags(URzz, 0)

    # Creating sparse diagonals of inverses
    ERxx_i = diags(ERxx_i, 0)
    ERyy_i = diags(ERyy_i, 0)
    ERzz_i = diags(ERzz_i, 0)
    URxx_i = diags(URxx_i, 0)
    URyy_i = diags(URyy_i, 0)
    URzz_i = diags(URzz_i, 0)
    
    lam0 = wl
    k0  = 2*np.pi/lam0
    Nx = eps.shape[1]
    Ny = eps.shape[2]
    dx = 1/res
    NS = [Nx, Ny]   # array containing the size of the grid
    RES = [k0*dx, vertical_stretching*k0*dx]
    [DEX,DEY,DHX,DHY] = yeeder2d(NS, RES, k=None)
    
    from scipy.sparse import coo_matrix, bmat
    P = bmat([[DEX @ ERzz_i @ DHY, -(DEX @ ERzz_i @ DHX + URyy)], [DEY @ ERzz_i @ DHY + URxx, -DEY @ ERzz_i @ DHX]])
    Q = bmat([[DHX @ URzz_i @ DEY,  -(DHX @ URzz_i @ DEX + ERyy)], [DHY @ URzz_i @ DEY + ERxx, -DHY @ URzz_i @ DEX]])

    import scipy.sparse.linalg as sla
    
    ev       = - np.max(eps)
    D2, Exy  = sla.eigs(P @ Q, k=nmodes, M=None, sigma=ev)
    D        = D2**0.5
    NEFF     = -1j*diags(D)
    neff = np.real(NEFF.diagonal()[0])
            
    M  = Nx*Ny
    Ex = Exy[0:M, :]
    #print(Ex.shape)
    ex = np.reshape(Ex[:M,0],(Nx, Ny), 'F')
    Ey = Exy[M:2*M,:]
    #print(Ey.shape)
    ey = np.reshape(Ey[:M,0],(Nx, Ny), 'F')
    
    if (np.sum(Ex)<0):  ## flip signs if eig() returned negative Et1 
        ex = -ex
        ey = -ey
    
    Hxy = (Q@Exy)/D[0] 
    Hx  = Hxy[0:M, :]
    Hy  = Hxy[M:2*M,:]

    hx = np.reshape(Hx[:M,0],(Nx, Ny), 'F')
    hy = np.reshape(Hy[:M,0],(Nx, Ny), 'F')

    Ez = ERzz_i @ (DHX@Hy - DHY@Hx)
    Hz = URzz_i @ (DEX@Ey - DEY@Ex)  
    
    ez = np.reshape(Ez[:,0],(Nx, Ny), 'F')
    hz = np.reshape(Hz[:,0],(Nx, Ny), 'F')
    
    ## Restore the original H field from the normalization used in mode solver
    ## Raymond Rumpf's book, Eq. (4.11) Hhat = -1j * h0 * H 
    ##   h0 is vacuum impedance, equal to 1 in meep's units (eps0 = mu0 = 1)
    ##   Mode solver solves for Hhat, we need H, so H = Hhat / (-1j) = 1j H
    hx = 1j*hx
    hy = 1j*hy
    hz = 1j*hz 
    
    # проверка на знак Ht , El    
    #P =  0.5 * np.sum(ex*np.conj(hy) - ey * np.conj(hx))
    P =  0.5 * np.trapz(np.trapz(ex*np.conj(hy) - ey * np.conj(hx), axis=0), axis=0)
    if np.real(P) < 0:   ## Power of the mode = Re(P)
        hx = -hx
        hy = -hy
        ez = -ez    
    ## We always want to return forward propagating mode
    ## If we found that the sign of Poynting vector of the modes is negative, 
    ## it means that eig() and everyrhing below have computed a backward mode.
    ## In this case we need to change the signs according to the symmetry:
    ## Snyder & Love, Optical Waveguide Theory, ch. 11, Eq. (11-7)
    ## 
    ##  e(+) = et(+) + ez(+)*z,  h(+) =   ht(+) + hz(+)*z, 
    ##  e(-) = et(+) - ez(+)*z,  h(-) = - ht(+) + hz(+)*z, 
    ##  beta(-) = - beta(+)
        
    #  Next, make the modes orthonormal:
    ## Normalize it by the N = 0.5 \int E x H* z dA   Eq. (11-12)
    ## N = 0.5 int (ex hy* - ey hx*) dA 
    
    N = np.abs(P)**0.5  ## Eq. (11-15)
    
    if N == 0:
        N = 1
        
    
    ## unroll magnetic fields...
    ## here we use local coordinates, z is wg axis, 
    #                                 x is horizontal cross-section axis (0.5 um), 
    #                                 y is vertical cross-section axis (0.22 um)
    tmphx = 0.5 * (hx  + np.roll(hx, -1, axis = 0))
    tmphx = 0.5 * (tmphx + np.roll(tmphx, +1, axis = 1))
    
    tmphy = 0.5 * (hy + np.roll(hy, +1, axis = 0)) 
    tmphy = 0.5 * (tmphy + np.roll(tmphy, -1, axis = 1))
    
    tmphz = 0.5 * (hz + np.roll(hz, +1, axis = 0))
    tmphz = 0.5 * (tmphz + np.roll(tmphz, +1, axis = 1))
    
    flds = np.zeros((6, Nx, Ny), dtype = complex)
    flds[0,:,:] = ez/N
    flds[1,:,:] = ex/N
    flds[2,:,:] = ey/N
    flds[3,:,:] = tmphz/N #hz/N
    flds[4,:,:] = tmphx/N #hx/N
    flds[5,:,:] = tmphy/N #hy/N
    
    return neff, flds

def plot_modes(eps, f, label = ''):
    ## expects eps is a 2D array, 
    ## f is 3D (6, Nx, Ny) array with 6 field components returned by modes()

    plt.figure()
    plt.imshow(eps)
    plt.title(label + 'Epsilon')
    plt.xlabel('Transverse direction 2')
    plt.ylabel('Transverse direction 1')
    
    fig, ax = plt.subplots(2, 3)
    im00 = ax[0][0].imshow(np.real(f[0,:,:]))
    im01 = ax[0][1].imshow(np.real(f[1,:,:]))
    im02 = ax[0][2].imshow(np.real(f[2,:,:]))
    im10 = ax[1][0].imshow(np.imag(f[0,:,:]))
    im11 = ax[1][1].imshow(np.imag(f[1,:,:]))
    im12 = ax[1][2].imshow(np.imag(f[2,:,:]))
    fig.colorbar(im00)
    fig.colorbar(im01)
    fig.colorbar(im02)
    fig.colorbar(im10)
    fig.colorbar(im11)
    fig.colorbar(im12)
    ax[0][0].set_title('Re($e_l$)')
    ax[0][1].set_title('Re($e_{t1}$)')
    ax[0][2].set_title('Re($e_{t2}$)')
    ax[1][0].set_title('Im($e_{l}$)')
    ax[1][1].set_title('Im($e_{t1}$)')
    ax[1][2].set_title('Im($e_{t1}$)')
    fig.suptitle(label)
    fig.tight_layout()
    
    fig, ax = plt.subplots(2, 3)
    im00 = ax[0][0].imshow(np.real(f[3,:,:]))
    im01 = ax[0][1].imshow(np.real(f[4,:,:]))
    im02 = ax[0][2].imshow(np.real(f[5,:,:]))
    im10 = ax[1][0].imshow(np.imag(f[3,:,:]))
    im11 = ax[1][1].imshow(np.imag(f[4,:,:]))
    im12 = ax[1][2].imshow(np.imag(f[5,:,:]))
    fig.colorbar(im00)
    fig.colorbar(im01)
    fig.colorbar(im02)
    fig.colorbar(im10)
    fig.colorbar(im11)
    fig.colorbar(im12)
    ax[0][0].set_title('Re($h_l$)')
    ax[0][1].set_title('Re($h_{t1}$)')
    ax[0][2].set_title('Re($h_{t2}$)')
    ax[1][0].set_title('Im($h_{l}$)')
    ax[1][1].set_title('Im($h_{t1}$)')
    ax[1][2].set_title('Im($h_{t1}$)')
    fig.suptitle(label)
    fig.tight_layout()



### Testing
if __name__ == '__main__':
    
    import numpy as np
    mode_size = 1.5  # um
    res = 50         # pxls/um
    wl = 1.55        # um 
    def test(use_double_grid = False):
        Nx = int(mode_size*res)
        Ny = int(mode_size*res)
        eps = np.zeros((3, Nx, Ny))
        if use_double_grid:
            Nx2 = 2*Nx
            Ny2 = 2*Ny
            res2 = 2*res
            width2 = int(0.5*res2)    ## waveguide 0.5 x 0.22 um 
            height2 = int(0.22*res2)
            half_w2 = int(width2/2)
            half_h2 = int(height2/2)
            eps2 = 1.44**2*np.ones((Nx2, Ny2))
            Nc2 = int(Nx2/2)
            eps2[Nc2-half_w2 : Nc2+half_w2 + 1, Nc2 - half_h2 : Nc2+half_h2 + 1] = 3.4**2
            eps[0,:,:] = eps2[1:Nx2:2, 0:Ny2:2]   ## xx component
            eps[1,:,:] = eps2[0:Nx2:2, 1:Ny2:2]   ## yy component
            eps[2,:,:] = eps2[0:Nx2:2, 0:Ny2:2]   ## zz component 
        else:
            width = int(0.5*res)    ## waveguide 0.5 x 0.22 um 
            height = int(0.22*res)
            half_w = int(width/2)
            half_h = int(height/2)
            eps1 = 1.44**2*np.ones((Nx, Ny))
            Nc = int(Nx/2)
            eps1[Nc-half_w : Nc+half_w + 1, Nc - half_h : Nc+half_h + 1] = 3.4**2
            eps[0,:,:] = eps1   ## xx component
            eps[1,:,:] = eps1   ## yy component
            eps[2,:,:] = eps1   ## zz component

        neff, f = modes(eps, wl, res)
        
        plot_modes(eps[0,:,:], f, label = 'Mode Solver: ')
        print('******************************')
        print()
        print('Use double grid = ' + str(use_double_grid))
        print('Mode solver: neff = ' + str(neff))
        print()
        print('******************************')
         
    ## Try to compare with meep
    import importlib.util
    meep_spec = importlib.util.find_spec("meep")
    found = meep_spec is not None
    if not found:
        print('Cannot locate meep, skip the test')
        test(True)
        test(False)
    else:    
        import meep as mp
        freq = 1/wl
        Sz = mode_size
        mode_size_z = mode_size
        Sx = mode_size
        Sy = mode_size
        cell_size = mp.Vector3(Sx, Sy, Sz)
        sim = mp.Simulation(cell_size = cell_size,
            boundary_layers = [],
            geometry = [mp.Block(size = mp.Vector3(mp.inf,0.5,0.22), material = mp.Medium(index = 3.4))],
            #sources = [],
            symmetries = [], #[mp.Mirror(direction=mp.Y)], <= mode parity ??
            default_material=mp.Medium(index = 1.44),
            resolution=res, 
            eps_averaging=False
            )
        sim.run(until = 1) ## For some reason, fields should be initialized before computing modes...
        mode_data = sim.get_eigenmode(freq,
                                    direction = mp.X,
                                    band_num = 1,
                                    where = mp.Volume(center=mp.Vector3(0, 0, 0), 
                                                        size=mp.Vector3(0, mode_size, mode_size_z)),
                                    kpoint=mp.Vector3(1.44*freq,0,0)
                                    )
        x,y,z,w = sim.get_array_metadata(center = mp.Vector3(0, 0, 0),
                                        size = mp.Vector3(0, mode_size, mode_size_z))

        f = np.zeros((6,len(y), len(z)), dtype = complex)
        eps_meep = sim.get_array(mp.Dielectric, center = mp.Vector3(0, 0, 0),
                                        size = mp.Vector3(0, mode_size, mode_size_z))
        neff = mode_data.k.x/mode_data.freq
        for i in range(len(y)):
            for j in range(len(z)):
                f[0,i,j] = 1j*np.imag(mode_data.amplitude(mp.Vector3(x[0],y[i],z[j]), mp.Ex))
                f[1,i,j] = np.real(mode_data.amplitude(mp.Vector3(x[0],y[i],z[j]), mp.Ey))
                f[2,i,j] = np.real(mode_data.amplitude(mp.Vector3(x[0],y[i],z[j]), mp.Ez))
                f[3,i,j] = 1j*np.imag(mode_data.amplitude(mp.Vector3(x[0],y[i],z[j]), mp.Hx))
                f[4,i,j] = np.real(mode_data.amplitude(mp.Vector3(x[0],y[i],z[j]), mp.Hy))
                f[5,i,j] = np.real(mode_data.amplitude(mp.Vector3(x[0],y[i],z[j]), mp.Hz))
        
        
        plot_modes(eps_meep, f, label = 'MEEP: ')
        print()
        print()
        print('******************************')
        print()
        print('Meep: neff = ' + str(neff))
        print()
        print('******************************')
    
        test(use_double_grid=True)
        test(use_double_grid=False)
    
        eps = np.zeros((3, eps_meep.shape[0], eps_meep.shape[1]))
        eps[0,:,:] = eps_meep
        eps[1,:,:] = eps_meep
        eps[2,:,:] = eps_meep
        
        neff, f = modes(eps, wl,res)
        plot_modes(eps[0,:,:], f, label = 'Mode Solver: ')
        print('******************************')
        print()
        print('Epsilon from meep')
        print('Mode solver: neff = ' + str(neff))
        print()
        print('******************************')