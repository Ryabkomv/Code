
'''
3D splitter solving by FDFD method.
There are 4 first steps of topology optimization of 3D splitter model (eps0.npy, eps1.npy, eps2.npy, eps3.npy).
The first splitter (eps0) is solved by fgmres iterative solver with no initial guess and high tolerance 0.01.
For the second splitter (eps1) the result of the first splitter is used as initial guess with tolerance 0.001.
For the third splitter (eps2) the result of the second splitter is used as initial guess with tolerance 0.0001.
And for the last splitter (eps3) the result of the third splitter is used as initial guess with tolerance 0.00001.
'''

# %%
import numpy as np
import matplotlib.pyplot as plt
from scipy.sparse import diags, csc_matrix
import scipy.sparse.linalg as sla
import matplotlib.pyplot as plt
from scipy.sparse import bmat
from petsc4py import PETSc
import time


def yeeder3d(NS, RES, k=None):
#     Compute derivative matrices on a 2D Yee Grid according to Boundary Conditions
#     Arguments:
#         NS    [Nx, Ny] Grid Size
#         RES   [dx, dy] Grid Resolution
#         kinc  [kx, ky] Incident Wave Vector
#     Returns:
#         DEx spatial derivatives of the electric field across the x-axis
#         DEy spatial derivatives of the electric field across the y-axis
#         DHx spatial derivatives of the magnetic field across the x-axis
#         DHy spatial derivatives of the magnetic field across the y-axis

    Nx = int(NS[0])                          # extract grid parameter at the x-axis
    Ny = int(NS[1])                          # extract grid parameter at the y-axis    
    Nz = int(NS[2])                          # extract grid parameter at the y-axis     
    dx = RES[0]                              # extract resolution parameter at the x-axis
    dy = RES[1]                              # extract resolution parameter at the y-axis
    dz = RES[2]                              # extract resolution parameter at the y-axis
    
    if k is None:                            # Define default indicent wave (k is only needed for periodic boundary conditions)
        k_incident = np.zeros(3)

    M = int(Nx * Ny * Nz)                         # Matrix size

    #BUILD DEX
    if Nx==1:
        DEx = -1j * k_incident[0] * np.eye(M)
    else:
        d0 = - np.ones(M)
        d1 = np.ones(M - 1)
        d1[range(Nx - 1, M - 1, Nx)] = 0
        DEx = (1 / dx) * diags([d0, d1], [0, 1])  
        
    #BUILD DEY    
    if Ny == 1:
        DEy = -1j * k_incident[1] * np.eye(M)
    else:
        d0 = - np.ones(M)
        d1 = np.ones(int(M - Nx))
        for i in range(Nx):
            d1[range(Nx*(Ny-1) + i, M - (Ny-1)*Nx, (Ny-1)*Nx+Nx) ] = 0           
        DEy = (1 / dy) * diags([d0, d1], [0, Nx])

    # BUILD DEZ
    if Nz == 1:
        DEz = -1j * k_incident[2] * np.eye(M)
    else:
        d0 = - np.ones(M)
        d1 = np.ones(M - Nx*Ny)
        DEz = (1 / dx) * diags([d0, d1], [0, Nx*Ny])               
        

    DHx = - DEx.transpose()
    DHy = - DEy.transpose()
    DHz = - DEz.transpose()

    DEx = csc_matrix(DEx)
    DEy = csc_matrix(DEy)
    DEz = csc_matrix(DEz)
    DHx = csc_matrix(DHx)
    DHy = csc_matrix(DHy)
    DHz = csc_matrix(DHz)

    
    return DEx, DEy, DEz, DHx, DHy, DHz


def calcpml3d(grid_size, PML):
    
    # PML[pml_xmin, pml_xmax, pml_ymin, pml_ymax, pml_zmin, pml_zmax]
    
    Nx = grid_size[0]
    Ny = grid_size[1]
    Nz = grid_size[2]
    
    NXLO = PML[0]*2
    NXHI = PML[1]*2
    NYLO = PML[2]*2
    NYHI = PML[3]*2
    NZLO = PML[4]*2
    NZHI = PML[5]*2
    
    # DEFINE PML PARAMETERS
    amax = 4
    cmax = 1
    p    = 3

    Nx2 = 2*Nx
    Ny2 = 2*Ny
    Nz2 = 2*Nz
    
    
    # INITIALIZE PML PARAMETERS TO PROBLEM SPACE
    sx = np.ones((Nx2,Ny2,Nz2), dtype=np.csingle)
    sy = np.ones((Nx2,Ny2,Nz2), dtype=np.csingle)
    sz = np.ones((Nx2,Ny2,Nz2), dtype=np.csingle)
    
    for i in range(NXLO):
        ax = 1 + (amax - 1) * ((i + 1) / NXLO) ** p
        cx = cmax * np.sin(0.5 * np.pi * (i + 1) / NXLO) ** 2
        sx[int(NXLO - (i + 1)), :] = ax * (1 - 1j * 60 * cx)    
    
    for i in range(NXHI):
        ax = 1 + (amax - 1) * ((i + 1) / NXHI) ** p
        cx = cmax * np.sin(0.5 * np.pi * (i + 1) / NXHI) ** 2
        sx[int(Nx2 - NXHI + i), :] = ax * (1 - 1j * 60 * cx)
    
    # Add YLO PML
    for i in range(NYLO):
        ay = 1 + (amax - 1) * ((i + 1) / NYLO) ** p
        cy = cmax * np.sin(0.5 * np.pi * (i + 1) / NYLO) ** 2
        sy[:, int(NYLO - (i + 1))] = ay * (1 - 1j * 60 * cy)
    
    # Add YHI PML
    for i in range(NYHI):
        ay = 1 + (amax - 1) * ((i + 1) / NYHI) ** p
        cy = cmax * np.sin(0.5 * np.pi * (i + 1) / NYHI) ** 2
        sy[:, int(Ny2 - NYHI + i)] = ay * (1 - 1j * 60 * cy)
    
    for i in range(NZLO):
        az = 1 + (amax - 1) * ((i + 1) / NZLO) ** p
        cz = cmax * np.sin(0.5 * np.pi * (i + 1) / NZLO) ** 2
        sz[:,:,int(NZLO - (i + 1))] = az * (1 - 1j * 60 * cz)    
    
    for i in range(NZHI):
        az = 1 + (amax - 1) * ((i + 1) / NZHI) ** p
        cz = cmax * np.sin(0.5 * np.pi * (i + 1) / NZHI) ** 2
        sz[:,:,int(Nz2 - NXHI + i)] = az * (1 - 1j * 60 * cz)    
        
    sx2 = sx
    sy2 = sy
    sz2 = sz   
    
    # plt.pcolormesh(np.real(sz2[:,:,0]))
    
    sx_ey = (1./sx2[0:Nx2:2,1:Ny2:2,0:Nz2:2])
    sx_ey = sx_ey.flatten('F')
    sx_ey = diags(sx_ey, 0)
    
    sx_ez = (1./sx2[0:Nx2:2,0:Ny2:2,1:Nz2:2])
    sx_ez = sx_ez.flatten('F')
    sx_ez = diags(sx_ez, 0)
    
    sy_ex = (1./sy2[1:Nx2:2,0:Ny2:2,0:Nz2:2])
    sy_ex = sy_ex.flatten('F')
    sy_ex = diags(sy_ex, 0)
    
    sy_ez = (1./sy2[0:Nx2:2,0:Ny2:2,1:Nz2:2])
    sy_ez = sy_ez.flatten('F')
    sy_ez = diags(sy_ez, 0)
    
    sz_ex = (1./sz2[1:Nx2:2,0:Ny2:2,0:Nz2:2])
    sz_ex = sz_ex.flatten('F')
    sz_ex = diags(sz_ex, 0)
    
    sz_ey = (1./sz2[0:Nx2:2,1:Ny2:2,0:Nz2:2])
    sz_ey = sz_ey.flatten('F')
    sz_ey = diags(sz_ey, 0)
    
    sx_hy = (1./sx2[1:Nx2:2,0:Ny2:2,1:Nz2:2])
    sx_hy = sx_hy.flatten('F')
    sx_hy = diags(sx_hy, 0)
    
    sx_hz = (1./sx2[1:Nx2:2,1:Ny2:2,0:Nz2:2])
    sx_hz = sx_hz.flatten('F')
    sx_hz = diags(sx_hz, 0)
    
    sy_hx = (1./sy2[0:Nx2:2,1:Ny2:2,1:Nz2:2])
    sy_hx = sy_hx.flatten('F')
    sy_hx = diags(sy_hx, 0)
    
    sy_hz = (1./sy2[1:Nx2:2,1:Ny2:2,0:Nz2:2])
    sy_hz = sy_hz.flatten('F')
    sy_hz = diags(sy_hz, 0)
    
    sz_hx = (1./sz2[0:Nx2:2,1:Ny2:2,1:Nz2:2])
    sz_hx = sz_hx.flatten('F')
    sz_hx = diags(sz_hx, 0)
    
    sz_hy = (1./sz2[1:Nx2:2,0:Ny2:2,1:Nz2:2])
    sz_hy = sz_hy.flatten('F')
    sz_hy = diags(sz_hy, 0)
        
    
    return sx_ey, sx_ez, sy_ex, sy_ez, sz_ex, sz_ey, sx_hy, sx_hz, sy_hx, sy_hz, sz_hx, sz_hy

def modes(eps, wl, res, nmodes = 1, vertical_stretching = 1):
    ## eps - 3D np.ndaray with shape = (3, Nx, Ny) , 
    ##       cross-section of waveguide with eps_xx, eps_yy, eps_zz 
    ##       components after subpixel averaging
    ## wl - vacuum wavelength [um]
    ## res - resolutin pixels/um
    ## vertical_stretching - dz/dx
    ## 
    ## Returns neff, np.ndarray((6, Nx, Ny)) with 6 field components 
    ## representing mode fields at the same grid as eps
    
    ## order is: 
    # [0,:,:] - E component along the waveguide direction (longitudinal component)
    # [1,:,:] - E component along first axis of eps (first transverse component)
    # [2,:,:] - E component along second axis of eps (second transverse component)
    # [3,:,:] - H component along the waveguide direction (longitudinal component)
    # [4,:,:] - H component along first axis of eps (first transverse component)
    # [5,:,:] - H component along second axis of eps (second transverse component)
    
    ## IMPORTANT: H field components are unrolled to the same positions as E field components
    ## inside Yee cell!!
    ## Ex and Hx are at (0.5, 0, 0)
    ## Ey and Hy are at (0, 0.5, 0)
    ## Ez and Hz are at (0, 0, 0.5)
    
    ## TODO: 
    ## Accept nmodes > 1, and add one more dimension to output arrays representing different modes.
    ## Need to sort the modes over effective index before return...

    def yeeder2d(grid_size, resolution, k=None):
        """
        Function that computes the scipy sparse derivative matrices on the 2D Yee Grid
        Arguments:
            grid_size = two-tuple of the size of the grid
            resolution = two-tuple of the grid resolution (i.e. incremental step)
            k = incident waves
        Returns:
        Derivative matrices with Dirichlet conditions in the x and y direction (DEx, DEy, DHx, DHy)
        """
        # Extracting grid parameters
        Nx = grid_size[0]
        Ny = grid_size[1]
        dx = resolution[0]
        dy = resolution[1]
        
        # Default indicent wave
        if k is None:
            k_incident = np.zeros(2)

        # Matrix size and zero matrix
        M = int(Nx * Ny)

        ### Building DEx
        if Nx == 1:
            DEx = -1j * k_incident[0] * np.eye(M)
        else:
            d0 = - np.ones(M)
            d1 = np.ones(M - 1)
            d1[range(Nx - 1, M - 1, Nx)] = 0
            DEx = (1 / dx) * diags([d0, d1], [0, 1])


        ### Building DEy
        if Ny == 1:
            DEy = -1j * k_incident[1] * np.eye(M)
        else:
            d0 = - np.ones(M)
            d1 = np.ones(int(M - Nx))
            DEy = (1 / dy) * diags([d0, d1], [0, Nx])


        ### Build DHx and DHy
        DHx = - DEx.transpose()
        DHy = - DEy.transpose()

        # Transforming to sparse matrices
        DEx = csc_matrix(DEx)
        DEy = csc_matrix(DEy)
        DHx = csc_matrix(DHx)
        DHy = csc_matrix(DHy)

        return DEx, DEy, DHx, DHy
    
    # Extract tensor elements on yee grid
    ERxx = eps[0,:,:] 
    ERyy = eps[1,:,:]
    ERzz = eps[2,:,:]

    URxx = 1 + eps[0,:,:] * 0
    URyy = 1 + eps[0,:,:] * 0
    URzz = 1 + eps[0,:,:] * 0

    # Flatten arrays column major style
    ERxx = ERxx.flatten('F')
    ERyy = ERyy.flatten('F')
    ERzz = ERzz.flatten('F')
    URxx = URxx.flatten('F')
    URyy = URyy.flatten('F')
    URzz = URzz.flatten('F')

    # Calculating the multiplicative inverse of the permeability and permittivity matrices
    ERxx_i = 1 / ERxx
    ERyy_i = 1 / ERyy
    ERzz_i = 1 / ERzz
    URxx_i = 1 / URxx
    URyy_i = 1 / URyy
    URzz_i = 1 / URzz

    # Creating a Sparse Diagonal and transforming it to an array
    ERxx = diags(ERxx, 0)
    ERyy = diags(ERyy, 0)
    ERzz = diags(ERzz, 0)
    URxx = diags(URxx, 0)
    URyy = diags(URyy, 0)
    URzz = diags(URzz, 0)

    # Creating sparse diagonals of inverses
    ERxx_i = diags(ERxx_i, 0)
    ERyy_i = diags(ERyy_i, 0)
    ERzz_i = diags(ERzz_i, 0)
    URxx_i = diags(URxx_i, 0)
    URyy_i = diags(URyy_i, 0)
    URzz_i = diags(URzz_i, 0)
    
    lam0 = wl
    k0  = 2*np.pi/lam0
    Nx = eps.shape[1]
    Ny = eps.shape[2]
    dx = 1/res
    NS = [Nx, Ny]   # array containing the size of the grid
    RES = [k0*dx, vertical_stretching*k0*dx]
    [DEX,DEY,DHX,DHY] = yeeder2d(NS, RES, k=None)
    
    from scipy.sparse import coo_matrix, bmat
    P = bmat([[DEX @ ERzz_i @ DHY, -(DEX @ ERzz_i @ DHX + URyy)], [DEY @ ERzz_i @ DHY + URxx, -DEY @ ERzz_i @ DHX]])
    Q = bmat([[DHX @ URzz_i @ DEY,  -(DHX @ URzz_i @ DEX + ERyy)], [DHY @ URzz_i @ DEY + ERxx, -DHY @ URzz_i @ DEX]])

    import scipy.sparse.linalg as sla
    
    ev       = - np.max(eps)
    D2, Exy  = sla.eigs(P @ Q, k=nmodes, M=None, sigma=ev)
    D        = D2**0.5
    NEFF     = -1j*diags(D)
    neff = np.real(NEFF.diagonal()[0])
            
    M  = Nx*Ny
    Ex = Exy[0:M, :]
    ex = np.reshape(Ex[:M,0],(Nx, Ny), 'F')
    Ey = Exy[M:2*M,:]
    ey = np.reshape(Ey[:M,0],(Nx, Ny), 'F')
    
    if (np.sum(Ex)<0):  ## flip signs if eig() returned negative Et1 
        ex = -ex
        ey = -ey
    
    Hxy = (Q@Exy)/D[0] 
    Hx  = Hxy[0:M, :]
    Hy  = Hxy[M:2*M,:]

    hx = np.reshape(Hx[:M,0],(Nx, Ny), 'F')
    hy = np.reshape(Hy[:M,0],(Nx, Ny), 'F')

    Ez = ERzz_i @ (DHX@Hy - DHY@Hx)
    Hz = URzz_i @ (DEX@Ey - DEY@Ex)  
    
    ez = np.reshape(Ez[:,0],(Nx, Ny), 'F')
    hz = np.reshape(Hz[:,0],(Nx, Ny), 'F')
    
    ## Restore the original H field from the normalization used in mode solver
    ## Raymond Rumpf's book, Eq. (4.11) Hhat = -1j * h0 * H 
    ##   h0 is vacuum impedance, equal to 1 in meep's units (eps0 = mu0 = 1)
    ##   Mode solver solves for Hhat, we need H, so H = Hhat / (-1j) = 1j H
    hx = 1j*hx
    hy = 1j*hy
    hz = 1j*hz 
    
    # проверка на знак Ht , El    
    #P =  0.5 * np.sum(ex*np.conj(hy) - ey * np.conj(hx))
    P =  0.5 * np.trapz(np.trapz(ex*np.conj(hy) - ey * np.conj(hx), axis=0), axis=0)
    if np.real(P) < 0:   ## Power of the mode = Re(P)
        hx = -hx
        hy = -hy
        ez = -ez    
    ## We always want to return forward propagating mode
    ## If we found that the sign of Poynting vector of the modes is negative, 
    ## it means that eig() and everyrhing below have computed a backward mode.
    ## In this case we need to change the signs according to the symmetry:
    ## Snyder & Love, Optical Waveguide Theory, ch. 11, Eq. (11-7)
    ## 
    ##  e(+) = et(+) + ez(+)*z,  h(+) =   ht(+) + hz(+)*z, 
    ##  e(-) = et(+) - ez(+)*z,  h(-) = - ht(+) + hz(+)*z, 
    ##  beta(-) = - beta(+)
        
    #  Next, make the modes orthonormal:
    ## Normalize it by the N = 0.5 \int E x H* z dA   Eq. (11-12)
    ## N = 0.5 int (ex hy* - ey hx*) dA 
    
    N = np.abs(P)**0.5  ## Eq. (11-15)
    
    if N == 0:
        N = 1
        
    
    ## unroll magnetic fields...
    ## here we use local coordinates, z is wg axis, 
    #                                 x is horizontal cross-section axis (0.5 um), 
    #                                 y is vertical cross-section axis (0.22 um)
    tmphx = 0.5 * (hx  + np.roll(hx, -1, axis = 0))
    tmphx = 0.5 * (tmphx + np.roll(tmphx, +1, axis = 1))
    
    tmphy = 0.5 * (hy + np.roll(hy, +1, axis = 0)) 
    tmphy = 0.5 * (tmphy + np.roll(tmphy, -1, axis = 1))
    
    tmphz = 0.5 * (hz + np.roll(hz, +1, axis = 0))
    tmphz = 0.5 * (tmphz + np.roll(tmphz, +1, axis = 1))
    
    flds = np.zeros((6, Nx, Ny), dtype = complex)
    flds[0,:,:] = ez/N
    flds[1,:,:] = ex/N
    flds[2,:,:] = ey/N
    flds[3,:,:] = tmphz/N #hz/N
    flds[4,:,:] = tmphx/N #hx/N
    flds[5,:,:] = tmphy/N #hy/N
    
    return neff, flds


t1 = time.time()
splitter0 = np.load('eps0.npy')
splitter1 = np.load('eps1.npy')
splitter2 = np.load('eps2.npy')
splitter3 = np.load('eps3.npy')

dxdydz = np.load('dxdydz.npy')

eps_xx = splitter0[0]
eps_yy = splitter0[1]
eps_zz = splitter0[2]

dx = dxdydz[0]
dy = dxdydz[1]
dz = dxdydz[2]

Nx = eps_xx.shape[0]
Ny = eps_xx.shape[1]
Nz = eps_xx.shape[2]

UR = np.ones((Nx,Ny,Nz))

ER_xx = eps_xx.flatten('F')
ER_yy = eps_yy.flatten('F')
ER_zz = eps_zz.flatten('F')

ER_xx = diags(ER_xx, 0)
ER_yy = diags(ER_yy, 0)
ER_zz = diags(ER_zz, 0)

UR = UR.flatten('F')
UR = diags(UR, 0)

# Visualization of splitter epsilon distribution

# plt.pcolormesh(eps_xx[:,:, 30])
# plt.xlabel('Y')
# plt.ylabel('X')
# plt.title('eps0')
# plt.colorbar()
# plt.gca().set_aspect('equal') 

# Define mode source
wl = 1.55        # um 
k0  = 2*np.pi/wl 
source_plane_position =  30  # (10 cells away from the edge of PML)

ER_scr_xx = eps_xx[source_plane_position,:,:]
ER_scr_yy = eps_yy[source_plane_position,:,:]
ER_scr_zz = eps_zz[source_plane_position,:,:]

Nx = ER_scr_xx.shape[0]
Ny = ER_scr_xx.shape[1]

res = int(1/dx)         # pxls/um

eps = np.zeros((3, Nx, Ny))
eps[0,:,:] = ER_scr_xx    ## xx component
eps[1,:,:] = ER_scr_yy    ## yy component
eps[2,:,:] = ER_scr_zz    ## zz component

neff, f = modes(eps, wl, res)

ex = f[0,:,:]; ey = f[1,:,:]; ez = f[2,:,:]; hx = f[3,:,:]; hy = f[4,:,:]; hz = f[5,:,:]

# Visualization of mode source

# plt.figure()
# plt.subplot(2, 3, 1)
# plt.pcolormesh(np.real(ex))
# plt.title('real(Ex)')
# plt.colorbar()

# plt.subplot(2, 3, 2)
# plt.pcolormesh(np.real(ey))
# plt.title('real(Ey)')
# plt.yticks(fontsize = 0)
# plt.colorbar()

# plt.subplot(2, 3, 3)
# plt.pcolormesh(np.real(ez))
# plt.title('real(Ez)')
# plt.yticks(fontsize = 0)
# plt.colorbar()

# plt.figure()
# plt.subplot(2, 3, 1)
# plt.pcolormesh(np.imag(ex))
# plt.title('imag(Ex)')
# plt.colorbar()

# plt.subplot(2, 3, 2)
# plt.pcolormesh(np.imag(ey))
# plt.title('imag(Ey)')
# plt.yticks(fontsize = 0)
# plt.colorbar()

# plt.subplot(2, 3, 3)
# plt.pcolormesh(np.imag(ez))
# plt.title('imag(Ez)')
# plt.yticks(fontsize = 0)
# plt.colorbar()
# plt.show()

# plt.figure()
# plt.subplot(2, 3, 1)
# plt.pcolormesh(np.real(hx))
# plt.title('real(Hx)')
# plt.colorbar()

# plt.subplot(2, 3, 2)
# plt.pcolormesh(np.real(hy))
# plt.title('real(Hy)')
# plt.yticks(fontsize = 0)
# plt.colorbar()

# plt.subplot(2, 3, 3)
# plt.pcolormesh(np.real(hz))
# plt.title('real(Hz)')
# plt.yticks(fontsize = 0)
# plt.colorbar()

# plt.figure()
# plt.subplot(2, 3, 1)
# plt.pcolormesh(np.imag(hx))
# plt.title('imag(Hx)')
# plt.colorbar()

# plt.subplot(2, 3, 2)
# plt.pcolormesh(np.imag(hy))
# plt.title('imag(Hy)')
# plt.yticks(fontsize = 0)
# plt.colorbar()

# plt.subplot(2, 3, 3)
# plt.pcolormesh(np.imag(hz))
# plt.title('imag(Hz)')
# plt.yticks(fontsize = 0)
# plt.colorbar()
# plt.show()

Nx = eps_xx.shape[0]
Ny = eps_xx.shape[1]
Nz = eps_xx.shape[2]

Jx_grid = np.zeros((Nx,Ny,Nz), dtype=np.complex64)

Jy_grid = np.zeros((Nx,Ny,Nz), dtype=np.complex64)
Jy_grid[source_plane_position,:,:] = -hz 

Jz_grid = np.zeros((Nx,Ny,Nz), dtype=np.complex64)
Jz_grid[source_plane_position,:,:] = hy 

Jx_flat = Jx_grid.flatten('F') 
Jy_flat = Jy_grid.flatten('F') 
Jz_flat = Jz_grid.flatten('F') 

fsrc_flat  =np.concatenate((Jx_flat, Jy_flat, Jz_flat), dtype=np.complex64)

NS  = np.array([Nx, Ny, Nz])
RES = np.array([dx, dy, dz])
DEX,DEY,DEZ,DHX,DHY,DHZ = yeeder3d(NS,k0*RES)

PML = np.array([20, 20, 20, 20, 6, 6])
sx_ey, sx_ez, sy_ex, sy_ez, sz_ex, sz_ey, sx_hy, sx_hz, sy_hx, sy_hz, sz_hx, sz_hy  = calcpml3d(NS, PML)

print('time for geometry and mode source definition: ', time.time()-t1)

t2 = time.time()
M = Nx*Ny*Nz
ZZ = csc_matrix((M, M))

EPS = bmat([[ER_xx, ZZ, ZZ],
               [ZZ, ER_yy, ZZ],
               [ZZ, ZZ, ER_zz]], dtype=np.complex64)

MUR = bmat([[UR, ZZ, ZZ],
               [ZZ, UR, ZZ],
               [ZZ, ZZ, UR]], dtype=np.complex64)

CE = bmat([[ZZ, -sz_hx*DEZ, sy_hx*DEY],
               [sz_hy*DEZ, ZZ, -sx_hy*DEX],
               [-sy_hz*DEY, sx_hz*DEX, ZZ]], dtype=np.complex64)

CH = bmat([[ZZ, -sz_ex*DHZ, sy_ex*DHY],
               [sz_ey*DHZ, ZZ, -sx_ey*DHX],
               [-sy_ez*DHY, sx_ez*DHX, ZZ]], dtype=np.complex64)

Ae0 = CH@CE - EPS

print('\nsplitter 0 ')
print('time for scipy A matrix assembling: ', time.time()-t2)

t3 = time.time()
A0 = PETSc.Mat().createAIJ(size=Ae0.shape, nnz=1,
                                  csr=(Ae0.indptr, Ae0.indices,
                                       Ae0.data))

A0.setType('aijcusparse')
A0.assemble()

x0, b = A0.getVecs()
x0.set(0)

b.setArray(fsrc_flat)

ksp = PETSc.KSP().create(PETSc.COMM_WORLD)
ksp.setOperators(A0)
ksp.setType('fgmres')
ksp.setGMRESRestart(20)
ksp.setTolerances(rtol=0.01)
ksp.getIterationNumber()
ksp.setConvergenceHistory()
ksp.setFromOptions()

ksp.setInitialGuessNonzero(True)
ksp.getPC().setType('none')

print('time for petsc A matrix assembling: ', time.time()-t3)

t4 = time.time()

ksp.solve(b, x0)

print('time for Ax = b solving: ', time.time() - t4)

residuals0 = ksp.getConvergenceHistory()
iter_num0 = ksp.getIterationNumber()
print('iteration number of splitter0: ',iter_num0)

# %%
eps_xx = splitter1[0]
eps_yy = splitter1[1]
eps_zz = splitter1[2]

ER_xx = eps_xx.flatten('F')
ER_yy = eps_yy.flatten('F')
ER_zz = eps_zz.flatten('F')

ER_xx = diags(ER_xx, 0)
ER_yy = diags(ER_yy, 0)
ER_zz = diags(ER_zz, 0)

t2 = time.time()

EPS = bmat([[ER_xx, ZZ, ZZ],
               [ZZ, ER_yy, ZZ],
               [ZZ, ZZ, ER_zz]], dtype=np.complex64)

Ae1 = CH@CE - EPS

print('\nsplitter1')
print('time for scipy A matrix assembling: ', time.time()-t2)

t3 = time.time()
A1 = PETSc.Mat().createAIJ(size=Ae1.shape, nnz=1,
                                  csr=(Ae1.indptr, Ae1.indices,
                                       Ae1.data))

A1.setType('aijcusparse')
A1.assemble()

print('time for petsc A matrix assembling: ', time.time()-t3)

t4 = time.time()
ksp.setOperators(A1)
ksp.setTolerances(rtol=0.001)
ksp.solve(b, x0)

print('time for Ax = b solving: ', time.time()-t4)
iter_num1 = ksp.getIterationNumber()
residuals1 = ksp.getConvergenceHistory()
print('iteration number of splitter1: ',iter_num1)

eps_xx = splitter2[0]
eps_yy = splitter2[1]
eps_zz = splitter2[2]

ER_xx = eps_xx.flatten('F')
ER_yy = eps_yy.flatten('F')
ER_zz = eps_zz.flatten('F')

ER_xx = diags(ER_xx, 0)
ER_yy = diags(ER_yy, 0)
ER_zz = diags(ER_zz, 0)

t2 = time.time()

EPS = bmat([[ER_xx, ZZ, ZZ],
               [ZZ, ER_yy, ZZ],
               [ZZ, ZZ, ER_zz]], dtype=np.complex64)

Ae2 = CH@CE - EPS

print('\nsplitter2')
print('time for scipy A matrix assembling: ', time.time()-t2)

t3 = time.time()
A2 = PETSc.Mat().createAIJ(size=Ae2.shape, nnz=1,
                                  csr=(Ae2.indptr, Ae2.indices,
                                       Ae2.data))

A2.setType('aijcusparse')
A2.assemble()

print('time for petsc A matrix assembling: ', time.time()-t3)


s4 = time.time()
ksp.setOperators(A2)
ksp.setTolerances(rtol=0.0001)
ksp.solve(b, x0)

t4 = time.time()-s4
print('time for Ax = b solving: ', t4)
iter_num2 = ksp.getIterationNumber()
residuals2 = ksp.getConvergenceHistory()
print('iteration number of splitter2: ',iter_num2)

eps_xx = splitter3[0]
eps_yy = splitter3[1]
eps_zz = splitter3[2]

ER_xx = eps_xx.flatten('F')
ER_yy = eps_yy.flatten('F')
ER_zz = eps_zz.flatten('F')

ER_xx = diags(ER_xx, 0)
ER_yy = diags(ER_yy, 0)
ER_zz = diags(ER_zz, 0)

t2 = time.time()

EPS = bmat([[ER_xx, ZZ, ZZ],
               [ZZ, ER_yy, ZZ],
               [ZZ, ZZ, ER_zz]], dtype=np.complex64)

Ae3 = CH@CE - EPS

print('\nsplitter3')
print('time for scipy A matrix assembling: ', time.time()-t2)

t3 = time.time()
A3 = PETSc.Mat().createAIJ(size=Ae3.shape, nnz=1,
                                  csr=(Ae3.indptr, Ae3.indices,
                                       Ae3.data))

A3.setType('aijcusparse')
A3.assemble()

print('time for petsc A matrix assembling: ', time.time()-t3)

t4 = time.time()
ksp.setOperators(A3)
ksp.setTolerances(rtol=0.00001)
ksp.solve(b, x0)

print('time for Ax = b solving: ', time.time()-t4)
iter_num3 = ksp.getIterationNumber()
residuals3 = ksp.getConvergenceHistory()
print('iteration number of splitter3: ',iter_num3)

plt.figure()
plt.loglog(residuals0, color='blue', label='splitter 0')
plt.loglog(residuals1[residuals0.size:], color='red', label='splitter 1')
plt.loglog(residuals2[residuals1.size:], color='green', label='splitter 2')
plt.loglog(residuals3[residuals2.size:], color='orange', label='splitter 3')
plt.axhline(y = 0.01, color = 'b', linestyle = 'dashed')
plt.axhline(y = 0.001, color = 'r', linestyle = 'dashed')
plt.axhline(y = 0.0001, color = 'g', linestyle = 'dashed')
plt.axhline(y = 0.00001, color = 'orange', linestyle = 'dashed')
plt.title('residual')
plt.xlabel('Iteration numbers')
plt.legend()
plt.show()

# Result visualization

fEx1 = x0[0:M]
fEy1 = x0[M:2*M]
fEz1 = x0[2*M:3*M]

Ex1 = np.reshape(fEx1, (Nx, Ny, Nz), 'F')
Ey1 = np.reshape(fEy1, (Nx, Ny, Nz), 'F')
Ez1 = np.reshape(fEz1, (Nx, Ny, Nz), 'F')

plt.figure()
plt.subplot(2, 3, 1)
plt.imshow(eps_xx[:,:, 30])
plt.xlabel('Y')
plt.ylabel('X')
plt.title('splitter', fontsize = 10)
plt.colorbar()
plt.gca().set_aspect('equal') 
plt.show()

plt.figure()
plt.subplot(2, 3, 1)
plt.imshow(np.real(Ex1[:,:,30]))
plt.title('np.real(Ex)')
plt.colorbar()

plt.subplot(2, 3, 2)
plt.imshow(np.real(Ey1[:,:,30]))
plt.title('np.real(Ey)')
plt.yticks(fontsize = 0)
plt.colorbar()

plt.subplot(2, 3, 3)
plt.imshow(np.real(Ez1[:,:,30]))
plt.title('np.real(Ez)')
plt.yticks(fontsize = 0)
plt.colorbar()
plt.show()

plt.figure()
plt.subplot(2, 3, 1)
plt.imshow(np.imag(Ex1[:,:,30]))
plt.title('np.imag(Ex)')
plt.colorbar()

plt.subplot(2, 3, 2)
plt.imshow(np.imag(Ey1[:,:,30]))
plt.title('np.imag(Ey)')
plt.yticks(fontsize = 0)
plt.colorbar()

plt.subplot(2, 3, 3)
plt.imshow(np.imag(Ez1[:,:,30]))
plt.title('np.imag(Ez)')
plt.yticks(fontsize = 0)
plt.colorbar()
plt.show()

# %%
