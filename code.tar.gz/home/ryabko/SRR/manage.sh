#!/bin/bash

folder=("BIM_2D_Waveguide" "BIM_TM_2D" "FDFD_3D" "DIE" "GPU_FDTD" "FDFD" "Mode_Solver" "emopt" "LWIR_RCWA_PSF" "Meta-atom-of-metalens-MEEP-" "Optimization_Model" "metalens-intensity-optimizer" "aSi_absorber_rcwa" "Full_LWIR_Simulation" "metalens_inverse" "SPICE_cell" "SPICE_readout" "Meta-atom_gRCWA" "Image_construction" "NETD_calculation")
folder1=("MEEP" "AutoDiff" "CMath" "Interleaver")


for var in ${folder[@]}
do
git clone https://m.ryabko:Chango2015%21@github.sec.samsung.net/LWIR/$var
done

for var in ${folder1[@]}
do
cp -r ~/$var ~/SRR/$var
done
tar czf code.tar.gz ~/SRR
#git clone https://m.ryabko:Chango2015%21@github.sec.samsung.net/LWIR/BIM_TM_2D

#git remote set-url origin https://ryabkomv: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@github.com/Ryabkomv/Code.git

#git init
#git add code.tar.gz
#git commit -m "first"
#git remote add origin https://ryabkomv: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@github.com/Ryabkomv/Code.git
#git config --global https.postBuffer 2097152000
#git push --set-upstream origin master
#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
