##### imports & initial params

from pathlib import Path
# import autograd.numpy as np
# import matplotlib.pyplot as plt
import os
from gds_decomp import gds2npy
from params import *
from primitives import *
import pandas as pd
import pickle
import time

# RCWA

nG_max = nG_max_grid #
home_path = os.path.expanduser("~")
# thickness in [um], area in [um**2] units
layers_descr = {'10':{'material':'Al', 'area':102.688, 'thickness':0.1},
               '11':{'material':'Al', 'area':14.4, 'thickness':0.1},
               '12':{'material':'Al', 'area':14.4, 'thickness':0.1},
               '20':{'material':'TiN', 'area':1.566, 'thickness':0.1e-4},
               '21':{'material':'TiN', 'area':0.783, 'thickness':2.25},
               '22':{'material':'TiN', 'area':0.783, 'thickness':2.55},
               '30':{'material':'SiO2', 'area':1.924, 'thickness':2.25},
               '45':{'material':'TiN', 'area':113.7, 'thickness':0.04},
               '80':{'material':'aSi', 'area':113.7, 'thickness':0.2},
               '80 top diel':{'material':'SiO2', 'area':113.7, 'thickness':0.15},
               '80 bottom diel':{'material':'SiO2', 'area':113.7, 'thickness':0.15},
               'air':{'material':'air', 'area':113.7, 'thickness':2}}

# pixel_model = {'struct_file': home_path + '/Desktop/LWIR/28-11-2023_17-27-51/RCWA_PSF_3/data_comsol/pixels_edited_x.gds',
#                 'cell': 'FINGER_05' }

pixel_model = {'struct_file': home_path + '/Desktop/LWIR_2023_Project/System Design/PSF-construction-demo/RCWA_PSF_3/data_comsol/pixels_edited_x.gds',
                'cell': 'FINGER_05' }

gds_file = pixel_model['struct_file']
gds_cell_prefix = pixel_model['cell'].lower()

# this function returns actual phase of the spherical wavefront from wavelength, focal length and angle of incidence
get_phi = lambda theta: (-2*np.pi/(wvl*1e-6))*(np.sqrt((f*np.tan(np.pi*theta/180))**2 + f**2) - f)

###### loading masks from gds-file
gds_all = gds2npy(gds_file, Nx, Ny) # all cells are loaded
print(gds_file)
# keys filtering
masks = {}
for k, v in gds_all.items():
    if k.startswith(gds_cell_prefix):
        layer_name = k.replace(gds_cell_prefix+'-','')
        masks[layer_name] = v

# masks['80'] = np.ones((Nx, Ny))

##### constructing RCWA model

# Table of layers:
#_________________________________________________________________________________
# no. | z_from | z_to   | thick  | materials
# ----|--------| -------| ------ |------------------------------------------------
#  0  | 0.00μm | 0.00μm | 0.00μm | Air [input]
#  1  | 0.00μm | 0.15μm | 0.15μm | SiO2 (passivation)
#  2  | 0.15μm | 0.22μm | 0.07μm | a-Si
#  3  | 0.22μm | 0.25μm | 0.03μm | TiN (electrodes) + a-Si
#  4  | 0.25μm | 0.40μm | 0.15μm | SiO2 (support) + TiN (anchors)
#  5  | 0.40μm | 2.40μm | 2.00μm | Air (gap) + SiO2 (posts) + TiN (anchors 1&2)
#  6  | 2.40μm | 2.50μm | 0.10μm | SiO2 (base) + TiN (anchors 1&2)
#  7  | 2.50μm | 2.60μm | 0.10μm | SiO2 (base) + Al (electrode 2) + TiN (anchor 2)
#  8  | 2.60μm | 2.70μm | 0.10μm | SiO2 (base) + Al (mirror) + TiN (anchor 1)
#  9  | 2.70μm | 2.80μm | 0.10μm | SiO2 (base) + TiN (anchor 1)
# 10  | 2.80μm | 2.90μm | 0.10μm | SiO2 (base) + Al (electrode 1)
# 11  | 2.90μm | 3.00μm | 0.10μm | SiO2 (base)
#---------------------------------------------------------------------------------

# grids are wavelength-dependent and stacked as follows:
# eps_grid = [[eps_xy_wl0], ..., [eps_xy_wlN]]
# !!! Air as surrounding medium in layers no. 1-5, and SiO2 in layers no. 6-11

# layer no. 1: Air (input)
# no need in construction

epsAl = 10000 # some big number; TODO: replace by actual value

# layer no. 1: SiO2 (passivation)
epsSiO2Passivation_grid_range = np.array([
    masks['80'] * epsSiO2 for epsSiO2 in epsSiO2_range
])
epsSiO2Passivation_grid_range[epsSiO2Passivation_grid_range == 0] = epsAir

# layer no. 2: a-Si
epsSi_grid_range = np.array([
    masks['80'] * epsSi for epsSi in epsSi_range
])
epsSi_grid_range[epsSi_grid_range == 0] = epsAir

# layer no. 3: TiN (electrodes) + a-Si
epsTiN_grid_range = np.array([
    masks['45'] * epsTiN + (masks['80']-masks['45']) * epsSi
    for epsTiN, epsSi in np.stack([epsTiN_range, epsSi_range]).T
])
epsTiN_grid_range[epsTiN_grid_range == 0] = epsAir

# layer no. 4: SiO2 (support) + TiN (anchors)
epsSiO2Support_grid_range = np.array([
    (masks['80']-masks['20']) * epsSiO2 + masks['20'] * epsTiN
    for epsSiO2, epsTiN in np.stack([epsSiO2_range, epsTiN_range]).T
])
epsSiO2Support_grid_range[epsSiO2Support_grid_range == 0] = epsAir

# layer no. 5: Air (gap) + SiO2 (posts) + TiN (anchors 1&2)
epsAirGap_grid_range = np.array([
    masks['20'] * epsTiN + (masks['30']-masks['20']) * epsSiO2
    for epsTiN, epsSiO2 in np.stack((epsTiN_range, epsSiO2_range)).T
])
epsAirGap_grid_range[epsAirGap_grid_range == 0] = epsAir

# layer no. 6: SiO2 (base) + TiN (anchors 1&2)
epsSiO2BaseTiNAnchors_grid_range = []
for epsTiN, epsSiO2 in np.stack((epsTiN_range, epsSiO2_range)).T:
    eps_xy = masks['20'] * epsTiN
    eps_xy[eps_xy == 0] = epsSiO2
    epsSiO2BaseTiNAnchors_grid_range.append(eps_xy)
epsSiO2BaseTiNAnchors_grid_range = np.array(epsSiO2BaseTiNAnchors_grid_range)

# layer no. 7: SiO2 (base) + Al (electrode 2) + TiN (anchor 2)
epsSiO2BaseAlElectrode2_grid_range = []
for epsTiN, epsSiO2 in np.stack((epsTiN_range, epsSiO2_range)).T:
    eps_xy = masks['20'] * epsTiN
    eps_xy[:Nx//2,:Ny//2] = 0
    eps_xy += masks['11'] * epsAl
    eps_xy[eps_xy == 0] = epsSiO2
    epsSiO2BaseAlElectrode2_grid_range.append(eps_xy)
epsSiO2BaseAlElectrode2_grid_range = np.array(epsSiO2BaseAlElectrode2_grid_range)

# layer no. 8: SiO2 (base) + Al (mirror) + TiN (anchor 1)
epsSiO2BaseAlMirror = []
for epsTiN, epsSiO2 in np.stack((epsTiN_range, epsSiO2_range)).T:
    eps_xy = masks['20'] * epsTiN
    eps_xy[:Nx//2,:Ny//2] = 0
    eps_xy += masks['10'] * epsAl
    eps_xy[eps_xy == 0] = epsSiO2
    epsSiO2BaseAlMirror.append(eps_xy)
epsSiO2BaseAlMirror = np.array(epsSiO2BaseAlMirror)

# layer no. 9: SiO2 (base) + TiN (anchor 1)
epsSiO2TiNAnchor1_grid_range = []
for epsTiN, epsSiO2 in np.stack((epsTiN_range, epsSiO2_range)).T:
    eps_xy = masks['20'] * epsTiN
    eps_xy[:Nx//2,:Ny//2] = 0
    eps_xy[eps_xy == 0] = epsSiO2
    epsSiO2TiNAnchor1_grid_range.append(eps_xy)
epsSiO2TiNAnchor1_grid_range = np.array(epsSiO2TiNAnchor1_grid_range)

# layer no. 10: SiO2 (base) + Al (electrode 1)
epsSiO2BaseAlElectrode1_grid_range = []
for epsSiO2 in epsSiO2_range:
    eps_xy = np.zeros((Ny,Nx),dtype=complex)
    eps_xy[:,:] = masks['12'] * epsAl
    eps_xy[eps_xy == 0] = epsSiO2
    epsSiO2BaseAlElectrode1_grid_range.append(eps_xy)
epsSiO2BaseAlElectrode1_grid_range = np.array(epsSiO2BaseAlElectrode1_grid_range)

##### params

max_angle = 26.5              # maximal angle of incidence - 26.5 for NA = 0.45
n_angles = 15                 # number of plane waves is odd - (+theta and -theta and 1 plane wave for normal incidence)

azim_deg_list = [10*i for i in range(18)]
theta_list = np.linspace(-max_angle, max_angle, n_angles)

# phi_list = [get_phi(theta) for theta in theta_list]   # phase additions for each of incident plane waves

counter = 0
total_steps = len(wl_range) * len(theta_list) * len(azim_deg_list)

for wvl_i in range(len(wl_range)):
    
    # introduction of amplitude list required for plane wave expansion
    f = 3e-3
    ampl_list = [get_corr_ampl(wl_range[wvl_i], f, i) for i in np.abs(theta_list)]    # amplitude mutiplication factors for each of incident plane waves (are obtained from power spectrum of the spherical wave)

    # layers parameters: number, thickness, epsilon
    
    layers = [
        ['0',  0.00,                 epsAir],
        ['1',  layers_descr['80 top diel']['thickness'], epsSiO2Passivation_grid_range[wvl_i]],
        ['2',  layers_descr['80']['thickness'], epsSi_grid_range[wvl_i]],
        ['3',  layers_descr['45']['thickness'], epsTiN_grid_range[wvl_i]],
        ['4',  layers_descr['80 bottom diel']['thickness'], epsSiO2Support_grid_range[wvl_i]],
        ['5',  layers_descr['air']['thickness'], epsAirGap_grid_range[wvl_i]],
        ['6',  0.10, epsSiO2BaseTiNAnchors_grid_range[wvl_i]],
        ['7',  0.10, epsSiO2BaseAlElectrode2_grid_range[wvl_i]],
        ['8',  0.10, epsSiO2BaseAlMirror[wvl_i]],
        ['9',  0.10, epsSiO2TiNAnchor1_grid_range[wvl_i]],
        ['10', 0.10, epsSiO2BaseAlElectrode1_grid_range[wvl_i]],
        ['11', 0.10, epsSiO2_range[wvl_i]],
    ]
    
    for i_ in range(0, len(layers)):
        if type(layers[i_][2]) is np.ndarray:
            layers[i_][2] = np.transpose(layers[i_][2])
    
    df = pd.DataFrame(columns = azim_deg_list, index = theta_list) # dataframe for storing data
   
    for phi_deg in azim_deg_list:
        for theta_deg in theta_list: 
            
            # ampl_value from array
            index_th = int(np.where(theta_list == theta_deg)[0])
            # index_th = 0
            
            P_wave['s_phase'] = 0
            P_wave['p_phase'] = 0
            P_wave['s_amp'] = ampl_list[index_th] * (np.cos(np.pi * phi_deg / 180))
            P_wave['p_amp'] = ampl_list[index_th] * (np.sin(np.pi * phi_deg / 180)) / np.cos(np.pi * theta_deg / 180)
            
            s1 = time.time()                           
            print('getting rcwa object...')
            obj, eps_grid = grcwa_RTA(nG_max, Lx, Ly, wl_range[wvl_i], theta_deg, phi_deg,
                        layers, P_wave, return_obj=True, Gmethod = 1)
            print('rcwa object formed', time.time() - s1)
            counter+=1
            Ef, Hf = obj.Solve_FieldFourier(which_layer = 0, z_offset = 0)
            
            print(f'components have been found...', time.time() - s1)
            print(f'current progress: {100*counter/total_steps:.1f}%')
            kx, ky = obj.kx, obj.ky            
            df.loc[theta_deg][phi_deg] = [Ef, kx, ky]   
    data_full[wl_range[wvl_i]] = df  

# save data

descr = 'test_field_1x1_short'
# df.to_pickle(descr)

with open(descr, 'wb') as f:
    pickle.dump(data_full, f)


