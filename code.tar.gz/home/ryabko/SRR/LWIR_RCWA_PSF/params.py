'''
This file contains parameters of a models.

'''

import autograd.numpy as np
from pathlib import Path
from materials import Si_eps, SiO2_eps, TiN_eps

##!!! Are these paths used??
data_dir = Path('data') # where to save data
save_dir = Path('output')
gds_file = data_dir.joinpath('pixels.gds')
fig_dpi = 300           # default resolution for matplotib figures

##### min/max wavelengths range

wl_min = 8.1    # min. wavelength
wl_max = 11.9   # max. wavelength
Nwl = 5        # number of wavelengths in the range
wl_range = np.linspace(wl_min,wl_max,Nwl)

##### materials

# constant epsilons
epsAir        = 1.0
epsAl         = -1e10 # TODO: use the range from metal_eps()

# wavelength-dependent epsilons
epsSi_range   = Si_eps(wl_range)
epsSiO2_range = SiO2_eps(wl_range)
epsTiN_range  = TiN_eps(wl_range)

##### gRCWA model params

nG_max_unif = 50   # uniform layers model: max. number of Fourier expansion orders in XY plane
nG_max_grid = 500  # the same for a grid layers (gds) model

Lx = 12
Ly = 12

# Nx = Ny = 120      # points along x and y axes for patterned layers
Nx = 100
Ny = 100

# angles of planewave incidence
phi_deg = 0.0                      # azimuthal angle theta in [0,360)
phi_rad = phi_deg * np.pi/180      # degrees to radians
theta_deg = 0.0                    # polar angle phi in [0,180)
theta_rad = theta_deg * np.pi/180  # degrees to radians

# P-polarized wave (electric field along x axis if normally incident planewave)
# !!! P_wave is used by default in RCWA model
P_wave = {
    'p_amp':     1.0,
    'p_phase':   0.0,
    's_amp':     0.0,
    's_phase':   0.0,
    'order':     0,
    'direction': 'forward'
}

# S-polarized wave (electric field along y axis if normally incident planewave)
S_wave = {
    'p_amp':     0.0,
    'p_phase':   0.0,
    's_amp':    -1.0, # negative sign is for initial phase zeroing while simulations
    's_phase':   0.0,
    'order':     0,
    'direction': 'forward'
}
