'''
This file contains basic functions.

'''

import sys
import grcwa
grcwa.set_backend('autograd') # this is needed for gradients calculations
import autograd.numpy as np   # it's essential to use NumPy from autograd everywhere
import matplotlib.pyplot as plt
from params import *

def grcwa_RTA(nG_max: int,
              Lx: float,
              Ly: float,
              wl: float,
              theta_deg: float,
              phi_deg: float,
              layers: list,
              planewave_params: dict = S_wave,
              Gmethod: int = 1,
              return_obj: bool = False,
              ) -> tuple:
    
    '''
    Basic function for pixel construction with gRCWA. This function takes a set of parameters
    and returns reflection, transmission, and absorption coefficients.

    Parameters
    ----------
    nG_max: int
        max. truncation order
    Lx: float
        length of a lattice vector along x axis
    Lx: float
        length of a lattice vector along y axis
    wl: float
        wavelength of an incident plane wave
    theta_deg: float
        polar angle of an incident planewave in degrees
    phi_deg: float
        azimuthal angle of an incident planewave in degrees
    layers: list
        parameters of layers: [[label0,thick0,eps0], ..., [labelN,thickN,epsN]]
    planewave_params: dict
        amplitudes and phases for an excited plane wave
    Gmethod:
        Fourier space truncation options: 0 for circular, 1 for rectangular
    return_obj: bool
        if True model's class to be returned  
    
    Returns
    -------
    obj - rcwa object, 
    eps_grid - dielectric permittivity of the structure
    '''
    
    assert len(layers) > 0, 'Non-empty list of layers should be defined.'
    assert type(layers[0][2]) in [int, float, complex], 'The first layer should be uniform!'

    freq = 1./wl + 1j*1e-20 # small Im part is to avoid singular matrix

    theta_rad = theta_deg * np.pi/180
    phi_rad = phi_deg * np.pi/180
    
    # setting up RCWA on rectangular grid
    obj = grcwa.obj(nG_max, [Lx,0.], [0.,Ly], freq, theta_rad, phi_rad, verbose=0)

    eps_grid = []
    # contructing layers stack
    for label, thick, eps in layers:
        if isinstance(eps, (int, float, complex)):
            obj.Add_LayerUniform(thick, eps) # uniform layer
            # print(f'layer {label} is uniform')
        elif isinstance(eps, np.ndarray):
            Nx, Ny = eps.shape
            eps = np.roll(eps, int(Nx/2), 0)
            eps = np.roll(eps, int(Ny/2), 1)
            # print(f'eps is array: Nx {Nx}, Ny: {Ny}')
            obj.Add_LayerGrid(thick, Nx, Ny) # patterned layer
            eps_grid.append(eps.flatten())
        else:
            raise Exception(f'Incorrect eps type in "{label}" layer: {type(eps)}')
    
    obj.Init_Setup(Gmethod=Gmethod)
    obj.MakeExcitationPlanewave(**planewave_params)

    if len(eps_grid) > 0:
        obj.GridLayer_geteps(np.concatenate(eps_grid))
    
    return obj, eps_grid

# the function

def find_nearest(array,value):
    """
    the function returns index of the array's element with value closest to the given one
    """
    array[np.isnan(array)] = 90
    diff_arr = np.abs(array - value * np.ones(len(array)))
    result = np.where(diff_arr == min(diff_arr))[0]
    return result[0].astype(int)

def get_corr_ampl(wvl, f, theta):
    """
    the function returns amplitude of the plane wave corrected with taking into account Fourier ampltide
    """
    num_x = 8192
    x = np.linspace(-3e-3, 3e-3, num_x)
    ampl = np.asarray(np.where(np.abs(x) > 1.5e-3, 0, 1))
    wavelength = wvl*1e-6
    phi = (-2*np.pi/wavelength)*(np.sqrt(x**2 + f**2) - f)
    
    dx = (x[-1] - x[0])/num_x
    fx = np.linspace(-1/(2*dx), 1/(2*dx), num_x)
    
    field = ampl * np.exp(1j * phi)
    
    # generate set of K vectors

    k0 = 2 * np.pi / wavelength
    kx = 2* np.pi * fx
    angles_deg = (180 / np.pi) * np.arcsin(kx/k0)
    
    # get normalized fourier spectrum of the field at the metalens
    
    dftmodo = np.abs(np.fft.fftshift(np.fft.fft(field)))
    dftmodo/=np.max(np.max(dftmodo))
    
    idx = find_nearest(angles_deg, theta)
    
    return dftmodo[idx]**0.5

def get_layer_offset(layers, check_val): 
    """
    the function converts set of layers and depth value to the index of 
    the layer and its z-offset

    """
    cur_thck = 0
    if isinstance(layers, dict): 
        for i in layers:
            cur_thck+= layers[i]
            if check_val < cur_thck:
                cur_layer = i
                z_offset = check_val + layers[i] - cur_thck
                break
    if isinstance(layers, list):
        layers = layers[1:]
        for i in layers:
            cur_thck+= i[1]
            if check_val < cur_thck:
                cur_layer = int(i[0])
                z_offset = check_val + i[1] - cur_thck
                break
    return int(cur_layer), z_offset

