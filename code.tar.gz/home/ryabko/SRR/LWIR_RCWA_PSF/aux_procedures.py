# -*- coding: utf-8 -*-
"""
Created on Mon Dec  4 09:27:29 2023

@author: a.lantsov
"""

import pickle
import numpy as np
import matplotlib.pyplot as plt
from PIL import Image

# function for convolving image with psf selected for different temperatures

def convolution2d(image, kernel_dict):
    first_index = list(kernel_dict.keys())[0]
    m, n = kernel_dict[first_index].shape
    mh = int(0.5 * (m - 1))
    nh = int(0.5 * (n - 1))
    x, y = np.shape(image)
    print(x,y)
    psf_image = np.zeros((x, y))
    restored_image = np.zeros((x, y))

    for i in range(mh, y - mh):
        for j in range(mh, y - mh):
               
            # get an appropriate kernel according to image temperature:
            cur_kernel = kernel_dict[image[i,j]]
            # apply the selected kernel to image
            psf_image = np.zeros((x, y))
            psf_image[i - mh: i + mh + 1, j - mh : j + mh + 1] = cur_kernel
            restored_image = restored_image + psf_image
    return restored_image

# let's create temperature map from test image

T1 = 273
T2 = 273.5

im_pattern = Image.open('test_pattern2.png').convert('L')
arr = np.array(im_pattern)
arr = arr/np.max(arr)
map_x, map_y = np.shape(arr)
temp_map = np.zeros((map_x, map_y))
for i in range(map_x):
    for j in range(map_y):
        if arr[i,j] == 1:
            temp_map[i,j] = T2
        else:
            temp_map[i,j] = T1

# load absorbed power from save dictionaries

wvl_psf_273 = pickle.load(open("wvl_psf_2_wvls_273","rb"))
wvl_psf_273p5 = pickle.load(open("wvl_psf_2 wvls_273.5","rb"))

wvl_abs_273 = pickle.load(open("wvl_absorbed_2 wvls_273","rb"))
wvl_abs_273p5 = pickle.load(open("wvl_absorbed_2 wvls_273.5","rb"))

psf_1_273 = wvl_psf_273[8.1]
psf_2_273 = wvl_psf_273[11.9]
psf_273_total = psf_1_273 + psf_2_273
psf_273_max = np.max(psf_273_total)

abs_1_273 = wvl_abs_273[8.1]
abs_2_273 = wvl_abs_273[11.9]
abs_273_total = abs_1_273 + abs_2_273
abs_273_max = np.max(abs_273_total)

psf_1_273p5 = wvl_psf_273p5[8.1]
psf_2_273p5 = wvl_psf_273p5[11.9]

abs_1_273p5 = wvl_abs_273p5[8.1]
abs_2_273p5 = wvl_abs_273p5[11.9]
abs_273p5_total = abs_1_273p5 + abs_2_273p5

# let's integrate absorbed power

v_cube = 0.12e-6 * 0.12e-6 * 0.04e-6
coeff = 7
pixel_273 = np.zeros((coeff, coeff))
pixel_273p5 = np.zeros((coeff, coeff))

for i in range(coeff):
    for j in range(coeff):
        pixel_273[i,j] = np.sum(abs_273_total[100*i:100*(i + 1),100*j:100*(j + 1)])
        pixel_273p5[i,j] = np.sum(abs_273p5_total[100*i:100*(i + 1),100*j:100*(j + 1)])

plt.imshow(np.log(pixel_273))

# we obtain convolution of the discretized absorbed power with image pattern

kernel_dict = {273 : pixel_273, 273.5 : pixel_273p5}
restored_image = convolution2d(temp_map, kernel_dict)
pl_x, pl_y = np.shape(restored_image)

cut_image = restored_image[3: pl_x - 3, 3 : pl_y - 3]
ci_x, ci_y = np.shape(cut_image)

cut_image_deep = restored_image[6: pl_x - 6, 6 : pl_y - 6]
cid_x, cid_y = np.shape(cut_image_deep)

# plotting

fig, axs = plt.subplots(2, 2, figsize = (20,10))
plt.subplots_adjust(left=0.35,
                    bottom=0.1, 
                    right=0.7, 
                    top=0.6, 
                    wspace=0.25, 
                    hspace=0.35)

plt.rcParams["figure.titlesize"] = 22

extent = 0, 12 * pl_x, 0, 12 * pl_y
   
vmax_coeff_psf = 0.05
vmax_coeff_abs = 0.025
extent = 0, 12 * pl_x, 0, 12 * pl_y
im = axs[0][0].imshow(temp_map, extent = extent)
axs[0][0].set_xlabel('x, um')
axs[0][0].set_ylabel('y, um')
axs[0][0].set_title(f'Temperature map', fontsize = 12, loc = 'left')
cbar = fig.colorbar(im, ax = axs[0][0], pad = 0.05, shrink = 1)
cbar.ax.set_ylabel('Temperature, K', fontsize = 9)

extent = 0, 12 * coeff, 0, 12 * coeff
im = axs[0][1].imshow(pixel_273, extent = extent)
axs[0][1].set_xlabel('x, um')
axs[0][1].set_ylabel('y, um')
axs[0][1].set_title(f'Discretized absorbed power @ 273 K', fontsize = 12, loc = 'left')
cbar = fig.colorbar(im, ax = axs[0][1], pad = 0.05, shrink = 1)
cbar.ax.set_ylabel('Absorbed power, a.u.', fontsize = 9)

extent = 0, 12 * ci_x, 0, 12 * ci_y
im = axs[1][0].imshow(cut_image, extent = extent)
axs[1][0].set_xlabel('x, um')
axs[1][0].set_ylabel('y, um')
axs[1][0].set_title(f'Restored image', fontsize = 12, loc = 'left')
cbar = fig.colorbar(im, ax = axs[1][0], pad = 0.05, shrink = 1)
cbar.ax.set_ylabel('Signal, a.u.', fontsize = 9)

extent = 0, 12 * cid_x, 0, 12 * cid_y
im = axs[1][1].imshow(cut_image_deep, extent = extent)
axs[1][1].set_xlabel('x, um')
axs[1][1].set_ylabel('y, um')
axs[1][1].set_title(f'Restored image', fontsize = 12, loc = 'left')
cbar = fig.colorbar(im, ax = axs[1][1], pad = 0.05, shrink = 1)
cbar.ax.set_ylabel('Signal, a.u.', fontsize = 9)
# plotting



# fig, axs = plt.subplots(2, 3, figsize = (20,10))
# plt.subplots_adjust(left=0.35,
#                     bottom=0.1, 
#                     right=0.85, 
#                     top=0.6, 
#                     wspace=0.25, 
#                     hspace=0.35)

# plt.rcParams["figure.titlesize"] = 22

# extent = 0, 7*12, 0, 7*12
   
# vmax_coeff_psf = 0.05
# vmax_coeff_abs = 0.025

# im = axs[0][0].imshow(np.transpose(psf_1_273), extent = extent, vmax = vmax_coeff_psf * psf_273_max)
# # im = axs[0][0].imshow(np.transpose(np.log(psf_1_273)), extent = extent, vmax = -15)

# axs[0][0].set_xlabel('x, um')
# axs[0][0].set_ylabel('y, um')
# axs[0][0].set_title(f'Intensity @8.1 um', fontsize = 12, loc = 'left')
# cbar = fig.colorbar(im, ax = axs[0][0], pad = 0.05, shrink = 1)
# cbar.ax.set_ylabel('Field intensity a.u.', fontsize = 9)

# im = axs[0][1].imshow(np.transpose(psf_2_273), extent = extent, vmax = vmax_coeff_psf * psf_273_max)
# # im = axs[0][1].imshow(np.transpose(np.log(psf_2_273)), extent = extent, vmax = -15)

# axs[0][1].set_xlabel('x, um')
# axs[0][1].set_ylabel('y, um')
# axs[0][1].set_title(f'Intensity @11.9 um', fontsize = 12, loc = 'left')
# cbar = fig.colorbar(im, ax = axs[0][1], pad = 0.05, shrink = 1)
# cbar.ax.set_ylabel('Field intensity a.u.', fontsize = 9)

# im = axs[0][2].imshow(np.transpose(psf_273_total), extent = extent, vmax = vmax_coeff_psf * psf_273_max)
# # im = axs[0][2].imshow(np.transpose(np.log(psf_273_total)), extent = extent, vmax = -15)

# axs[0][2].set_xlabel('x, um')
# axs[0][2].set_ylabel('y, um')
# axs[0][2].set_title(f'Intensity @8.1/11.9 um', fontsize = 12, loc = 'left')
# cbar = fig.colorbar(im, ax = axs[0][2], pad = 0.05, shrink = 1)
# cbar.ax.set_ylabel('Field intensity a.u.', fontsize = 9)

# # absorbed power

# im = axs[1][0].imshow(np.transpose(abs_1_273), extent = extent, vmax = vmax_coeff_abs * abs_273_max)
# axs[1][0].set_xlabel('x, um')
# axs[1][0].set_ylabel('y, um')
# axs[1][0].set_title(f'Absrb. power @8.1 um', fontsize = 12, loc = 'left')
# cbar = fig.colorbar(im, ax = axs[1][0], pad = 0.05, shrink = 1)
# cbar.ax.set_ylabel('Absorbed power a.u.', fontsize = 10)

# im = axs[1][1].imshow(np.transpose(abs_2_273), extent = extent, vmax = vmax_coeff_abs * abs_273_max)
# axs[1][1].set_xlabel('x, um')
# axs[1][1].set_ylabel('y, um')
# axs[1][1].set_title(f'Absrb. power @11.9 um', fontsize = 12, loc = 'left')
# cbar = fig.colorbar(im, ax = axs[1][1], pad = 0.05, shrink = 1)
# cbar.ax.set_ylabel('Absorbed power a.u.', fontsize = 10)

# im = axs[1][2].imshow(np.transpose(abs_273_total), extent = extent, vmax = vmax_coeff_abs * abs_273_max)
# axs[1][2].set_xlabel('x, um')
# axs[1][2].set_ylabel('y, um')
# axs[1][2].set_title(f'Absrb. power @8.1/11.9 um', fontsize = 12, loc = 'left')
# cbar = fig.colorbar(im, ax = axs[1][2], pad = 0.05, shrink = 1)
# cbar.ax.set_ylabel('Absorbed power a.u.', fontsize = 10)