# LWIR_RCWA_PSF

The script rcwa_LWIR.py picks up a 5x1 LWIR pixels structure stored in '\data_comsol\pixels_edited_BIG_X.gds'
and performs calculation of the field intensity at a selected depth of the structure via summation of plane waves
incident upon the structure. Output data is stored in dataframe format (pandas package) in the form of electric field
with all three components obtained for each plane wave case.

Construction of light intensity distribution corresponding to the PSF of the optical system is performed in the script save_load.py after the main simulation routine is finished.
