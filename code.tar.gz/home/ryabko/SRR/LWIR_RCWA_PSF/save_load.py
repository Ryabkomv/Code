# -*- coding: utf-8 -*-
"""
Created on Mon Nov 13 13:11:10 2023

@author: a.lantsov
"""
import pandas as pd
import pickle
import numpy as np
import matplotlib.pyplot as plt
import jax
import jax.numpy as npj

# JAX settings
jax.config.update('jax_enable_x64', True)              # enable fp64; fp32 is used by default
jax.config.update('jax_platform_name', 'cpu')          # set defult backend ('gpu' of 'cpu')

# constants

c = 3e8
eps_0 = 8.85e-12 # F / m ___ q * V / m

c1 = 3.742e8
c2 = 1.439e4
c3 = 1.884e27

T1 = 273                                               # default temperature
T2 = 273.5                                             # increased temperature
alpha_ml = 0.3                                         # metalens transmission
dist_obj = 20                                          # distance to object [m]
D_lens = 3e-3                                          # metalens diameter  [m]
R_lens = 0.5*D_lens                                    # metalens radius    [m]
A_lens = np.pi * R_lens**2                             # metalens aperture
f_lens = 3e-3                                          # focal length       [m]
pixel_side = 12e-6                                     # pixel side length  [m]

ang_alpha = np.arctan(5 * pixel_side/(2 * f_lens))     # angular size of the pixel
ang_beta = ang_alpha

# functions 

def get_bb_spc_radiance (wvl, T):
    return c1 / ((wvl**5) * np.exp(c2/(wvl * T)) - 1)
       
@jax.jit
def get_field_upd_new(Ef, kx, ky, X, Y):
    """
    the function gets field components from the k-vectors and their amplitudes
    
    """
    tmp =  npj.exp( 1j * (kx[:,np.newaxis,npj.newaxis] * X + ky[:,npj.newaxis,npj.newaxis] * Y) )
    Ex = npj.sum( Ef[0][:,npj.newaxis,npj.newaxis] * tmp, axis=0)
    Ey = npj.sum( Ef[1][:,npj.newaxis,npj.newaxis] * tmp, axis=0)
        
    return [Ex, Ey]
    
# load dictionary with dataframes

# data_full_loaded = pickle.load(open("test_field_1x1_extended_phi","rb"))
data_full_loaded = pickle.load(open("test_field_1x1_short","rb"))

wvl_list = list(data_full_loaded.keys())              # list of wavelengths
test_field = data_full_loaded[wvl_list[0]]            # sample field from the dictionary
phi_list = list(test_field.columns)                   # azimuthal angles
theta_list = list(test_field.index)                   # incidence angles
W1 = [get_bb_spc_radiance(i, T1) for i in wvl_list]   # black body spectral radiance at T1 for wavelengths in the list

coeff = 1                                             # amount of pixels along x or y dimension
intensity_full = np.zeros((coeff * Nx, coeff * Ny))   # full registered intensity
absorbed_full = np.zeros((coeff * Nx, coeff * Ny))    # full registered absorbed power
n_pw = len(phi_list) * len(theta_list)                # total amount of plane waves

counter = 0                                          
total_steps = len(wvl_list) * n_pw

x = np.linspace(-coeff * Lx/2, coeff * Lx/2, coeff * Nx)
y = np.linspace(-coeff * Ly/2, coeff * Ly/2, coeff * Ny)
X, Y = np.meshgrid(x, y)

for i in range(len(wvl_list)):   
     
    wvl_cur = wvl_list[i] * 1e-6
    w_cycl = 2 * np.pi * c / wvl_cur
    Rad_per_pix = (W1[i] / np.pi) * A_lens * ang_alpha * ang_beta * alpha_ml
    I0 = Rad_per_pix / n_pw
    E_init = np.sqrt((2 * alpha_ml * I0)/(c * eps_0))
    
    eps_test = np.squeeze(epsTiN_grid_range[i, :, :])
    eps_pr = eps_test
    eps_pr = np.row_stack((eps_test for i in range(coeff)))
    eps_pr = np.column_stack((eps_pr for i in range(coeff)))
    
    full_field_ex = np.zeros((coeff * Nx, coeff * Ny))
    full_field_ey = np.zeros((coeff * Nx, coeff * Ny))
    
    for phi in phi_list:
        for theta in theta_list:
            counter+=1

            df = data_full_loaded[wvl_list[i]]
            Ef, kx, ky = [df[phi][theta][j] for j in range(3)]
            print(f'current phi {phi} and theta {theta}')
            print(f'current progress: {100*counter/total_steps:.1f}%')
            print(f'calculating fields...')
            s1 = time.time()
            Ex, Ey = get_field_upd_new(Ef, kx, ky, X, Y)
            print(f'fields have been found', time.time() - s1)
            
            full_field_ex = full_field_ex + Ex * E_init
            full_field_ey = full_field_ey + Ey * E_init
               
    psf_ex = np.abs(full_field_ex)**2
    psf_ey = np.abs(full_field_ey)**2
    
    abs_ex = 1e-18 * 0.5 * w_cycl * psf_ex * np.imag(eps_pr)
    abs_ey = 1e-18 * 0.5 * w_cycl * psf_ey * np.imag(eps_pr)
    
    intensity_full = intensity_full + psf_ex + psf_ey
    absorbed_full = absorbed_full + abs_ex + abs_ey


    





