#include <stdio.h>
double my_add(double a, double b);
int func_ret_int(int val);
double func_ret_double(double val);
char *func_ret_str(char *val);