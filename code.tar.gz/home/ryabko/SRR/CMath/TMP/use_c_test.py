#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Oct 12 13:51:56 2023

@author: ryabko
"""

import ctypes
import os

      
_sum = ctypes.CDLL('./libsum.so')
cuda = ctypes.CDLL('./libcuda.so')


# _sum.func_ret_int.restype = ctypes.c_int
# # Указываем, что функция принимает аргумент int
# _sum.func_ret_int.argtypes = [ctypes.c_int, ]

# _sum.func_ret_double.restype = ctypes.c_double
# # Указываем, что функция принимает аргумент double
# _sum.func_ret_double.argtypes = [ctypes.c_double]

# # Указываем, что функция возвращает char *
# _sum.func_ret_str.restype = ctypes.c_char_p
# # Указываем, что функция принимает аргумент char *
# _sum.func_ret_str.argtypes = [ctypes.POINTER(ctypes.c_char), ]

# _sum.my_add.restype = ctypes.c_double
# _sum.my_add.argtypes = [ctypes.c_double, ctypes.c_double]

# # global _sum
# # a = ctypes.c_int.in_dll(_sum, "a")
# # b = ctypes.c_int.in_dll(_sum, "b")
# a=3.7
# b=4.99
# result = _sum.my_add(a, b)

# print('ret func_ret_int: ', _sum.func_ret_int(101))
# # print('ret func_ret_double: ', _sum.func_ret_double(12.123456789))

# # # Необходимо строку привести к массиву байтов, затем полученный массив байтов приводим к строке.
# # print('ret func_ret_str: ', _sum.func_ret_str('Hello!'.encode('utf-8')).decode("utf-8") )

# print(result)

cuda.main()