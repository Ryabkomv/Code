#include <stdio.h>
#include <math.h>

int a = 4;
int b = 5;

int main(){
double c = sin(a+b);
printf("Sum of %d and %d = %f\n",a,b,c);
}
