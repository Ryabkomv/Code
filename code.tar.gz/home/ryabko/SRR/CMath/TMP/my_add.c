#include "my_add.h"

double my_add(double a, double b){
    double c;
    c = a+b;
    return c;
}

int func_ret_int(int val) { 
    printf("get func_ret_int: %d\n", val);
    return val;
} 

double func_ret_double(double val) { 
    printf("get func_ret_double: %f\n", val);
    return val;
} 

char *func_ret_str(char *val) { 
    printf("get func_ret_str: %s\n", val);
    return val;
} 