### How to setup

0. This step to be done if you work in WSL, but not SAIT servers (e.g. nanophotonics and microphotonics). Install sources for Boost and Eigen libraries, which are needed to compile C++ code in `src` directory:

```
$ sudo apt install build-essential libboost-all-dev libeigen3-dev
```

1. Clone EMOpt repository and change the directory:

```
$ git clone https://github.sec.samsung.net/LWIR/emopt
$ cd emopt
```

2. Compile C++ code when you are in `emopt`:

```
$ make 
```

3. Create virtual environment using mamba/conda:

```
$ mamba create -n emopt -c conda-forge python=3.9 future numpy=1.19 scipy matplotlib==3.3.4 \
    petsc4py="*=*complex*" slepc4py="*=*complex*" mpi4py h5py shapely
```

Note that some package versions are hard-coded, which is essential for compatibility with EMOpt.

7. Activate the created environment and install EMOpt as a local package:

```
$ mamba activate emopt
$ pip install .
```

DONE!

Note that some examples are executed in parallel (run `htop` to see the loaded CPUs), but some are not (e.g. FDTD code). In this case use `mpirun` as follows:

```
$ mpirun -n 8 python mmi_1x2_splitter_3D_fdtd.p
```

where `-n 8` defines a number of threads to be used.

-------------------------

### A Note on MPI + OpenMP

By default, emopt (and its dependencies) will use OpenMP to further parallelize some tasks. Unfortunately, on many systems the number of threads used for OpenMP will default to the number of cores available. This is problematic when using more than one process for MPI as emopt will try to use more threads than cores in the machine, leading to slow performance.

In order to avoid this, when running emopt on a single machine, it is advisable to set the number of OpenMP threads to 1 using:

```
$ export OMP_NUM_THREADS=1
$ mpirun -n 12 python code_to_run.py
```

or:

```
$ OMP_NUM_THREADS=1 mpirun -n 12 python code_to_run.py
```

If running on a network/cluster, increasing the number of threads used by OpenMP should be fine.

-------------------------

# EMopt
A toolkit for shape (and topology) optimization of 2D and 3D electromagnetic
structures. 

EMopt offers a suite of tools for simulating and optimizing electromagnetic
structures. It includes 2D and 3D finite difference frequency domain solvers,
1D and 2D mode solvers, a flexible and *easily extensible* adjoint method
implementation, and a simple wrapper around scipy.minimize. Out of the box, it
provides just about everything needed to apply cutting-edge inverse design
techniques to your electromagnetic devices.

A key emphasis of EMopt's is shape optimization. Using boundary smoothing
techniques, EMopt allows you to compute sensitivities (i.e. gradient of a
figure of merit with respect to design variables which define an
electromagnetic device's shape) with very high accuracy. This allows you to
easily take adavantage of powerful minimization techniques in order to optimize
your electromagnetic device.

## Documentation

Details on how to install and use EMopt can be found
[on readthedocs](https://emopt.readthedocs.io/en/latest/). Check this link
periodically as the documentation is constantly being improved and examples
added.

## Authors
Andrew Michaels 

## License
EMOpt is currently released under the BSD-3 license (see LICENSE.md for details)

## References
The methods employed by EMopt are described in:

Andrew Michaels and Eli Yablonovitch, "Leveraging continuous material averaging for inverse electromagnetic design," Opt. Express 26, 31717-31737 (2018)

An example of applying these methods to real design problems can be found in:

Andrew Michaels and Eli Yablonovitch, "Inverse design of near unity efficiency perfectly vertical grating couplers," Opt. Express 26, 4766-4779 (2018)
