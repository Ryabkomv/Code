emopt\.fdfd
===========

.. automodule:: emopt.fdfd
   :members:
   :undoc-members:
   :show-inheritance:
