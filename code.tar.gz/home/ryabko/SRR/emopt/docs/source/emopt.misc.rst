emopt\.misc
===========

.. automodule:: emopt.misc
   :members:
   :undoc-members:
   :show-inheritance:
