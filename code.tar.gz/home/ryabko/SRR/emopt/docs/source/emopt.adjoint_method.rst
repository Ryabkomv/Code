emopt\.adjoint_method
=====================

.. automodule:: emopt.adjoint_method
   :members:
   :undoc-members:
   :show-inheritance:
