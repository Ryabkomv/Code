emopt\.geometry
===============

.. automodule:: emopt.geometry
   :members:
   :undoc-members:
   :show-inheritance:
