.. _emopt_grid:

###########
emopt\.grid
###########

.. automodule:: emopt.grid
   :members:
   :undoc-members:
   :show-inheritance:
