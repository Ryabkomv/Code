emopt\.modes
============

.. automodule:: emopt.modes
   :members:
   :undoc-members:
   :show-inheritance:
