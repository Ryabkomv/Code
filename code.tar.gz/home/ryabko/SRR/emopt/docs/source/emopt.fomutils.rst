emopt\.fomutils
===============

.. automodule:: emopt.fomutils
   :members:
   :undoc-members:
   :show-inheritance:
