emopt\.defs
===========

.. automodule:: emopt.defs
   :members:
   :undoc-members:
   :show-inheritance:
