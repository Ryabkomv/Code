emopt\.fdtd
===========

.. automodule:: emopt.fdtd
   :members:
   :undoc-members:
   :show-inheritance:
