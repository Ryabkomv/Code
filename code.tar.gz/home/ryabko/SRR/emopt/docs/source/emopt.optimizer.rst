emopt\.optimizer
================

.. automodule:: emopt.optimizer
   :members:
   :undoc-members:
   :show-inheritance:
