'''
This file contains basic functions.

'''

import sys
import grcwa
grcwa.set_backend('autograd') # this is needed for gradients calculations
import autograd.numpy as np   # it's essential to use NumPy from autograd everywhere
import matplotlib.pyplot as plt

from params import *


def update_last_line(new_str: str):
    '''
    Updates the last string in console output.
    '''
    sys.stdout.write('\r')
    sys.stdout.write(new_str)
    sys.stdout.flush()

def draw_progress_bar(progress: float,
                      bar_len: int = 20) -> None:
    '''
    Draws simple updatable progress bar. Takes values in the range of [0,1].
    Based on:
    https://stackoverflow.com/questions/3002085/how-to-print-out-status-bar-and-percentage
    '''

    assert  0 <= progress <= 1, 'Incorrect input value. Should be in the range of [0,1].'
    update_last_line('TASK PROGRESS: [{:<{}}] {:.2%}'.format('='*int(bar_len*progress), bar_len, progress))
    if progress == 1: print('\n')


def grcwa_RTA(nG_max: int,
              Lx: float,
              Ly: float,
              wl: float,
              theta_deg: float,
              phi_deg: float,
              layers: list,
              planewave_params: dict = P_wave,
              Gmethod: int = 0,
              return_obj: bool = False,
              ) -> tuple:
    
    '''
    Basic function for pixel construction with gRCWA. This function takes a set of parameters
    and returns reflection, transmission, and absorption coefficients.

    Parameters
    ----------
    nG_max: int
        max. truncation order
    Lx: float
        length of a lattice vector along x axis
    Lx: float
        length of a lattice vector along y axis
    wl: float
        wavelength of an incident plane wave
    theta_deg: float
        polar angle of an incident planewave in degrees
    phi_deg: float
        azimuthal angle of an incident planewave in degrees
    layers: list
        parameters of layers: [[label0,thick0,eps0], ..., [labelN,thickN,epsN]]
    planewave_params: dict
        amplitudes and phases for an excited plane wave
    Gmethod:
        Fourier space truncation options: 0 for circular, 1 for rectangular
    return_obj: bool
        if True model's class to be returned  
    
    Returns
    -------
    R: float
        reflection coefficient
    T: float
        transmission coefficient
    A: float
        absorption coefficient
    '''
    
    assert len(layers) > 0, 'Non-empty list of layers should be defined.'
    assert type(layers[0][2]) in [int, float, complex], 'The first layer should be uniform!'

    freq = 1./wl + 1j*1e-20 # small Im part is to avoid singular matrix

    theta_rad = theta_deg * np.pi/180
    phi_rad = phi_deg * np.pi/180
    
    # setting up RCWA on rectangular grid
    obj = grcwa.obj(nG_max, [Lx,0.], [0.,Ly], freq, theta_rad, phi_rad, verbose=0)

    eps_grid = []
    # contructing layers stack
    for label, thick, eps in layers:
        if isinstance(eps, (int, float, complex)):
            obj.Add_LayerUniform(thick, eps) # uniform layer
        elif isinstance(eps, np.ndarray):
            Nx, Ny = eps.shape
            obj.Add_LayerGrid(thick, Nx, Ny) # patterned layer
            eps_grid.append(eps.flatten())
        else:
            raise Exception(f'Incorrect eps type in "{label}" layer: {type(eps)}')
    
    obj.Init_Setup(Gmethod=Gmethod)
    obj.MakeExcitationPlanewave(**planewave_params)

    if len(eps_grid) > 0:
        obj.GridLayer_geteps(np.concatenate(eps_grid))
    
    # compute reflection, transmission and absorption
    R, T = obj.RT_Solve(normalize=1)
    A = 1-R-T
    
    if return_obj:
        return R, T, A, obj
    else:
        return R, T, A


def absorption_dist(obj_range, which_layer, z_offset=0.0, plot_result=False):
    
    P_list = []
    
    for i, obj in enumerate(obj_range):
        
        (ex,ey,ez), _ = obj.Solve_FieldOnGrid(which_layer, z_offset)
        eps_xx = obj.Return_eps(which_layer, Nx=Nx, Ny=Ny, component='xx')
        eps_yy = obj.Return_eps(which_layer, Nx=Nx, Ny=Ny, component='yy')
        eps_zz = obj.Return_eps(which_layer, Nx=Nx, Ny=Ny, component='zz')
        
        P = np.real(obj.omega)*np.imag(
            eps_xx*np.abs(ex)**2 + eps_yy*np.abs(ey)**2 + eps_zz*np.abs(ez)**2
        )
        
        P_list.append(P)
    
    P_mean = np.mean(P_list,axis=0)
    
    if plot_result:
        fig, ax = plt.subplots(1,1,figsize=(3,2))
        c = ax.imshow(P_mean)
        fig.colorbar(c, ax=ax)
        ax.axis('off')
        fig.tight_layout()
    
    return P_mean


# Air-SiO2 interfece: Fresnel reflection depending on polarization and angle of incidence
# https://en.wikipedia.org/wiki/Fresnel_equations#/media/File:Fresnel_power_air-to-glass.svg
def grcwa_RTA_test():
    
    nG_max = 10 # no need for high number if uniform layers
    
    Lx = 1.0
    Ly = 1.0
    wl = 1.0
    
    theta_deg_range  = np.linspace(0, 89, 90)
    Ntheta = len(theta_deg_range)
    phi_deg = 0.0
    
    # [[label0,thick0,eps0], ...]
    layers = [
        ['Air',  1., 1.0],
        ['SiO2', 1., 1.5**2],
    ]

    Rs_range, Ts_range = np.zeros(Ntheta), np.zeros(Ntheta)
    Rp_range, Tp_range = np.zeros(Ntheta), np.zeros(Ntheta)

    for i, theta_deg in enumerate(theta_deg_range):
        Rs_range[i], Ts_range[i], _ =\
            grcwa_RTA(nG_max, Lx, Ly, wl, theta_deg, phi_deg, layers, S_wave)
        Rp_range[i], Tp_range[i], _ =\
            grcwa_RTA(nG_max, Lx, Ly, wl, theta_deg, phi_deg, layers, P_wave)

    brewster_angle = theta_deg_range[np.argmin(Rp_range)]
    print(f"Brewster's angle is {brewster_angle:.2f}")

    fig, ax = plt.subplots(1,1)

    ax.plot(theta_deg_range, Rs_range, 'b--', label='Rs')
    ax.plot(theta_deg_range, Ts_range, 'b-',  label='Ts')
    ax.plot(theta_deg_range, Rp_range, 'r--', label='Rp')
    ax.plot(theta_deg_range, Tp_range, 'r-',  label='Tp')
    ax.axvline(brewster_angle, ls='--', c='m', label="Brewster's angle")
    ax.set_title('Fresnel transmittance/reflectance at air/glass interface')
    ax.set_xlabel('angle of incidence, degrees')
    ax.set_xlim(theta_deg_range[0], theta_deg_range[-1])
    ax.set_ylim([0, 1.01])
    ax.legend()
    
    fig.show()


