Anaconda environment setup:

```
$ conda create -n rcwa python=3.10
$ conda activate rcwa
$ conda update conda --all
$ conda install -c conda-forge mkl blas='*=*mkl*' libblas='*=*mkl*' libcblas='*=*mkl*' liblapack='*=*mkl*'
$ conda install -c conda-forge cairosvg gdspy nlopt numpy matplotlib scipy
$ pip install grcwa
```
