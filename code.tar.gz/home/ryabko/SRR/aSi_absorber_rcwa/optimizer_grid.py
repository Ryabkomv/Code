'''
This script optimizes absorption coefficient for an a-Si-based pixel constructed
from non-uniform layers and operating in 8-12 μm wavelength range.

Some shortenings in the code:
R = Reflection
T = Transmission
A = Absorption

'''

#%% IMPORTS

import autograd.numpy as np
from autograd import grad
import nlopt
import matplotlib.pyplot as plt

from gds_decomp import gds2npy
from params import *
from primitives import *

# Matplotlib
MPL_OUTPUT_FLAG = True # plot figures
plt.rcParams.update({'figure.max_open_warning': 0}) # supress warnings on the number of figures
colors = plt.rcParams['axes.prop_cycle'].by_key()['color'] # list of default colors cycle

# NumPy formatter for printing arrays
np_formatter = {'float_kind': lambda x: f'{x:.3f}'}
np.set_printoptions(formatter=np_formatter)

nG_max = nG_max_grid

# !!! grid to be analyzed
gds_cell_prefix = 'finger_05'


#%% PIXEL WITH NON-UNIFORM LAYERS: LOADING MASKS FROM GDS

gds_all = gds2npy(gds_file, Nx, Ny) # all cells are loaded

print(f'"{gds_file}" has been loaded sucessfully.')

# keys filtering, here you can define a gds cell
masks = {}
for k, v in gds_all.items():
    if k.startswith(gds_cell_prefix):
        layer_name = k.replace(gds_cell_prefix+'-','')
        masks[layer_name] =  v

# preview of the loaded layers

if MPL_OUTPUT_FLAG:

    fig, axs = plt.subplots(1, len(masks), figsize=(10,2))
    
    for i, (k, v) in enumerate(masks.items()):
        axs[i].imshow(v)
        axs[i].set_title(k)
        axs[i].axis('off')
        axs[i].set_aspect('equal')
    
    fig.tight_layout()

    
#%% PIXEL WITH NON-UNIFORM LAYERS: CONSTRICTING RCWA LAYERS

# Table of layers:
#_________________________________________________________________________________
# no. | z_from | z_to   | thick  | materials
# ----|--------| -------| ------ |------------------------------------------------
#  0  | 0.00μm | 0.00μm | 0.00μm | Air [input]
#  1  | 0.00μm | 0.15μm | 0.15μm | SiO2 (passivation)
#  2  | 0.15μm | 0.22μm | 0.07μm | a-Si
#  3  | 0.22μm | 0.25μm | 0.03μm | TiN (electrodes) + a-Si
#  4  | 0.25μm | 0.40μm | 0.15μm | SiO2 (support) + TiN (anchors)
#  5  | 0.40μm | 2.40μm | 2.00μm | Air (gap) + SiO2 (posts) + TiN (anchors 1&2)
#  6  | 2.40μm | 2.50μm | 0.10μm | SiO2 (base) + TiN (anchors 1&2)
#  7  | 2.50μm | 2.60μm | 0.10μm | SiO2 (base) + Al (electrode 2) + TiN (anchor 2)
#  8  | 2.60μm | 2.70μm | 0.10μm | SiO2 (base) + Al (mirror) + TiN (anchor 1)
#  9  | 2.70μm | 2.80μm | 0.10μm | SiO2 (base) + TiN (anchor 1)
# 10  | 2.80μm | 2.90μm | 0.10μm | SiO2 (base) + Al (electrode 1)
# 11  | 2.90μm | 3.00μm | 0.10μm | SiO2 (base)
#---------------------------------------------------------------------------------

# grids are wavelength-dependent and stacked as follows:
# eps_grid = [[eps_xy_wl0], ..., [eps_xy_wlN]]
# !!! Air as surrounding medium in layers no. 1-5, and SiO2 in layers no. 6-11

# layer no. 1: Air (input)
# no need in construction

epsAl = 100

# layer no. 1: SiO2 (passivation)
epsSiO2Passivation_grid_range = np.array([
    masks['80'] * epsSiO2 for epsSiO2 in epsSiO2_range
])
epsSiO2Passivation_grid_range[epsSiO2Passivation_grid_range == 0] = epsAir

# layer no. 2: a-Si
epsSi_grid_range = np.array([
    masks['80'] * epsSi for epsSi in epsSi_range
])
epsSi_grid_range[epsSi_grid_range == 0] = epsAir

# layer no. 3: TiN (electrodes) + a-Si
epsTiN_grid_range = np.array([
    masks['45'] * epsTiN + (masks['80']-masks['45']) * epsSi
    for epsTiN, epsSi in np.stack([epsTiN_range, epsSi_range]).T
])
epsTiN_grid_range[epsTiN_grid_range == 0] = epsAir

# layer no. 4: SiO2 (support) + TiN (anchors)
epsSiO2Support_grid_range = np.array([
    (masks['80']-masks['20']) * epsSiO2 + masks['20'] * epsTiN
    for epsSiO2, epsTiN in np.stack([epsSiO2_range, epsTiN_range]).T
])
epsSiO2Support_grid_range[epsSiO2Support_grid_range == 0] = epsAir

# layer no. 5: Air (gap) + SiO2 (posts) + TiN (anchors 1&2)
epsAirGap_grid_range = np.array([
    masks['20'] * epsTiN + (masks['30']-masks['20']) * epsSiO2
    for epsTiN, epsSiO2 in np.stack((epsTiN_range, epsSiO2_range)).T
])
epsAirGap_grid_range[epsAirGap_grid_range == 0] = epsAir

# layer no. 6: SiO2 (base) + TiN (anchors 1&2)
epsSiO2BaseTiNAnchors_grid_range = []
for epsTiN, epsSiO2 in np.stack((epsTiN_range, epsSiO2_range)).T:
    eps_xy = masks['20'] * epsTiN
    eps_xy[eps_xy == 0] = epsSiO2
    epsSiO2BaseTiNAnchors_grid_range.append(eps_xy)
epsSiO2BaseTiNAnchors_grid_range = np.array(epsSiO2BaseTiNAnchors_grid_range)

# layer no. 7: SiO2 (base) + Al (electrode 2) + TiN (anchor 2)
epsSiO2BaseAlElectrode2_grid_range = []
for epsTiN, epsSiO2 in np.stack((epsTiN_range, epsSiO2_range)).T:
    eps_xy = masks['20'] * epsTiN
    eps_xy[:Nx//2,:Ny//2] = 0
    eps_xy += masks['11'] * epsAl
    eps_xy[eps_xy == 0] = epsSiO2
    epsSiO2BaseAlElectrode2_grid_range.append(eps_xy)
epsSiO2BaseAlElectrode2_grid_range = np.array(epsSiO2BaseAlElectrode2_grid_range)

# layer no. 8: SiO2 (base) + Al (mirror) + TiN (anchor 1)
epsSiO2BaseAlMirror = []
for epsTiN, epsSiO2 in np.stack((epsTiN_range, epsSiO2_range)).T:
    eps_xy = masks['20'] * epsTiN
    eps_xy[:Nx//2,:Ny//2] = 0
    eps_xy += masks['10'] * epsAl
    eps_xy[eps_xy == 0] = epsSiO2
    epsSiO2BaseAlMirror.append(eps_xy)
epsSiO2BaseAlMirror = np.array(epsSiO2BaseAlMirror)

# layer no. 9: SiO2 (base) + TiN (anchor 1)
epsSiO2TiNAnchor1_grid_range = []
for epsTiN, epsSiO2 in np.stack((epsTiN_range, epsSiO2_range)).T:
    eps_xy = masks['20'] * epsTiN
    eps_xy[:Nx//2,:Ny//2] = 0
    eps_xy[eps_xy == 0] = epsSiO2
    epsSiO2TiNAnchor1_grid_range.append(eps_xy)
epsSiO2TiNAnchor1_grid_range = np.array(epsSiO2TiNAnchor1_grid_range)

# layer no. 10: SiO2 (base) + Al (electrode 1)
epsSiO2BaseAlElectrode1_grid_range = []
for epsSiO2 in epsSiO2_range:
    eps_xy = np.zeros((Nx,Ny),dtype=complex)
    eps_xy[:,:] = masks['12'] * epsAl
    eps_xy[eps_xy == 0] = epsSiO2
    epsSiO2BaseAlElectrode1_grid_range.append(eps_xy)
epsSiO2BaseAlElectrode1_grid_range = np.array(epsSiO2BaseAlElectrode1_grid_range)

# layer no. 11: SiO2 (base)
# no need in construction

# plotting resulting grid layers
if MPL_OUTPUT_FLAG:

    all_eps_grids = {
        '1' : epsSiO2Passivation_grid_range,
        '2' : epsSi_grid_range,
        '3' : epsTiN_grid_range,
        '4' : epsSiO2Support_grid_range,
        '5' : epsAirGap_grid_range,
        '6' : epsSiO2BaseTiNAnchors_grid_range,
        '7' : epsSiO2BaseAlElectrode2_grid_range,
        '8' : epsSiO2BaseAlMirror,
        '9' : epsSiO2TiNAnchor1_grid_range,
        '10': epsSiO2BaseAlElectrode1_grid_range,
    }

    fig, axs = plt.subplots(4,3,figsize=(8,8))
    fig.suptitle('real part on complex n')
    axs = axs.flatten()

    i_wl_to_plot = Nwl//2 # !!! wavelength is fixed at wl_range_inv[i_wl_to_plot]

    for i, (label, eps_grid) in enumerate(all_eps_grids.items()):
        c = axs[i].imshow(np.real(np.sqrt(eps_grid[i_wl_to_plot])))
        axs[i].set_title(f'layer no. {label}')
        fig.colorbar(c, ax=axs[i])
        axs[i].axis('off')

    fig.tight_layout()


#%% PIXEL WITH NON-UNIFORM LAYERS: BROADBAND RESPONSE

R_range = np.zeros(Nwl)
T_range = np.zeros(Nwl)
A_range = np.zeros(Nwl)
obj_range = np.empty(Nwl, dtype=object)

for i in range(Nwl):
    
    layers = [
        ['0',  0.00, epsAir],
        ['1',  0.15, epsSiO2Passivation_grid_range[i]],
        ['2',  0.07, epsSi_grid_range[i]],
        ['3',  0.03, epsTiN_grid_range[i]],
        ['4',  0.15, epsSiO2Support_grid_range[i]],
        ['5',  2.00, epsAirGap_grid_range[i]],
        ['6',  0.10, epsSiO2BaseTiNAnchors_grid_range[i]],
        ['7',  0.10, epsSiO2BaseAlElectrode2_grid_range[i]],
        ['8',  0.10, epsSiO2BaseAlMirror[i]],
        ['9',  0.10, epsSiO2TiNAnchor1_grid_range[i]],
        ['10', 0.10, epsSiO2BaseAlElectrode1_grid_range[i]],
        ['11', 0.10, epsSiO2_range[i]],
    ]
    
    R_range[i], T_range[i], A_range[i], obj_range[i] =\
        grcwa_RTA(nG_max, Lx, Ly, wl_range[i], theta_deg, phi_deg,
                  layers, P_wave, return_obj=True)
    
    draw_progress_bar((i+1)/Nwl)

if MPL_OUTPUT_FLAG:
    
    fig, ax = plt.subplots(1,1,figsize=(6,3))

    colors = plt.rcParams['axes.prop_cycle'].by_key()['color']
    ax.plot(wl_range, R_range, 'o', color=colors[0], fillstyle='none', label='R')
    ax.axhline(np.mean(R_range),    color=colors[0], linestyle='--',   label='R mean')
    ax.plot(wl_range, T_range, 'o', color=colors[1], fillstyle='none', label='T')
    ax.axhline(np.mean(T_range),    color=colors[1], linestyle='--',   label='T mean')
    ax.plot(wl_range, A_range, 'o', color=colors[2], fillstyle='none', label='A')
    ax.axhline(np.mean(A_range),    color=colors[2], linestyle='--',   label='A mean')
    ax.set_title('Reflection | Transmission | Absorption')
    ax.set_xlabel('Wavelength (μm)')
    ax.set_ylabel('Normalized coefficient')
    ax.set_xlim([8, 12])
    ax.set_ylim([0, 1.05])
    ax.legend(loc='center left', bbox_to_anchor=(1.0, 0.5))
    
    fig.tight_layout()
    fig.savefig(save_dir.joinpath('pixel_grid_absorption_probe.png'), dpi=fig_dpi)
    

#%% PIXEL WITH NON-UNIFORM LAYERS: ABSORPTION DISTRIBUTION

# flattened XY grids for saving data
X, Y = np.meshgrid(np.linspace(-0.5*Lx,0.5*Lx,Nx), np.linspace(-0.5*Ly,0.5*Ly,Ny))
X = X.flatten()
Y = Y.flatten()

# l is layer's label, t is thickness
for l, t, _ in layers:
    if l in ['1','2','3','4']:
        z_rel = 0.5*t # !!! relative z (from beginnig of the layer)
        Z = z_rel*np.ones(Nx*Ny) # flattened Z grid
        P_mean = absorption_dist(obj_range, which_layer=int(l), z_offset=0.5*t,
                                 plot_result=MPL_OUTPUT_FLAG).flatten() # !!! flattened
        save_data = np.vstack([X,Y,Z,P_mean]).T
        np.savetxt(save_dir.joinpath(f'P_layer{l}_z={z_rel}.txt'), save_data, delimiter=',')





















# OPTIMIZATION CODE TAKES A LOT OF TIME AND SO IS COMMENTED

#%% PIXEL WITH NON-UNIFORM LAYERS: AVERAGED PARAMETERS

# def grcwa_A_mean(x):
#     '''
#     Function which takes vector of thicknesses and returns absorption coefficiens
#     in a defined wavelength range; such a format is essential for NLOpt.
#     '''

#     A_list = []
  
#     for i in range(Nwl):
#         # ! note that some thicknesses are fixed
#         layers = [
#             ['0',  0.00, epsAir],
#             ['1',  x[0], epsSiO2Passivation_grid_range[i]],
#             ['2',  x[1], epsSi_grid_range[i]],
#             ['3',  0.03, epsTiN_grid_range[i]],
#             ['4',  x[2], epsSiO2Support_grid_range[i]],
#             ['5',  x[3], epsAirGap_grid_range[i]],
#             ['6',  0.10, epsSiO2BaseTiNAnchors_grid_range[i]],
#             ['7',  0.10, epsSiO2BaseAlElectrode2_grid_range[i]],
#             ['8',  0.10, epsSiO2BaseAlMirror[i]],
#             ['9',  0.10, epsSiO2TiNAnchor1_grid_range[i]],
#             ['10', 0.10, epsSiO2BaseAlElectrode1_grid_range[i]],
#             ['11', 0.10, epsSiO2_range[i]],
#         ]
    
#         _, _, A =\
#             grcwa_RTA(nG_max, Lx, Ly, wl_range[i], theta_deg, phi_deg,
#                       layers, P_wave, return_obj=False)

#         A_list.append(A)

#     return np.mean(np.array(A_list))

# x_test = np.array([0.15, 0.10, 0.15, 2.5])
# print(f'Layers with variable thicknesses are [SiO2 (top), a-Si, SiO2 (bottom), Air(gap)]')
# print(f'Test vector of thicknesses: {x_test})')
# print(f'Absorption averaging function test: {grcwa_A_mean(x_test):.3f}')

# grcwa_A_mean_grad = grad(grcwa_A_mean)
# print(f'Absorption gradient function test: {grcwa_A_mean_grad(x_test)}')


#%% PIXEL WITH NON-UNIFORM LAYERS: ABSORPTION OPTIMIZATION

# counter = 0
# A_opt_list = []

# maxeval = 40 # TODO: move NLOpt params to params.py

# def objective(x, gradn):
    
#     global counter, A_opt_list

#     A = grcwa_A_mean(x)
#     gradn[:] = grcwa_A_mean_grad(x)
    
#     update_last_line(f'step # {counter:2}: A = {A:.5f}')
    
#     counter += 1
#     A_opt_list.append(A)
    
#     return A

# # initial params
# x_init = np.array([0.15, 0.1, 0.15, 2.5])
# ndof = len(x_init)

# # lower & upper boundaries
# x_lb = np.array([0.05, 0.05, 0.05, 0.2])
# x_ub = np.array([0.30, 0.30, 0.30, 5.0])

# opt = nlopt.opt(nlopt.LD_MMA, ndof) # LD_MMA = Method of Moving Asymptotes
# opt.set_lower_bounds(x_lb)
# opt.set_upper_bounds(x_ub)

# opt.set_xtol_rel(1e-4)
# opt.set_maxeval(maxeval) # max number of iterations

# opt.set_max_objective(objective)
# x_opt = opt.optimize(x_init)

# print()

# print(f'Best result is achieved for thicknesses: {x_opt}')

# if MPL_OUTPUT_FLAG:

#     fig, ax = plt.subplots(1,1,figsize=(6,3))

#     ax.plot(A_opt_list, 'o', fillstyle='none', label='optimization')
#     ax.axhline(A_opt_list[0], linestyle='--', color='red', label='initial guess')
#     ax.axhline(max(A_opt_list), linestyle='--', color='gray', label='best iteration')
#     ax.set_title('Absorption optimization with NLopt')
#     ax.set_xlabel('Iteration #')
#     ax.set_ylabel('Absorption')
#     ax.set_xlim([0, len(A_opt_list)])
#     ax.set_ylim([0.75, 1.0])
#     ax.legend(loc='lower right', bbox_to_anchor=(1, 0.15))

#     fig.tight_layout()
#     fig.savefig(save_dir.joinpath('pixel_grid_absorption_opt.png'), dpi=fig_dpi)


# %%
