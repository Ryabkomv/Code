'''
This script optimizes absorption coefficient for an a-Si-based pixel constructed
from uniform layers and operating in 8-12 μm wavelength range.

Some shortenings in the code:
R = Reflection
T = Transmission
A = Absorption

'''

#%% IMPORTS

import autograd.numpy as np
from autograd import grad
import nlopt
import matplotlib.pyplot as plt

from params import *
from primitives import *

# checking dir for saving output
save_dir.mkdir(parents=True, exist_ok=True)

# Matplotlib
MPL_OUTPUT_FLAG = True # plot figures
plt.rcParams.update({'figure.max_open_warning': 0}) # supress warnings on the number of figures
colors = plt.rcParams['axes.prop_cycle'].by_key()['color'] # list of default colors cycle

# NumPy formatter for printing arrays
np_formatter = {'float_kind': lambda x: f'{x:.3f}'}
np.set_printoptions(formatter=np_formatter)

nG_max = nG_max_unif # in this 


#%% PIXEL WITH UNIFORM LAYERS: BROADBAND RESPONSE

# Table of the probe parameters:
#________________________________________________________
# no. | thick  | material      | epsilon in 8-12 μm range
# ----|--------|---------------|-----------------------
# 0   | 0.00μm | Air [input]   | 1.0 (constant)
# 1   | 0.15μm | SiO2 (top)    | [refractiveindex.info]
# 2   | 0.10μm | a-Si          | [refractiveindex.info]
# 3   | 0.01μm | TiN           | [HQ data]
# 4   | 0.15μm | SiO2 (bottom) | [refractiveindex.info]
# 5   | 2.50μm | Air (gap)     | 1.0 [constant]
# 6   | 1.00μm | Al (mirror)   | 10^10 [constant]
#--------------------------------------------------------

R_range = np.zeros(Nwl)
T_range = np.zeros(Nwl)
A_range = np.zeros(Nwl)

for i in range(Nwl):
    
    layers = [
        ['Air (input)',   0.00, epsAir],
        ['SiO2 (top)',    0.15, epsSiO2_range[i]],
        ['a-Si',          0.10, epsSi_range[i]],
        ['TiN',           0.01, epsTiN_range[i]],
        ['SiO2 (bottom)', 0.15, epsSiO2_range[i]],
        ['Air (gap)'    , 2.50, epsAir],
        ['Al (mirror)',   1.00, epsAl],
    ]
    
    R_range[i], T_range[i], A_range[i] =\
        grcwa_RTA(nG_max, Lx, Ly, wl_range[i], theta_deg, phi_deg, layers, P_wave)

    draw_progress_bar((i+1)/Nwl)

if MPL_OUTPUT_FLAG:
    
    fig, ax = plt.subplots(1,1,figsize=(6,3))

    ax.plot(wl_range, R_range, 'o', color=colors[0], fillstyle='none', label='R')
    ax.axhline(np.mean(R_range),    color=colors[0], linestyle='--',   label='R mean')
    ax.plot(wl_range, T_range, 'o', color=colors[1], fillstyle='none', label='T')
    ax.axhline(np.mean(T_range),    color=colors[1], linestyle='--',   label='T mean')
    ax.plot(wl_range, A_range, 'o', color=colors[2], fillstyle='none', label='A')
    ax.axhline(np.mean(A_range),    color=colors[2], linestyle='--',   label='A mean')
    ax.set_title('Reflection | Transmission | Absorption')
    ax.set_xlabel('Wavelength (μm)')
    ax.set_ylabel('Normalized coefficient')
    ax.set_xlim([8, 12])
    ax.set_ylim([0, 1.05])
    ax.legend(loc='center left', bbox_to_anchor=(1.0, 0.5))
    
    fig.tight_layout()
    fig.savefig(save_dir.joinpath('pixel_uniform_absorption_probe.png'), dpi=fig_dpi)


#%% PIXEL WITH UNIFORM LAYERS: AVERAGED PARAMETERS

def grcwa_A_mean(x):
    '''
    Function which takes vector of thicknesses and returns absorption coefficiens
    in a defined wavelength range; such a format is essential for NLOpt.
    '''

    A_list = []
  
    for i in range(Nwl):
        # ! note that some thicknesses are fixed
        layers = [
            ['Air (input)',   0.00, epsAir],
            ['SiO2 (top)',    x[0], epsSiO2_range[i]],
            ['a-Si',          x[1], epsSi_range[i]],
            ['TiN',           0.01, epsTiN_range[i]],
            ['SiO2 (bottom)', x[2], epsSiO2_range[i]],
            ['Air (gap)',     x[3], epsAir],
            ['Al (mirror)',   1.00, epsAl],
        ]

        _, _, A =\
            grcwa_RTA(nG_max, Lx, Ly, wl_range[i], theta_deg, phi_deg, layers, P_wave)

        A_list.append(A)

    return np.mean(np.array(A_list))

x_test = np.array([0.15, 0.10, 0.15, 2.5])
print(f'Layers with variable thicknesses are [SiO2 (top), a-Si, SiO2 (bottom), Air(gap)]',
      f'Test vector of thicknesses: {x_test})',
      f'Absorption averaging function test: {grcwa_A_mean(x_test):.3f}',
      sep='\n')

grcwa_A_mean_grad = grad(grcwa_A_mean)
print(f'Absorption gradient function test: {grcwa_A_mean_grad(x_test)}')


#%% PIXEL WITH UNIFORM LAYERS: ABSORPTION OPTIMIZATION

counter = 0
A_opt_list = []

maxeval = 40 # TODO: move NLOpt params to params.py

def objective(x, gradn):
    
    global counter, A_opt_list

    A = grcwa_A_mean(x)
    gradn[:] = grcwa_A_mean_grad(x)
    
    update_last_line(f'step # {counter:2}: A = {A:.5f}')
    
    counter += 1
    A_opt_list.append(A)
    
    return A

# initial params
x_init = np.array([0.15, 0.1, 0.15, 2.5])
ndof = len(x_init)

# lower & upper boundaries
x_lb = np.array([0.05, 0.05, 0.05, 0.2])
x_ub = np.array([0.30, 0.30, 0.30, 5.0])

opt = nlopt.opt(nlopt.LD_MMA, ndof) # LD_MMA = Method of Moving Asymptotes
opt.set_lower_bounds(x_lb)
opt.set_upper_bounds(x_ub)

opt.set_xtol_rel(1e-4)
opt.set_maxeval(maxeval) # max number of iterations

opt.set_max_objective(objective)
x_opt = opt.optimize(x_init)

print()

print(f'Best result is achieved for thicknesses: {x_opt}')

if MPL_OUTPUT_FLAG:

    fig, ax = plt.subplots(1,1,figsize=(6,3))

    ax.plot(A_opt_list, 'o', fillstyle='none', label='optimization')
    ax.axhline(A_opt_list[0], linestyle='--', color='red', label='initial guess')
    ax.axhline(max(A_opt_list), linestyle='--', color='gray', label='best iteration')
    ax.set_title('Absorption optimization with NLopt')
    ax.set_xlabel('Iteration #')
    ax.set_ylabel('Absorption')
    ax.set_xlim([0, len(A_opt_list)])
    ax.set_ylim([0.75, 1.0])
    ax.legend(loc='lower right', bbox_to_anchor=(1, 0.15))

    fig.tight_layout()
    fig.savefig(save_dir.joinpath('pixel_uniform_absorption_opt.png'), dpi=fig_dpi)


# %%
