# -*- coding: utf-8 -*-
"""
Created on Thu Jan 11 13:15:24 2024

@author: user
"""
import numpy as np
import math
import matplotlib.pyplot as plt
import scipy.sparse as sps
import scipy.sparse.linalg as sla
from decimal import Decimal

def get_waveguidemesh (n,h,rh,rw,side,dx,dy, edges_req = True):
    """
    This function creates an index mesh for the finite-difference
    mode solver.  The function will accommodate a generalized three
    layer rib waveguide structure.  (Note: channel waveguides can
    also be treated by selecting the parameters appropriately.) 
    
    USAGE:
 
    [x,y,xc,yc,nx,ny,eps] = get_waveguidemesh(n,h,rh,rw,side,dx,dy)
    [x,y,xc,yc,nx,ny,eps,edges] = get_waveguidemesh(n,h,rh,rw,side,dx,dy)
    
    Parameters
    ----------
    n : indices of refraction for layers in waveguide (tuple)
    h : height of each layer in waveguide (tuple)
    rh : height of waveguide feature
    rw : half-width of waveguide
    side : excess space to the right of waveguide
    dx : vertical grid spacing
    
    Returns
    
    x,y - vectors specifying mesh coordinates
    xc,yc - vectors specifying grid-center coordinates
    nx,ny - size of index mesh
    eps - index mesh (n^2)
    edges - (optional) list of edge coordinates, to be used later
          with the line() command to plot the waveguide edges
    
    
    # """

    ih = [round(i_/dy) for i_ in h]
    irh = round (rh/dy)
    irw = round (rw/dx)
    iside = round (side/dx)
    nlayers = len(h)
    
    nx = irw+iside+1
    ny = sum(ih)+1
    
    xc = (np.asarray(np.linspace(1*dx - dx/2, (nx - 1) * dx - dx/2, nx - 1))).reshape(-1,1)
    yc = np.transpose((np.asarray(np.linspace(1*dy - dy/2, (ny - 1) * dy - dy/2, ny - 1))).reshape(-1,1))
    x = (np.asarray(np.linspace(0, (nx - 1) * dx, nx))).reshape(-1,1)
    y = np.transpose((np.asarray(np.linspace(0, (ny - 1) * dy, ny))).reshape(-1,1))
    
    eps = np.zeros((nx-1,ny-1))
    
    iy = 0
    
    for jj in range(0, nlayers):
        for i in range(0, ih[jj]):
            eps[:,iy] = (n[jj]**2)*np.ones((nx-1))
            iy+=1
    
    iy = sum(ih)-ih[nlayers - 1]
    for i in range(1, irh):
        eps[irw:irw+iside + 1,iy] = (n[nlayers - 1]**2)*np.ones(iside)
        iy-=1
    
    nx = max(np.shape(xc))
    ny = max(np.shape(yc))
    
    if edges_req:
        edges = {1:[],2:[]}
        iyp = np.cumsum(ih)
        for jj in range(0, nlayers-2):
            if (iyp[jj] >= (iyp[nlayers-1]-irh)):
                edges[1].append([0, dx * irw])
            else:
                edges[1].append([0, dx * (irw+iside)])
    
        edges[2].append([dy*iyp[jj], dy*iyp[jj]])
        jj = nlayers - 2
        edges[1].append([0,dx * irw, dx * irw, dx * (irw+iside)])
        edges[2].append([dy * iyp[jj],dy * iyp[jj], dy * (iyp[jj]-irh), dy * (iyp[jj]-irh)])
        output_data = x,y,xc,yc,nx,ny,eps,edges
    else:
        output_data = x,y,xc,yc,nx,ny,eps
    return output_data

def get_wgmodes(wavelength, guess, nmodes, dx, dy, *args):
    """
    
     This function computes the two transverse magnetic field
     components of a dielectric waveguide, using the finite
     difference method.  For details about the method, please
     consult:  
    
     A. B. Fallahkhair, K. S. Li and T. E. Murphy, "Vector Finite
     Difference Modesolver for Anisotropic Dielectric
     Waveguides", J. Lightwave Technol. 26(11), 1423-1431,
     (2008). 
    
        Parameters
        ----------
        wavelength : optical wavelength
        
        guess : scalar shift to apply when calculating the eigenvalues.
                This routine will return the eigenpairs which have an
                effective index closest to this guess
                
        nmodes : the number of modes to calculate
        
        dx : horizontal grid spacing (vector or scalar)
        
        dy : vertical grid spacing (vector or scalar)
        
        *args : 
            eps - index mesh (isotropic materials)  OR:
        epsxx, epsxy, epsyx, epsyy, epszz - index mesh (anisotropic)
        boundary - 4 letter string specifying boundary conditions to be
        applied at the edges of the computation window.  
          boundary(1) = North boundary condition
          boundary(2) = South boundary condition
          boundary(3) = East boundary condition
          boundary(4) = West boundary condition
        The following boundary conditions are supported: 
          'A' - Hx is antisymmetric, Hy is symmetric.
          'S' - Hx is symmetric and, Hy is antisymmetric.
          '0' - Hx and Hy are zero immediately outside of the
                boundary. 
    
        Returns
        -------
        phix - Hx - three-dimensional vector containing Hx for each
           calculated mode 
        phiy - Hy - three-dimensional vector containing Hy for each
           calculated mode (e.g.: hy(:,k) = two dimensional Hy
           matrix for the k-th mode 
        neff - vector of modal effective indices
    
     USAGE:
     
     [Hx,Hy,neff] = wgmodes(wavelength, guess, nmodes, dx, dy, ...
                            eps,boundary);
     [Hx,Hy,neff] = wgmodes(wavelength, guess, nmodes, dx, dy, ...
                            epsxx, epsyy, epszz, boundary);
     [Hx,Hy,neff] = wgmodes(wavelength, guess, nmodes, dx, dy, ...
                            epsxx, epsxy, epsyx, epsyy, epszz, boundary);
     
      NOTES:
     
      1) The units are arbitrary, but they must be self-consistent
      (e.g., if lambda is in um, then dx and dy should also be in
      um.
     
      2) Unlike the E-field modesolvers, this method calculates
      the transverse MAGNETIC field components Hx and Hy.  Also,
      it calculates the components at the edges (vertices) of
      each cell, rather than in the center of each cell.  As a
      result, if size(eps) = [n,m], then the output eigenvectors
      will be have a size of [n+1,m+1].
     
      3) This version of the modesolver can optionally support
      non-uniform grid sizes.  To use this feature, you may let dx
      and/or dy be vectors instead of scalars.
     
      4) The modesolver can consider anisotropic materials, provided
      the permittivity of all constituent materials can be
      expressed in one of the following forms:   
     
       [eps  0   0 ]  [epsxx   0     0  ]  [epsxx epsxy   0  ]
       [ 0  eps  0 ]  [  0   epsyy   0  ]  [epsyx epsyy   0  ]
       [ 0   0  eps]  [  0     0   epszz]  [  0     0   epszz]
     
      The program will decide which form is appropriate based upon
      the number of input arguments supplied.
     
      5) Perfectly matched boundary layers can be accomodated by
      using the complex coordinate stretching technique at the
      edges of the computation window.  (stretchmesh.m can be used
      for complex or real-coordinate stretching.)

    
    """
    
    match len(args):
        case 6:
            epsxx = args[0]
            epsxy = args[1]
            epsyx = args[2]
            epsyy = args[3]
            epszz = args[4]
            boundary = args[5]
        case 4:
            epsxx = args[0]
            epsxy = np.zeros(np.shape(epsxx))
            epsyx = np.zeros(np.shape(epsxx))
            epsyy = args[1]
            epszz = args[2]
            boundary = args[3]
        case 2:
            print('len is 2')
            epsxx = args[0]
            epsxy = np.zeros(np.shape(epsxx))
            epsyx = np.zeros(np.shape(epsxx))
            epsyy = epsxx
            epszz = epsxx
            boundary = args[1]

    nx,ny = np.shape(epsxx)
    nx = nx + 1
    ny = ny + 1

    # now we pad eps on all sides by one grid point
    epsxx = np.hstack((epsxx[:,0].reshape(-1,1), epsxx, epsxx[:,ny - 2].reshape(-1,1)))
    epsxx = np.vstack(((np.transpose(epsxx[0,0:ny + 1].reshape(-1,1))), epsxx, np.transpose(epsxx[nx-2,0:ny + 1].reshape(-1,1))))

    epsyy = np.hstack((epsyy[:,0].reshape(-1,1), epsyy, epsyy[:,ny - 2].reshape(-1,1)))
    epsyy = np.vstack(((np.transpose(epsyy[0,0:ny + 1].reshape(-1,1))), epsyy, np.transpose(epsyy[nx-2,0:ny + 1].reshape(-1,1))))

    epsxy = np.hstack((epsxy[:,0].reshape(-1,1), epsxy, epsxy[:,ny - 2].reshape(-1,1)))
    epsxy = np.vstack(((np.transpose(epsxy[0,0:ny + 1].reshape(-1,1))), epsxy, np.transpose(epsxy[nx-2,0:ny + 1].reshape(-1,1))))

    epsyx = np.hstack((epsyx[:,0].reshape(-1,1), epsyx, epsyx[:,ny - 2].reshape(-1,1)))
    epsyx = np.vstack(((np.transpose(epsyx[0,0:ny + 1].reshape(-1,1))), epsyx, np.transpose(epsyx[nx-2,0:ny + 1].reshape(-1,1))))

    epszz = np.hstack((epszz[:,0].reshape(-1,1), epszz, epszz[:,ny - 2].reshape(-1,1)))
    epszz = np.vstack(((np.transpose(epszz[0,0:ny + 1].reshape(-1,1))), epszz, np.transpose(epszz[nx-2,0:ny + 1].reshape(-1,1))))

    k = 2*np.pi/wavelength  # free-space wavevector

    if np.isscalar(dx):
        dx = dx * np.ones((nx + 1, 1))
    else:
        dx = dx.reshape(-1,1)
        dx = np.vstack((dx[0], dx, dx[-1]))

    if np.isscalar(dy):
        dy = dy * np.ones((1, ny + 1))
    else:
        dy = dy.reshape(-1,1)
        check = dy
        dy = np.transpose(np.vstack((dy[0], dy, dy[-1])))


    n, s = [np.tile(dy[0,1:ny + 1],(nx,1)).flatten() for i in range(2)]
    e, w = [np.tile(dx[1:nx + 1,0],(ny,1)).flatten() for i in range(2)]

    print(f'n - {np.shape(n)}')
    print(f's - {np.shape(s)}')
    print(f'e - {np.shape(e)}')
    print(f'w - {np.shape(w)}')

    exx1, exx2, exx3, exx4 = [np.ones((1, nx * ny)) for i in range(4)]
    eyy1, eyy2, eyy3, eyy4 = [np.ones((1, nx * ny)) for i in range(4)]
    exy1, exy2, exy3, exy4 = [np.ones((1, nx * ny)) for i in range(4)]
    eyx1, eyx2, eyx3, eyx4 = [np.ones((1, nx * ny)) for i in range(4)]
    ezz1, ezz2, ezz3, ezz4 = [np.ones((1, nx * ny)) for i in range(4)]

    exx1 = np.transpose(epsxx[0:nx, 1:ny + 1]).flatten()
    exx2 = np.transpose(epsxx[0:nx, 0:ny]).flatten()
    exx3 = np.transpose(epsxx[1:nx + 1, 0:ny]).flatten()
    exx4 = np.transpose(epsxx[1:nx + 1, 1:ny + 1]).flatten()

    eyy1 = np.transpose(epsyy[0:nx, 1:ny + 1]).flatten()
    eyy2 = np.transpose(epsyy[0:nx, 0:ny]).flatten()
    eyy3 = np.transpose(epsyy[1:nx + 1, 0:ny]).flatten()
    eyy4 = np.transpose(epsyy[1:nx + 1, 1:ny + 1]).flatten()

    exy1 = np.transpose(epsxy[0:nx, 1:ny + 1]).flatten()
    exy2 = np.transpose(epsxy[0:nx, 0:ny]).flatten()
    exy3 = np.transpose(epsxy[1:nx + 1, 0:ny]).flatten()
    exy4 = np.transpose(epsxy[1:nx + 1, 1:ny + 1]).flatten()

    eyx1 = np.transpose(epsyx[0:nx, 1:ny + 1]).flatten()
    eyx2 = np.transpose(epsyx[0:nx, 0:ny]).flatten()
    eyx3 = np.transpose(epsyx[1:nx + 1, 0:ny]).flatten()
    eyx4 = np.transpose(epsyx[1:nx + 1, 1:ny + 1]).flatten()

    ezz1 = np.transpose(epszz[0:nx, 1:ny + 1]).flatten()
    ezz2 = np.transpose(epszz[0:nx, 0:ny]).flatten()
    ezz3 = np.transpose(epszz[1:nx + 1, 0:ny]).flatten()
    ezz4 = np.transpose(epszz[1:nx + 1, 1:ny + 1]).flatten()


    ns21 = n*eyy2+s*eyy1
    ns34 = n*eyy3+s*eyy4
    ew14 = e*exx1+w*exx4
    ew23 = e*exx2+w*exx3

    axxn = ((2*eyy4*e-eyx4*n)*(eyy3/ezz4)/ns34 + \
            (2*eyy1*w+eyx1*n)*(eyy2/ezz1)/ns21)/(n*(e+w))

    axxs = ((2*eyy3*e+eyx3*s)*(eyy4/ezz3)/ns34 + \
            (2*eyy2*w-eyx2*s)*(eyy1/ezz2)/ns21)/(s*(e+w))

    ayye = (2*n*exx4 - e*exy4)*exx1/ezz4/e/ew14/(n+s) + \
            (2*s*exx3 + e*exy3)*exx2/ezz3/e/ew23/(n+s)

    ayyw = (2*exx1*n + exy1*w)*exx4/ezz1/w/ew14/(n+s) + \
            (2*exx2*s - exy2*w)*exx3/ezz2/w/ew23/(n+s)

    axxe = 2/(e*(e+w)) + (eyy4*eyx3/ezz3 - eyy3*eyx4/ezz4)/(e+w)/ns34
    axxw = 2/(w*(e+w)) + (eyy2*eyx1/ezz1 - eyy1*eyx2/ezz2)/(e+w)/ns21
    ayyn = 2/(n*(n+s)) + (exx4*exy1/ezz1 - exx1*exy4/ezz4)/(n+s)/ew14
    ayys = 2/(s*(n+s)) + (exx2*exy3/ezz3 - exx3*exy2/ezz2)/(n+s)/ew23



    axxne = +eyx4*eyy3/ezz4/(e+w)/ns34
    axxse = -eyx3*eyy4/ezz3/(e+w)/ns34
    axxnw = -eyx1*eyy2/ezz1/(e+w)/ns21
    axxsw = +eyx2*eyy1/ezz2/(e+w)/ns21

    ayyne = +exy4*exx1/ezz4/(n+s)/ew14
    ayyse = -exy3*exx2/ezz3/(n+s)/ew23
    ayynw = -exy1*exx4/ezz1/(n+s)/ew14
    ayysw = +exy2*exx3/ezz2/(n+s)/ew23

    # center P 


    axxp = - axxn - axxs - axxe - axxw - axxne - axxse - axxnw - axxsw + \
           k**2*(n+s) * (eyy4 * eyy3 * e / ns34 + eyy1 * eyy2 * w / ns21) / (e+w)

    ayyp = - ayyn - ayys - ayye - ayyw - ayyne - ayyse - ayynw - ayysw + \
           k**2*(e+w) * (exx1 * exx4 * n / ew14 + exx2 * exx3 * s / ew23) / (n+s)

    axyn = (eyy3 * eyy4 / ezz4 / ns34 - eyy2 * eyy1 / ezz1 / ns21 + \
            s * (eyy2 * eyy4 - eyy1 * eyy3) / ns21 / ns34) / (e+w)

    axys = (eyy1 * eyy2 / ezz2 / ns21 - eyy4 * eyy3 / ezz3 / ns34 + \
            n * (eyy2 * eyy4 - eyy1 * eyy3) / ns21 / ns34) / (e+w)

    ayxe = (exx1 * exx4 / ezz4 / ew14 - exx2 * exx3 / ezz3 / ew23 + \
            w * (exx2 * exx4 - exx1 * exx3) / ew23 / ew14) / (n+s)

    ayxw = (exx3 * exx2 / ezz2 / ew23 - exx4 * exx1 / ezz1 / ew14 + \
            e * (exx4 * exx2 - exx1 * exx3) / ew23 / ew14) / (n+s)

    # checked to this....

        
    axye = (eyy4 * (1-eyy3 / ezz3) - eyy3 * (1-eyy4 / ezz4)) / ns34 / (e+w) - \
            2*(eyx1 * eyy2 / ezz1 * n * w / ns21 + \
                eyx2 * eyy1 / ezz2 * s * w / ns21 + \
                eyx4 * eyy3 / ezz4 * n * e / ns34 + \
                eyx3 * eyy4 / ezz3 * s * e / ns34 + \
                eyy1 * eyy2 * (1 / ezz1-1 / ezz2) * w**2 / ns21 + \
                eyy3 * eyy4 * (1 / ezz4-1 / ezz3) * e * w / ns34) / e / (e+w)**2

    axyw = (eyy2 * (1-eyy1 / ezz1) - eyy1 * (1-eyy2 / ezz2)) / ns21 / (e+w) - \
            2*(eyx4 * eyy3 / ezz4 * n * e / ns34 + \
              eyx3 * eyy4 / ezz3 * s * e / ns34 + \
              eyx1 * eyy2 / ezz1 * n * w / ns21 + \
              eyx2 * eyy1 / ezz2 * s * w / ns21 + \
              eyy4 * eyy3 * (1 / ezz3-1 / ezz4) * e**2 / ns34 + \
              eyy2 * eyy1 * (1 / ezz2-1 / ezz1) * w * e / ns21) / w / (e+w)**2

    ayxn = (exx4 * (1-exx1 / ezz1) - exx1 * (1-exx4 / ezz4)) / ew14 / (n+s) - \
            2*(exy3 * exx2 / ezz3 * e * s / ew23 + \
              exy2 * exx3 / ezz2 * w * s / ew23 + \
              exy4 * exx1 / ezz4 * e * n / ew14 + \
              exy1 * exx4 / ezz1 * w * n / ew14 + \
              exx3 * exx2 * (1 / ezz3-1 / ezz2) * s**2 / ew23 + \
              exx1 * exx4 * (1 / ezz4-1 / ezz1) * n * s / ew14) / n / (n+s)**2

    ayxs = (exx2 * (1-exx3 / ezz3) - exx3 * (1-exx2 / ezz2)) / ew23 / (n+s) - \
            2*(exy4 * exx1 / ezz4 * e * n / ew14 + \
              exy1 * exx4 / ezz1 * w * n / ew14 + \
              exy3 * exx2 / ezz3 * e * s / ew23 + \
              exy2 * exx3 / ezz2 * w * s / ew23 + \
              exx4 * exx1 * (1 / ezz1-1 / ezz4) * n**2 / ew14 + \
              exx2 * exx3 * (1 / ezz2-1 / ezz3) * s * n / ew23) / s / (n+s)**2

    axyne = +eyy3 * (1-eyy4 / ezz4) / (e+w) / ns34
    axyse = -eyy4 * (1-eyy3 / ezz3) / (e+w) / ns34
    axynw = -eyy2 * (1-eyy1 / ezz1) / (e+w) / ns21
    axysw = +eyy1 * (1-eyy2 / ezz2) / (e+w) / ns21

    ayxne = +exx1 * (1-exx4 / ezz4) / (n+s) / ew14
    ayxse = -exx2 * (1-exx3 / ezz3) / (n+s) / ew23
    ayxnw = -exx4 * (1-exx1 / ezz1) / (n+s) / ew14
    ayxsw = +exx3 * (1-exx2 / ezz2) / (n+s) / ew23

    axyp = -(axyn + axys + axye + axyw + axyne + axyse + axynw + axysw) - \
            k**2 * (w * (n * eyx1 * eyy2 + s * eyx2 * eyy1) / ns21 + \
                   e * (s * eyx3 * eyy4 + n * eyx4 * eyy3) / ns34) / (e+w)

    ayxp = -(ayxn + ayxs + ayxe + ayxw + ayxne + ayxse + ayxnw + ayxsw) - \
            k**2 * (n * (w * exy1 * exx4 + e * exy4 * exx1) / ew14 + \
                   s * (w * exy2 * exx3 + e * exy3 * exx2) / ew23) / (n+s)  

    ii = (np.linspace(0, nx*ny - 1, nx*ny)).astype(int)
    ii = np.transpose(ii.reshape(ny, nx))


    # checked up to this....

    # NORTH boundary

    ib = (np.zeros((nx,1))).astype(int)
    ib[:] = (ii[0:nx,ny - 1]).reshape((-1,1))

    match (boundary[0]):
        case 'S':
            sign = +1
        case 'A':
            sign = -1
        case '0':
            sign = 0
      

    axxs[ib]  = axxs[ib]  + sign*axxn[ib] 
    axxse[ib] = axxse[ib] + sign*axxne[ib] 
    axxsw[ib] = axxsw[ib] + sign*axxnw[ib] 
    ayxs[ib]  = ayxs[ib]  + sign*ayxn[ib] 
    ayxse[ib] = ayxse[ib] + sign*ayxne[ib] 
    ayxsw[ib] = ayxsw[ib] + sign*ayxnw[ib] 
    ayys[ib]  = ayys[ib]  - sign*ayyn[ib] 
    ayyse[ib] = ayyse[ib] - sign*ayyne[ib] 
    ayysw[ib] = ayysw[ib] - sign*ayynw[ib] 
    axys[ib]  = axys[ib]  - sign*axyn[ib] 
    axyse[ib] = axyse[ib] - sign*axyne[ib] 
    axysw[ib] = axysw[ib] - sign*axynw[ib] 

    # SOUTH BOUNDARY

    ib = (np.zeros((nx,1))).astype(int)
    ib[:] = (ii[0:nx,0]).reshape((-1,1))

    match (boundary[1]):
        case 'S':
            sign = +1
        case 'A':
            sign = -1
        case '0':
            sign = 0

    axxn[ib]  = axxn[ib]  + sign*axxs[ib]
    axxne[ib] = axxne[ib] + sign*axxse[ib]
    axxnw[ib] = axxnw[ib] + sign*axxsw[ib]
    ayxn[ib]  = ayxn[ib]  + sign*ayxs[ib]
    ayxne[ib] = ayxne[ib] + sign*ayxse[ib]
    ayxnw[ib] = ayxnw[ib] + sign*ayxsw[ib]
    ayyn[ib]  = ayyn[ib]  - sign*ayys[ib]
    ayyne[ib] = ayyne[ib] - sign*ayyse[ib]
    ayynw[ib] = ayynw[ib] - sign*ayysw[ib]
    axyn[ib]  = axyn[ib]  - sign*axys[ib]
    axyne[ib] = axyne[ib] - sign*axyse[ib]
    axynw[ib] = axynw[ib] - sign*axysw[ib]

    # EAST boundary

    ib = (np.zeros((1,ny))).astype(int)
    ib[:] = ii[nx - 1,0:ny]

    match (boundary[2]):
        case 'S':
            sign = +1
        case 'A':
            sign = -1
        case '0':
            sign = 0
            
    axxw[ib]  = axxw[ib]  + sign*axxe[ib]
    axxnw[ib] = axxnw[ib] + sign*axxne[ib]
    axxsw[ib] = axxsw[ib] + sign*axxse[ib]
    ayxw[ib]  = ayxw[ib]  + sign*ayxe[ib]
    ayxnw[ib] = ayxnw[ib] + sign*ayxne[ib]
    ayxsw[ib] = ayxsw[ib] + sign*ayxse[ib]
    ayyw[ib]  = ayyw[ib]  - sign*ayye[ib]
    ayynw[ib] = ayynw[ib] - sign*ayyne[ib]
    ayysw[ib] = ayysw[ib] - sign*ayyse[ib]
    axyw[ib]  = axyw[ib]  - sign*axye[ib]
    axynw[ib] = axynw[ib] - sign*axyne[ib]
    axysw[ib] = axysw[ib] - sign*axyse[ib]

    # WEST BOUNDARY

    ib = (np.zeros((1,ny))).astype(int)
    ib[:] = ii[0,0:ny]

    match (boundary[3]):
        case 'S':
            sign = +1
        case 'A':
            sign = -1
        case '0':
            sign = 0

    axxe[ib]  = axxe[ib]  + sign*axxw[ib]
    axxne[ib] = axxne[ib] + sign*axxnw[ib]
    axxse[ib] = axxse[ib] + sign*axxsw[ib]
    ayxe[ib]  = ayxe[ib]  + sign*ayxw[ib]
    ayxne[ib] = ayxne[ib] + sign*ayxnw[ib]
    ayxse[ib] = ayxse[ib] + sign*ayxsw[ib]
    ayye[ib]  = ayye[ib]  - sign*ayyw[ib]
    ayyne[ib] = ayyne[ib] - sign*ayynw[ib]
    ayyse[ib] = ayyse[ib] - sign*ayysw[ib]
    axye[ib]  = axye[ib]  - sign*axyw[ib]
    axyne[ib] = axyne[ib] - sign*axynw[ib]
    axyse[ib] = axyse[ib] - sign*axysw[ib]

    # Assemble sparse matrix

    iall = (np.zeros((1,nx*ny))).astype(int)
    iall[:] = (np.transpose(ii)).flatten()

    is_ = (np.zeros((1,nx*(ny-1)))).astype(int)
    is_[:] = (np.transpose(ii[0:nx,0:(ny-1)])).flatten()

    in_ = (np.zeros((1,nx*(ny-1)))).astype(int)
    in_[:] = (np.transpose(ii[0:nx,1:ny])).flatten()

    ie = (np.zeros((1,(nx-1)*ny))).astype(int)
    ie[:] = (np.transpose(ii[1:nx,0:ny])).flatten()

    iw = (np.zeros((1,(nx-1)*ny))).astype(int)
    iw[:] = (np.transpose(ii[0:(nx-1),0:ny])).flatten()

    ine = (np.zeros((1,(nx-1)*(ny-1)))).astype(int)
    ine[:] = (np.transpose(ii[1:nx, 1:ny])).flatten()

    ise = (np.zeros((1,(nx-1)*(ny-1)))).astype(int)
    ise[:] = (np.transpose(ii[1:nx, 0:(ny-1)])).flatten()

    isw = (np.zeros((1,(nx-1)*(ny-1)))).astype(int)
    isw[:] = (np.transpose(ii[0:(nx-1), 0:(ny-1)])).flatten()

    inw = (np.zeros((1,(nx-1)*(ny-1)))).astype(int)
    inw[:] = (np.transpose(ii[0:(nx-1), 1:ny])).flatten()

    v1 = np.hstack((iall,iw,ie,is_,in_,ine,ise,isw,inw))
    v2 = np.hstack((iall,ie,iw,in_,is_,isw,inw,ine,ise))

    v1 = np.squeeze(v1)
    v2 = np.squeeze(v2)

    v_axx = np.hstack((axxp[iall],axxe[iw],axxw[ie],axxn[is_],axxs[in_], axxsw[ine],axxnw[ise],axxne[isw],axxse[inw]))
    v_axx = np.squeeze(v_axx)
    Axx = sps.csr_matrix((v_axx, (v1, v2)))

    v_axy = np.hstack((axyp[iall],axye[iw],axyw[ie],axyn[is_],axys[in_], axysw[ine],axynw[ise],axyne[isw],axyse[inw]))
    v_axy = np.squeeze(v_axy)
    Axy = sps.csr_matrix((v_axy, (v1, v2)))

    v_ayx = np.hstack((ayxp[iall],ayxe[iw],ayxw[ie],ayxn[is_],ayxs[in_], ayxsw[ine],ayxnw[ise],ayxne[isw],ayxse[inw]))
    v_ayx = np.squeeze(v_ayx)
    Ayx = sps.csr_matrix((v_ayx, (v1, v2)))

    v_ayy = np.hstack((ayyp[iall],ayye[iw],ayyw[ie],ayyn[is_],ayys[in_], ayysw[ine],ayynw[ise],ayyne[isw],ayyse[inw]))
    v_ayy = np.squeeze(v_ayy)
    Ayy = sps.csr_matrix((v_ayy, (v1, v2)))

    A = sps.vstack([sps.hstack([Axx, Axy]), sps.hstack([Ayx, Ayy])])

    shift = (guess*k)**2
    options_tol = 1e-8

    [d,v] = sla.eigs(A, nmodes, sigma = shift, tol = options_tol)
    neff = wavelength * np.sqrt(np.diag(d))/(2*np.pi)
    print(f'neff - {neff}')

    phix = np.zeros((nx,ny,nmodes),dtype=np.complex_)
    phiy = np.zeros((nx,ny,nmodes),dtype=np.complex_)
    temp = np.zeros((nx,2*ny))

     # Normalize modes
    temp = np.zeros((nx*ny,2))
    for kk in range(0, nmodes):
        temp[:, 0] = v[0:nx*ny,kk]
        temp[:, 1] = v[nx*ny:,kk]
        result = np.sqrt(np.sum(np.abs(temp)**2,axis = 1))
        mag, ii = max(result), int(np.where(result == max(result))[0])
        if abs(temp[ii,0]) > abs(temp[ii,1]):
            jj = 0
        else:
            jj = 1
        mag = mag*temp[ii,jj]/np.abs(temp[ii,jj])
        temp = temp/mag
        phix[:,:,kk] = temp[:,0].reshape(nx,ny, order = 'F')
        phiy[:,:,kk] = temp[:,1].reshape(nx,ny, order = 'F')
    
    if nmodes == 1:
        phix = np.squeeze(phix)
        phiy = np.squeeze(phiy)
    
    return phix, phiy, neff, v

def postprocess(wavelength, neff, Hx, Hy, dx, dy, *args):
    """
      This function takes the two computed transverse magnetic
      fields (Hx and Hy) of an optical waveguide structure and
      solves for the remaining 4 vield components:  Hz, Ex, Ey,
      and Ez.

        Parameters
        ----------
        wavelength : optical wavelength
        
        neff : the calculated effective index of the optial mode
        
        Hx, Hy: the calculated transverse magnetic fields of the mode
        
        dx : horizontal grid spacing (vector or scalar)
        
        dy : vertical grid spacing (vector or scalar)
        
        *args : 
            eps - index mesh (isotropic materials)  OR:
        epsxx, epsxy, epsyx, epsyy, epszz - index mesh (anisotropic)
        boundary - 4 letter string specifying boundary conditions to be
        applied at the edges of the computation window.  
          boundary(1) = North boundary condition
          boundary(2) = South boundary condition
          boundary(3) = East boundary condition
          boundary(4) = West boundary condition
        The following boundary conditions are supported: 
          'A' - Hx is antisymmetric, Hy is symmetric.
          'S' - Hx is symmetric and, Hy is antisymmetric.
          '0' - Hx and Hy are zero immediately outside of the
                boundary. 
    
        Returns
        -------
      Hz - calculated longitudinal magnetic field.  This output will 
        have the same dimensions as Hx and Hy.
      Ex, Ey, Ez - calculated electric field.  These field components 
        are computed at the center of each element instead of on the
        edges or vertices.
    
    NOTES:
     
      1) This routine is meant to be used in conjunction with
      get_wgmodes, the vector eigenmode solver.  
     
      2) The boundary conditions and waveguide specifications
      (given in dx, dy, eps, and boundary) should be the same as
      what was used in wgmodes.m to compute the mode.
     
      3) The magnetic field components (Hx, Hy, and Hz) are
      calculated at the edges of each cell, whereas the electric
      field components are computed at the center of each cell.
      Therefore if size(eps) = [n,m], then the magnetic fields
      will have a size of [n+1,m+1] while the computed electric
      fields will have a size of [n,m].
     
      4) Even though get_wgmodes will optionally calculate more than
      one mode at a time, this postprocessing routine must be
      invoked separately for each computed mode.
     

    """
    
    match len(args):
        case 6:
            epsxx = args[0]
            epsxy = args[1]
            epsyx = args[2]
            epsyy = args[3]
            epszz = args[4]
            boundary = args[5]
        case 4:
            epsxx = args[0]
            epsxy = np.zeros(np.shape(epsxx))
            epsyx = np.zeros(np.shape(epsxx))
            epsyy = args[1]
            epszz = args[2]
            boundary = args[3]
        case 2:
            print('len is 2')
            epsxx = args[0]
            epsxy = np.zeros(np.shape(epsxx))
            epsyx = np.zeros(np.shape(epsxx))
            epsyy = epsxx
            epszz = epsxx
            boundary = args[1]
            
    nx,ny = np.shape(epsxx)
    nx = nx + 1
    ny = ny + 1

    # now we pad eps on all sides by one grid point
    epsxx = np.hstack((epsxx[:,0].reshape(-1,1), epsxx, epsxx[:,ny - 2].reshape(-1,1)))
    epsxx = np.vstack(((np.transpose(epsxx[0,0:ny + 1].reshape(-1,1))), epsxx, np.transpose(epsxx[nx-2,0:ny + 1].reshape(-1,1))))

    epsyy = np.hstack((epsyy[:,0].reshape(-1,1), epsyy, epsyy[:,ny - 2].reshape(-1,1)))
    epsyy = np.vstack(((np.transpose(epsyy[0,0:ny + 1].reshape(-1,1))), epsyy, np.transpose(epsyy[nx-2,0:ny + 1].reshape(-1,1))))

    epsxy = np.hstack((epsxy[:,0].reshape(-1,1), epsxy, epsxy[:,ny - 2].reshape(-1,1)))
    epsxy = np.vstack(((np.transpose(epsxy[0,0:ny + 1].reshape(-1,1))), epsxy, np.transpose(epsxy[nx-2,0:ny + 1].reshape(-1,1))))

    epsyx = np.hstack((epsyx[:,0].reshape(-1,1), epsyx, epsyx[:,ny - 2].reshape(-1,1)))
    epsyx = np.vstack(((np.transpose(epsyx[0,0:ny + 1].reshape(-1,1))), epsyx, np.transpose(epsyx[nx-2,0:ny + 1].reshape(-1,1))))

    epszz = np.hstack((epszz[:,0].reshape(-1,1), epszz, epszz[:,ny - 2].reshape(-1,1)))
    epszz = np.vstack(((np.transpose(epszz[0,0:ny + 1].reshape(-1,1))), epszz, np.transpose(epszz[nx-2,0:ny + 1].reshape(-1,1))))

    k = 2*np.pi/wavelength     # free-space wavevector
    b = np.squeeze(neff*k)     # propagation constant (eigenvalue)

    if np.isscalar(dx):
        dx = dx * np.ones((nx + 1, 1))
    else:
        dx = dx.reshape(-1,1)
        dx = np.vstack((dx[0], dx, dx[-1]))

    if np.isscalar(dy):
        dy = dy * np.ones((1, ny + 1))
    else:
        dy = dy.reshape(-1,1)
        check = dy
        dy = np.transpose(np.vstack((dy[0], dy, dy[-1])))

    n, s = [np.tile(dy[0,1:ny + 1],(nx,1)).flatten() for i in range(2)]
    e, w = [np.tile(dx[1:nx + 1,0],(ny,1)).flatten() for i in range(2)]

    print(f'n - {np.shape(n)}')
    print(f's - {np.shape(s)}')
    print(f'e - {np.shape(e)}')
    print(f'w - {np.shape(w)}')

    exx1, exx2, exx3, exx4 = [np.ones((1, nx * ny)) for i in range(4)]
    eyy1, eyy2, eyy3, eyy4 = [np.ones((1, nx * ny)) for i in range(4)]
    exy1, exy2, exy3, exy4 = [np.ones((1, nx * ny)) for i in range(4)]
    eyx1, eyx2, eyx3, eyx4 = [np.ones((1, nx * ny)) for i in range(4)]
    ezz1, ezz2, ezz3, ezz4 = [np.ones((1, nx * ny)) for i in range(4)]

    exx1 = np.transpose(epsxx[0:nx, 1:ny + 1]).flatten()
    exx2 = np.transpose(epsxx[0:nx, 0:ny]).flatten()
    exx3 = np.transpose(epsxx[1:nx + 1, 0:ny]).flatten()
    exx4 = np.transpose(epsxx[1:nx + 1, 1:ny + 1]).flatten()

    eyy1 = np.transpose(epsyy[0:nx, 1:ny + 1]).flatten()
    eyy2 = np.transpose(epsyy[0:nx, 0:ny]).flatten()
    eyy3 = np.transpose(epsyy[1:nx + 1, 0:ny]).flatten()
    eyy4 = np.transpose(epsyy[1:nx + 1, 1:ny + 1]).flatten()

    exy1 = np.transpose(epsxy[0:nx, 1:ny + 1]).flatten()
    exy2 = np.transpose(epsxy[0:nx, 0:ny]).flatten()
    exy3 = np.transpose(epsxy[1:nx + 1, 0:ny]).flatten()
    exy4 = np.transpose(epsxy[1:nx + 1, 1:ny + 1]).flatten()

    eyx1 = np.transpose(epsyx[0:nx, 1:ny + 1]).flatten()
    eyx2 = np.transpose(epsyx[0:nx, 0:ny]).flatten()
    eyx3 = np.transpose(epsyx[1:nx + 1, 0:ny]).flatten()
    eyx4 = np.transpose(epsyx[1:nx + 1, 1:ny + 1]).flatten()

    ezz1 = np.transpose(epszz[0:nx, 1:ny + 1]).flatten()
    ezz2 = np.transpose(epszz[0:nx, 0:ny]).flatten()
    ezz3 = np.transpose(epszz[1:nx + 1, 0:ny]).flatten()
    ezz4 = np.transpose(epszz[1:nx + 1, 1:ny + 1]).flatten()

    bzxne = (1/2*(n*ezz1*ezz2/eyy1+s*ezz2*ezz1/eyy2)*eyx4/ezz4/(n*eyy3+s*eyy4)/ezz2/ezz1/(n*eyy2+s*eyy1)/(e+w)*eyy3*eyy1*w*eyy2+1/2*(ezz3/exx2*ezz2*w+ezz2/exx3*ezz3*e)*(1-exx4/ezz4)/ezz3/ezz2/(w*exx3+e*exx2)/(w*exx4+e*exx1)/(n+s)*exx2*exx3*exx1*s)/b
    bzxse = (-1/2*(n*ezz1*ezz2/eyy1+s*ezz2*ezz1/eyy2)*eyx3/ezz3/(n*eyy3+s*eyy4)/ezz2/ezz1/(n*eyy2+s*eyy1)/(e+w)*eyy4*eyy1*w*eyy2+1/2*(ezz4/exx1*ezz1*w+ezz1/exx4*ezz4*e)*(1-exx3/ezz3)/(w*exx3+e*exx2)/ezz4/ezz1/(w*exx4+e*exx1)/(n+s)*exx2*n*exx1*exx4)/b
    bzxnw = (-1/2*(-n*ezz4*ezz3/eyy4-s*ezz3*ezz4/eyy3)*eyx1/ezz4/ezz3/(n*eyy3+s*eyy4)/ezz1/(n*eyy2+s*eyy1)/(e+w)*eyy4*eyy3*eyy2*e-1/2*(ezz3/exx2*ezz2*w+ezz2/exx3*ezz3*e)*(1-exx1/ezz1)/ezz3/ezz2/(w*exx3+e*exx2)/(w*exx4+e*exx1)/(n+s)*exx2*exx3*exx4*s)/b
    bzxsw = (1/2*(-n*ezz4*ezz3/eyy4-s*ezz3*ezz4/eyy3)*eyx2/ezz4/ezz3/(n*eyy3+s*eyy4)/ezz2/(n*eyy2+s*eyy1)/(e+w)*eyy4*eyy3*eyy1*e-1/2*(ezz4/exx1*ezz1*w+ezz1/exx4*ezz4*e)*(1-exx2/ezz2)/(w*exx3+e*exx2)/ezz4/ezz1/(w*exx4+e*exx1)/(n+s)*exx3*n*exx1*exx4)/b
    bzxn = ((1/2*(-n*ezz4*ezz3/eyy4-s*ezz3*ezz4/eyy3)*n*ezz1*ezz2/eyy1*(2*eyy1/ezz1/n**2+eyx1/ezz1/n/w)+1/2*(n*ezz1*ezz2/eyy1+s*ezz2*ezz1/eyy2)*n*ezz4*ezz3/eyy4*(2*eyy4/ezz4/n**2-eyx4/ezz4/n/e))/ezz4/ezz3/(n*eyy3+s*eyy4)/ezz2/ezz1/(n*eyy2+s*eyy1)/(e+w)*eyy4*eyy3*eyy1*w*eyy2*e+((ezz3/exx2*ezz2*w+ezz2/exx3*ezz3*e)*(1/2*ezz4*((1-exx1/ezz1)/n/w-exy1/ezz1*(2/n**2-2/n**2*s/(n+s)))/exx1*ezz1*w+(ezz4-ezz1)*s/n/(n+s)+1/2*ezz1*(-(1-exx4/ezz4)/n/e-exy4/ezz4*(2/n**2-2/n**2*s/(n+s)))/exx4*ezz4*e)-(ezz4/exx1*ezz1*w+ezz1/exx4*ezz4*e)*(-ezz3*exy2/n/(n+s)/exx2*w+(ezz3-ezz2)*s/n/(n+s)-ezz2*exy3/n/(n+s)/exx3*e))/ezz3/ezz2/(w*exx3+e*exx2)/ezz4/ezz1/(w*exx4+e*exx1)/(n+s)*exx2*exx3*n*exx1*exx4*s)/b
    bzxs =((1/2*(-n*ezz4*ezz3/eyy4-s*ezz3*ezz4/eyy3)*s*ezz2*ezz1/eyy2*(2*eyy2/ezz2/s**2-eyx2/ezz2/s/w)+1/2*(n*ezz1*ezz2/eyy1+s*ezz2*ezz1/eyy2)*s*ezz3*ezz4/eyy3*(2*eyy3/ezz3/s**2+eyx3/ezz3/s/e))/ezz4/ezz3/(n*eyy3+s*eyy4)/ezz2/ezz1/(n*eyy2+s*eyy1)/(e+w)*eyy4*eyy3*eyy1*w*eyy2*e+((ezz3/exx2*ezz2*w+ezz2/exx3*ezz3*e)*(-ezz4*exy1/s/(n+s)/exx1*w-(ezz4-ezz1)*n/s/(n+s)-ezz1*exy4/s/(n+s)/exx4*e)-(ezz4/exx1*ezz1*w+ezz1/exx4*ezz4*e)*(1/2*ezz3*(-(1-exx2/ezz2)/s/w-exy2/ezz2*(2/s**2-2/s**2*n/(n+s)))/exx2*ezz2*w-(ezz3-ezz2)*n/s/(n+s)+1/2*ezz2*((1-exx3/ezz3)/s/e-exy3/ezz3*(2/s**2-2/s**2*n/(n+s)))/exx3*ezz3*e))/ezz3/ezz2/(w*exx3+e*exx2)/ezz4/ezz1/(w*exx4+e*exx1)/(n+s)*exx2*exx3*n*exx1*exx4*s)/b
    bzxe = ((n*ezz1*ezz2/eyy1+s*ezz2*ezz1/eyy2)*(1/2*n*ezz4*ezz3/eyy4*(2/e**2-eyx4/ezz4/n/e)+1/2*s*ezz3*ezz4/eyy3*(2/e**2+eyx3/ezz3/s/e))/ezz4/ezz3/(n*eyy3+s*eyy4)/ezz2/ezz1/(n*eyy2+s*eyy1)/(e+w)*eyy4*eyy3*eyy1*w*eyy2*e+(-1/2*(ezz3/exx2*ezz2*w+ezz2/exx3*ezz3*e)*ezz1*(1-exx4/ezz4)/n/exx4*ezz4-1/2*(ezz4/exx1*ezz1*w+ezz1/exx4*ezz4*e)*ezz2*(1-exx3/ezz3)/s/exx3*ezz3)/ezz3/ezz2/(w*exx3+e*exx2)/ezz4/ezz1/(w*exx4+e*exx1)/(n+s)*exx2*exx3*n*exx1*exx4*s)/b
    bzxw = ((-n*ezz4*ezz3/eyy4-s*ezz3*ezz4/eyy3)*(1/2*n*ezz1*ezz2/eyy1*(2/w**2+eyx1/ezz1/n/w)+1/2*s*ezz2*ezz1/eyy2*(2/w**2-eyx2/ezz2/s/w))/ezz4/ezz3/(n*eyy3+s*eyy4)/ezz2/ezz1/(n*eyy2+s*eyy1)/(e+w)*eyy4*eyy3*eyy1*w*eyy2*e+(1/2*(ezz3/exx2*ezz2*w+ezz2/exx3*ezz3*e)*ezz4*(1-exx1/ezz1)/n/exx1*ezz1+1/2*(ezz4/exx1*ezz1*w+ezz1/exx4*ezz4*e)*ezz3*(1-exx2/ezz2)/s/exx2*ezz2)/ezz3/ezz2/(w*exx3+e*exx2)/ezz4/ezz1/(w*exx4+e*exx1)/(n+s)*exx2*exx3*n*exx1*exx4*s)/b
    bzxp = (((-n*ezz4*ezz3/eyy4-s*ezz3*ezz4/eyy3)*(1/2*n*ezz1*ezz2/eyy1*(-2/w**2-2*eyy1/ezz1/n**2+k**2*eyy1-eyx1/ezz1/n/w)+1/2*s*ezz2*ezz1/eyy2*(-2/w**2-2*eyy2/ezz2/s**2+k**2*eyy2+eyx2/ezz2/s/w))+(n*ezz1*ezz2/eyy1+s*ezz2*ezz1/eyy2)*(1/2*n*ezz4*ezz3/eyy4*(-2/e**2-2*eyy4/ezz4/n**2+k**2*eyy4+eyx4/ezz4/n/e)+1/2*s*ezz3*ezz4/eyy3*(-2/e**2-2*eyy3/ezz3/s**2+k**2*eyy3-eyx3/ezz3/s/e)))/ezz4/ezz3/(n*eyy3+s*eyy4)/ezz2/ezz1/(n*eyy2+s*eyy1)/(e+w)*eyy4*eyy3*eyy1*w*eyy2*e+((ezz3/exx2*ezz2*w+ezz2/exx3*ezz3*e)*(1/2*ezz4*(-k**2*exy1-(1-exx1/ezz1)/n/w-exy1/ezz1*(-2/n**2-2/n**2*(n-s)/s))/exx1*ezz1*w+(ezz4-ezz1)*(n-s)/n/s+1/2*ezz1*(-k**2*exy4+(1-exx4/ezz4)/n/e-exy4/ezz4*(-2/n**2-2/n**2*(n-s)/s))/exx4*ezz4*e)-(ezz4/exx1*ezz1*w+ezz1/exx4*ezz4*e)*(1/2*ezz3*(-k**2*exy2+(1-exx2/ezz2)/s/w-exy2/ezz2*(-2/s**2+2/s**2*(n-s)/n))/exx2*ezz2*w+(ezz3-ezz2)*(n-s)/n/s+1/2*ezz2*(-k**2*exy3-(1-exx3/ezz3)/s/e-exy3/ezz3*(-2/s**2+2/s**2*(n-s)/n))/exx3*ezz3*e))/ezz3/ezz2/(w*exx3+e*exx2)/ezz4/ezz1/(w*exx4+e*exx1)/(n+s)*exx2*exx3*n*exx1*exx4*s)/b

    bzyne = (1/2*(n*ezz1*ezz2/eyy1+s*ezz2*ezz1/eyy2)*(1-eyy4/ezz4)/(n*eyy3+s*eyy4)/ezz2/ezz1/(n*eyy2+s*eyy1)/(e+w)*eyy3*eyy1*w*eyy2+1/2*(ezz3/exx2*ezz2*w+ezz2/exx3*ezz3*e)*exy4/ezz3/ezz2/(w*exx3+e*exx2)/ezz4/(w*exx4+e*exx1)/(n+s)*exx2*exx3*exx1*s)/b
    bzyse = (-1/2*(n*ezz1*ezz2/eyy1+s*ezz2*ezz1/eyy2)*(1-eyy3/ezz3)/(n*eyy3+s*eyy4)/ezz2/ezz1/(n*eyy2+s*eyy1)/(e+w)*eyy4*eyy1*w*eyy2+1/2*(ezz4/exx1*ezz1*w+ezz1/exx4*ezz4*e)*exy3/ezz3/(w*exx3+e*exx2)/ezz4/ezz1/(w*exx4+e*exx1)/(n+s)*exx2*n*exx1*exx4)/b
    bzynw = (-1/2*(-n*ezz4*ezz3/eyy4-s*ezz3*ezz4/eyy3)*(1-eyy1/ezz1)/ezz4/ezz3/(n*eyy3+s*eyy4)/(n*eyy2+s*eyy1)/(e+w)*eyy4*eyy3*eyy2*e-1/2*(ezz3/exx2*ezz2*w+ezz2/exx3*ezz3*e)*exy1/ezz3/ezz2/(w*exx3+e*exx2)/ezz1/(w*exx4+e*exx1)/(n+s)*exx2*exx3*exx4*s)/b
    bzysw = (1/2*(-n*ezz4*ezz3/eyy4-s*ezz3*ezz4/eyy3)*(1-eyy2/ezz2)/ezz4/ezz3/(n*eyy3+s*eyy4)/(n*eyy2+s*eyy1)/(e+w)*eyy4*eyy3*eyy1*e-1/2*(ezz4/exx1*ezz1*w+ezz1/exx4*ezz4*e)*exy2/ezz2/(w*exx3+e*exx2)/ezz4/ezz1/(w*exx4+e*exx1)/(n+s)*exx3*n*exx1*exx4)/b
    bzyn = ((1/2*(-n*ezz4*ezz3/eyy4-s*ezz3*ezz4/eyy3)*ezz1*ezz2/eyy1*(1-eyy1/ezz1)/w-1/2*(n*ezz1*ezz2/eyy1+s*ezz2*ezz1/eyy2)*ezz4*ezz3/eyy4*(1-eyy4/ezz4)/e)/ezz4/ezz3/(n*eyy3+s*eyy4)/ezz2/ezz1/(n*eyy2+s*eyy1)/(e+w)*eyy4*eyy3*eyy1*w*eyy2*e+(ezz3/exx2*ezz2*w+ezz2/exx3*ezz3*e)*(1/2*ezz4*(2/n**2+exy1/ezz1/n/w)/exx1*ezz1*w+1/2*ezz1*(2/n**2-exy4/ezz4/n/e)/exx4*ezz4*e)/ezz3/ezz2/(w*exx3+e*exx2)/ezz4/ezz1/(w*exx4+e*exx1)/(n+s)*exx2*exx3*n*exx1*exx4*s)/b
    bzys = ((-1/2*(-n*ezz4*ezz3/eyy4-s*ezz3*ezz4/eyy3)*ezz2*ezz1/eyy2*(1-eyy2/ezz2)/w+1/2*(n*ezz1*ezz2/eyy1+s*ezz2*ezz1/eyy2)*ezz3*ezz4/eyy3*(1-eyy3/ezz3)/e)/ezz4/ezz3/(n*eyy3+s*eyy4)/ezz2/ezz1/(n*eyy2+s*eyy1)/(e+w)*eyy4*eyy3*eyy1*w*eyy2*e-(ezz4/exx1*ezz1*w+ezz1/exx4*ezz4*e)*(1/2*ezz3*(2/s**2-exy2/ezz2/s/w)/exx2*ezz2*w+1/2*ezz2*(2/s**2+exy3/ezz3/s/e)/exx3*ezz3*e)/ezz3/ezz2/(w*exx3+e*exx2)/ezz4/ezz1/(w*exx4+e*exx1)/(n+s)*exx2*exx3*n*exx1*exx4*s)/b
    bzye = (((-n*ezz4*ezz3/eyy4-s*ezz3*ezz4/eyy3)*(-n*ezz2/eyy1*eyx1/e/(e+w)+(ezz1-ezz2)*w/e/(e+w)-s*ezz1/eyy2*eyx2/e/(e+w))+(n*ezz1*ezz2/eyy1+s*ezz2*ezz1/eyy2)*(1/2*n*ezz4*ezz3/eyy4*(-(1-eyy4/ezz4)/n/e-eyx4/ezz4*(2/e**2-2/e**2*w/(e+w)))+1/2*s*ezz3*ezz4/eyy3*((1-eyy3/ezz3)/s/e-eyx3/ezz3*(2/e**2-2/e**2*w/(e+w)))+(ezz4-ezz3)*w/e/(e+w)))/ezz4/ezz3/(n*eyy3+s*eyy4)/ezz2/ezz1/(n*eyy2+s*eyy1)/(e+w)*eyy4*eyy3*eyy1*w*eyy2*e+(1/2*(ezz3/exx2*ezz2*w+ezz2/exx3*ezz3*e)*ezz1*(2*exx4/ezz4/e**2-exy4/ezz4/n/e)/exx4*ezz4*e-1/2*(ezz4/exx1*ezz1*w+ezz1/exx4*ezz4*e)*ezz2*(2*exx3/ezz3/e**2+exy3/ezz3/s/e)/exx3*ezz3*e)/ezz3/ezz2/(w*exx3+e*exx2)/ezz4/ezz1/(w*exx4+e*exx1)/(n+s)*exx2*exx3*n*exx1*exx4*s)/b
    bzyw = (((-n*ezz4*ezz3/eyy4-s*ezz3*ezz4/eyy3)*(1/2*n*ezz1*ezz2/eyy1*((1-eyy1/ezz1)/n/w-eyx1/ezz1*(2/w**2-2/w**2*e/(e+w)))-(ezz1-ezz2)*e/w/(e+w)+1/2*s*ezz2*ezz1/eyy2*(-(1-eyy2/ezz2)/s/w-eyx2/ezz2*(2/w**2-2/w**2*e/(e+w))))+(n*ezz1*ezz2/eyy1+s*ezz2*ezz1/eyy2)*(-n*ezz3/eyy4*eyx4/w/(e+w)-s*ezz4/eyy3*eyx3/w/(e+w)-(ezz4-ezz3)*e/w/(e+w)))/ezz4/ezz3/(n*eyy3+s*eyy4)/ezz2/ezz1/(n*eyy2+s*eyy1)/(e+w)*eyy4*eyy3*eyy1*w*eyy2*e+(1/2*(ezz3/exx2*ezz2*w+ezz2/exx3*ezz3*e)*ezz4*(2*exx1/ezz1/w**2+exy1/ezz1/n/w)/exx1*ezz1*w-1/2*(ezz4/exx1*ezz1*w+ezz1/exx4*ezz4*e)*ezz3*(2*exx2/ezz2/w**2-exy2/ezz2/s/w)/exx2*ezz2*w)/ezz3/ezz2/(w*exx3+e*exx2)/ezz4/ezz1/(w*exx4+e*exx1)/(n+s)*exx2*exx3*n*exx1*exx4*s)/b
    bzyp = (((-n*ezz4*ezz3/eyy4-s*ezz3*ezz4/eyy3)*(1/2*n*ezz1*ezz2/eyy1*(-k**2*eyx1-(1-eyy1/ezz1)/n/w-eyx1/ezz1*(-2/w**2+2/w**2*(e-w)/e))+(ezz1-ezz2)*(e-w)/e/w+1/2*s*ezz2*ezz1/eyy2*(-k**2*eyx2+(1-eyy2/ezz2)/s/w-eyx2/ezz2*(-2/w**2+2/w**2*(e-w)/e)))+(n*ezz1*ezz2/eyy1+s*ezz2*ezz1/eyy2)*(1/2*n*ezz4*ezz3/eyy4*(-k**2*eyx4+(1-eyy4/ezz4)/n/e-eyx4/ezz4*(-2/e**2-2/e**2*(e-w)/w))+1/2*s*ezz3*ezz4/eyy3*(-k**2*eyx3-(1-eyy3/ezz3)/s/e-eyx3/ezz3*(-2/e**2-2/e**2*(e-w)/w))+(ezz4-ezz3)*(e-w)/e/w))/ezz4/ezz3/(n*eyy3+s*eyy4)/ezz2/ezz1/(n*eyy2+s*eyy1)/(e+w)*eyy4*eyy3*eyy1*w*eyy2*e+((ezz3/exx2*ezz2*w+ezz2/exx3*ezz3*e)*(1/2*ezz4*(-2/n**2-2*exx1/ezz1/w**2+k**2*exx1-exy1/ezz1/n/w)/exx1*ezz1*w+1/2*ezz1*(-2/n**2-2*exx4/ezz4/e**2+k**2*exx4+exy4/ezz4/n/e)/exx4*ezz4*e)-(ezz4/exx1*ezz1*w+ezz1/exx4*ezz4*e)*(1/2*ezz3*(-2/s**2-2*exx2/ezz2/w**2+k**2*exx2+exy2/ezz2/s/w)/exx2*ezz2*w+1/2*ezz2*(-2/s**2-2*exx3/ezz3/e**2+k**2*exx3-exy3/ezz3/s/e)/exx3*ezz3*e))/ezz3/ezz2/(w*exx3+e*exx2)/ezz4/ezz1/(w*exx4+e*exx1)/(n+s)*exx2*exx3*n*exx1*exx4*s)/b

    ii = (np.linspace(0, nx*ny - 1, nx*ny)).astype(int)
    ii = np.transpose(ii.reshape(ny, nx))

    # NORTH boundary

    ib = (np.zeros((nx,1))).astype(int)
    ib[:] = (ii[0:nx,ny - 1]).reshape((-1,1))

    match (boundary[0]):
        case 'S':
            sign = +1
        case 'A':
            sign = -1
        case '0':
            sign = 0

    bzxs[ib]  = bzxs[ib]  + sign*bzxn[ib]
    bzxse[ib] = bzxse[ib] + sign*bzxne[ib]
    bzxsw[ib] = bzxsw[ib] + sign*bzxnw[ib]
    bzys[ib]  = bzys[ib]  - sign*bzyn[ib]
    bzyse[ib] = bzyse[ib] - sign*bzyne[ib]
    bzysw[ib] = bzysw[ib] - sign*bzynw[ib]

    # SOUTH BOUNDARY

    ib = (np.zeros((nx,1))).astype(int)
    ib[:] = (ii[0:nx,0]).reshape((-1,1))

    match (boundary[1]):
        case 'S':
            sign = +1
        case 'A':
            sign = -1
        case '0':
            sign = 0
            
    bzxn[ib]  = bzxn[ib]  + sign*bzxs[ib]
    bzxne[ib] = bzxne[ib] + sign*bzxse[ib]
    bzxnw[ib] = bzxnw[ib] + sign*bzxsw[ib]
    bzyn[ib]  = bzyn[ib]  - sign*bzys[ib]
    bzyne[ib] = bzyne[ib] - sign*bzyse[ib]
    bzynw[ib] = bzynw[ib] - sign*bzysw[ib]  

    # EAST boundary

    ib = (np.zeros((1,ny))).astype(int)
    ib[:] = ii[nx - 1,0:ny]

    match (boundary[2]):
        case 'S':
            sign = +1
        case 'A':
            sign = -1
        case '0':
            sign = 0  
            
    bzxw[ib]  = bzxw[ib]  + sign*bzxe[ib]
    bzxnw[ib] = bzxnw[ib] + sign*bzxne[ib]
    bzxsw[ib] = bzxsw[ib] + sign*bzxse[ib]
    bzyw[ib]  = bzyw[ib]  - sign*bzye[ib]
    bzynw[ib] = bzynw[ib] - sign*bzyne[ib]
    bzysw[ib] = bzysw[ib] - sign*bzyse[ib]

    # WEST boundary

    ib = (np.zeros((1,ny))).astype(int)
    ib[:] = ii[0,0:ny]

    match (boundary[3]):
        case 'S':
            sign = +1
        case 'A':
            sign = -1
        case '0':
            sign = 0
            
    bzxe[ib]  = bzxe[ib]  + sign*bzxw[ib]
    bzxne[ib] = bzxne[ib] + sign*bzxnw[ib]
    bzxse[ib] = bzxse[ib] + sign*bzxsw[ib]
    bzye[ib]  = bzye[ib]  - sign*bzyw[ib]
    bzyne[ib] = bzyne[ib] - sign*bzynw[ib]
    bzyse[ib] = bzyse[ib] - sign*bzysw[ib]        

    # Assemble sparse matrix

    iall = (np.zeros((1,nx*ny))).astype(int)
    iall[:] = (np.transpose(ii)).flatten()

    is_ = (np.zeros((1,nx*(ny-1)))).astype(int)
    is_[:] = (np.transpose(ii[0:nx,0:(ny-1)])).flatten()

    in_ = (np.zeros((1,nx*(ny-1)))).astype(int)
    in_[:] = (np.transpose(ii[0:nx,1:ny])).flatten()

    ie = (np.zeros((1,(nx-1)*ny))).astype(int)
    ie[:] = (np.transpose(ii[1:nx,0:ny])).flatten()

    iw = (np.zeros((1,(nx-1)*ny))).astype(int)
    iw[:] = (np.transpose(ii[0:(nx-1),0:ny])).flatten()

    ine = (np.zeros((1,(nx-1)*(ny-1)))).astype(int)
    ine[:] = (np.transpose(ii[1:nx, 1:ny])).flatten()

    ise = (np.zeros((1,(nx-1)*(ny-1)))).astype(int)
    ise[:] = (np.transpose(ii[1:nx, 0:(ny-1)])).flatten()

    isw = (np.zeros((1,(nx-1)*(ny-1)))).astype(int)
    isw[:] = (np.transpose(ii[0:(nx-1), 0:(ny-1)])).flatten()

    inw = (np.zeros((1,(nx-1)*(ny-1)))).astype(int)
    inw[:] = (np.transpose(ii[0:(nx-1), 1:ny])).flatten()

    v1 = np.hstack((iall,iw,ie,is_,in_,ine,ise,isw,inw))
    v2 = np.hstack((iall,ie,iw,in_,is_,isw,inw,ine,ise))

    v1 = np.squeeze(v1)
    v2 = np.squeeze(v2)

    v_bzx = np.hstack((bzxp[iall],bzxe[iw],bzxw[ie],bzxn[is_],bzxs[in_], bzxsw[ine],bzxnw[ise],bzxne[isw],bzxse[inw]))
    v_bzx = np.squeeze(v_bzx)

    Bzx = sps.csr_matrix((v_bzx, (v1, v2)))

    v_bzy = np.hstack((bzyp[iall],bzye[iw],bzyw[ie],bzyn[is_],bzys[in_], bzysw[ine],bzynw[ise],bzyne[isw],bzyse[inw]))
    v_bzy = np.squeeze(v_bzy)

    Bzy = sps.csr_matrix((v_bzy, (v1, v2)))

    # up to this.....

    B = sps.hstack((Bzx, Bzy))

    modes_hx_hy = np.hstack((Hx, Hy))
    modes_hx_hy = modes_hx_hy.reshape(2*nx*ny, order = 'F')/1j
    Hz = B @ modes_hx_hy
    Hz = Hz.reshape(nx, ny, order = 'F')

    nx = nx-1
    ny = ny-1

    exx = epsxx[1:nx+1,1:ny+1]
    exy = epsxy[1:nx+1,1:ny+1]
    eyx = epsyx[1:nx+1,1:ny+1]
    eyy = epsyy[1:nx+1,1:ny+1]
    ezz = epszz[1:nx+1,1:ny+1]
    edet = exx*eyy - exy*eyx

    h = np.transpose(np.tile(dx[1:nx + 1, 0], (ny, 1)))
    v = np.tile(dy[0, 1:ny + 1], (nx, 1))

    i1 = slice(0, nx), slice(1, ny + 1)
    i2 = slice(0, nx), slice(0, ny)
    i3 = slice(1,nx + 1), slice(0, ny)
    i4 = slice(1,nx + 1), slice(1, ny+1)

    Hx, Hy = [np.squeeze(i) for i in (Hx, Hy)]

    Dx = neff*(Hy[i1] + Hy[i2] + Hy[i3] + Hy[i4])/4 + (Hz[i1] + Hz[i4] - Hz[i2] - Hz[i3])/(1j*2*k*v)
    Dy = -neff*(Hx[i1] + Hx[i2] + Hx[i3] + Hx[i4])/4 - (Hz[i3] + Hz[i4] - Hz[i1] - Hz[i2])/(1j*2*k*h)
    Dz = ((Hy[i3] + Hy[i4] - Hy[i1] - Hy[i2])/(2*h) - (Hx[i1] + Hx[i4] - Hx[i2] - Hx[i3])/(2*v))/(1j*k)

    Ex = (eyy*Dx - exy*Dy)/edet
    Ey = (exx*Dy - eyx*Dx)/edet
    Ez = Dz/ezz
    
    return Hz, Ex, Ey, Ez

def normalize(dx, dy, Ex, Ey, Ez, Hx, Hy, Hz):
    """
    Normalizes all of the field components so that the mode has
    unity power (Poynting vector integrated over the cross section.)

    """
    Z0 = 119.9169832*np.pi # vacuum impedance
    [nx,ny] = np.shape(Ex)
    dx_, dy_ = [dx], [dy]

    if (len(dx_) != nx):
        dx_ = dx_*np.ones((nx,1))

    if (len(dy_) != ny):
        dy_ = dy_*np.ones((1,ny))

    ii = (np.linspace(0, (nx + 1)*(ny + 1) - 1, (nx + 1)*(ny + 1))).astype(int)
    ii = np.transpose(ii.reshape(ny + 1, nx + 1)) 

    i1 = slice(0, nx), slice(1, ny + 1)
    i2 = slice(0, nx), slice(0, ny)
    i3 = slice(1,nx + 1), slice(0, ny)
    i4 = slice(1,nx + 1), slice(1, ny+1)

    HXp = (Hx[i1] + Hx[i2]+ Hx[i3] + Hx[i4])/4
    HYp = (Hy[i1] + Hy[i2]+ Hy[i3] + Hy[i4])/4

    SZ = Z0*(np.conj(Ex) * HYp - np.conj(Ey) * HXp + Ex * np.conj(HYp) - Ey * np.conj(HXp))/4
    dA = dx_*dy_
    N = np.sqrt(sum(sum((SZ[:]*dA[:]))))
    ex = Z0*Ex/N
    ey = Z0*Ey/N
    ez = Z0*Ez/N
    hx = Hx/N
    hy = Hy/N
    hz = Hz/N
    return ex, ey, ez, hx, hy, hz
        
    
