# -*- coding: utf-8 -*-
"""
Created on Tue Jan 16 14:31:48 2024

@author: a.lantsov
"""

import numpy as np
import math
import matplotlib.pyplot as plt
import aux_funcs_visualization

# GETTING CONTOUR INDICES FOR EPSILON MAP

eps_test = np.flipud(eps)
eps_full = np.vstack((eps_test, eps))
x_ind, y_ind = aux_funcs_visualization.create_mask(np.rot90(eps_full))

# symmetrical expansion of obtained EM-components

# electric components

if boundary == '000A':
    Ex_full = np.vstack((np.flipud(Ex), Ex))
    
    Ey_asym = np.conj(Ey * (-1 * np.ones(np.shape(Ey))))
    Ey_full = np.vstack((np.flipud(Ey_asym), Ey))
    
    Ez_full = np.vstack((np.flipud(Ez), Ez))
    
    # magnetic components
    
    Hx_asym = np.conj(Hx * (-1 * np.ones(np.shape(Hx))))
    Hx_full = np.vstack((np.flipud(Hx_asym), Hx))
    
    Hy_full = np.vstack((np.flipud(Hy), Hy))
    Hz_full = np.vstack((np.flipud(Hz), Hz))
if boundary == '000S':
    Ex_asym = np.conj(Ex * (-1 * np.ones(np.shape(Ex))))
    Ex_full = np.vstack((np.flipud(Ex_asym), Ex))
    
    Ey_full = np.vstack((np.flipud(Ey), Ey))
    Ez_full = np.vstack((np.flipud(Ez), Ez))
    
    # magnetic components
    Hx_full = np.vstack((np.flipud(Hx), Hx))
    
    Hy_asym = np.conj(Hy * (-1 * np.ones(np.shape(Hy))))
    Hy_full = np.vstack((np.flipud(Hy_asym), Hy))
    
    Hz_full = np.vstack((np.flipud(Hz), Hz))

# PLOTTING

fig, axs = plt.subplots(2,3, figsize = (12,12))

plt.subplots_adjust(left=0.2,
                    bottom=0.1, 
                    right=0.9, 
                    top=0.5, 
                    wspace=0.15, 
                    hspace=0.05)

EM_list = [np.abs(i)**2 for i in (Hx_full, Hy_full, Hz_full, Ex_full, Ey_full, Ez_full)]
EM_title_list = [r'$\mathrm{|Hx|}^{2}$',
                 r'$\mathrm{|Hy|}^{2}$',
                 r'$\mathrm{|Hz|}^{2}$',
                 r'$\mathrm{|Ex|}^{2}$',
                 r'$\mathrm{|Ey|}^{2}$',
                 r'$\mathrm{|Ez|}^{2}$']

count = 0
for i in range(2):
    for j in range(3):
        im = axs[i][j].imshow(np.rot90(EM_list[count]))
        axs[i][j].scatter(y_ind, x_ind, s = 0.01, c = 'white',alpha = 1)
        axs[i][j].set_title(EM_title_list[count])
        # axs[i][j].set_xlabel('x, um')
        # axs[i][j].set_xlabel('x, um')
        axs[i][j].set_xticks([])
        axs[i][j].set_yticks([])
        cbar = fig.colorbar(im, ax = axs[i][j], pad = 0.025, shrink = 0.7)
        count+=1