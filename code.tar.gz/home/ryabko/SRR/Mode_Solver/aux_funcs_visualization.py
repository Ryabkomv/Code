# -*- coding: utf-8 -*-
"""
Created on Wed Jan 17 15:30:08 2024

@author: user
"""

import numpy as np
import math
import matplotlib.pyplot as plt

def get_3x3_deriv(arr):
    result = 0
    center_p = arr[1,1]
    new_arr = center_p * np.ones((3,3))
    if sum(sum(arr - new_arr))!=0:
        result = 1
    return result

def create_mask(image):
    num_x, num_y = np.shape(image)
    x_ind = []
    y_ind = []
    for i in range(1,num_x - 1):
        for j in range(1, num_y - 1):
            current_selection = image[i-1:i+2,j-1:j+2]
            result = get_3x3_deriv(current_selection)
            if result != 0:
                x_ind.append(i)
                y_ind.append(j)
    return x_ind, y_ind