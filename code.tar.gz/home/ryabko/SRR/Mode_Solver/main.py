# -*- coding: utf-8 -*-
"""
Created on Thu Jan 11 13:12:20 2024

@author: user
"""

import numpy as np
import matplotlib.pyplot as plt
import aux_funcs

# Refractive indices:
n1 = 3.34            # Lower cladding
n2 = 3.44            # Core
n3 = 1.00            # Upper cladding (air)

 # Layer heights:
h1 = 2.0             # Lower cladding
h2 = 1.3             # Core thickness
h3 = 0.5             # Upper cladding

 # Horizontal dimensions:
rh = 1.1             # Ridge height
rw = 1.0             # Ridge half-width
side = 1.5           # Space on side

 # Grid size:
dx = 0.0125          # grid size (horizontal)
dy = 0.0125          # grid size (vertical)

wavelength = 1.55    # vacuum wavelength
nmodes = 1           # number of modes to compute
guess = n2
boundary = '000A'

# create waveguide mesh

n = n1, n2, n3       # index tuple
h = h1, h2, h3       # height tuple

x,y,xc,yc,nx,ny,eps,edges = aux_funcs.get_waveguidemesh(n, h, rh, rw, side, dx, dy) 
args = eps, boundary
Hx, Hy, neff, v = aux_funcs.get_wgmodes(wavelength, n2, nmodes, dx, dy, eps, boundary)
Hz, Ex, Ey, Ez = aux_funcs.postprocess(wavelength, neff, Hx, Hy, dx, dy, eps, boundary)
Ex, Ey, Ez, Hx, Hy, Hz = aux_funcs.normalize(dx, dy, Ex, Ey, Ez, Hx, Hy, Hz)
# # for plotting components run 'plotting_aux.py' script
# for i in Ex,Ey,Ez,Hx,Hy,Hz:
#     print(np.max(np.max(np.abs(i))))