##### imports & initial params

from pathlib import Path
import autograd.numpy as np
import numpy as np
from gds_decomp import gds2npy
from params import *
from primitives import *
from mod_par import layers_descr, pixel_model, param_draw

def get_inc_power_distribution(focal_length, lens_radius, num_angles):
    """
    focal_length - focal length of the lens
    lens_radius -  lens radius
    num_angles -   amount of angles corresponding to the set of incident plane waves

    function returns a dictionary which contains set of incident plane waves angles and corresponding plane wave
    amplitude which should be used in RCWA solver for calculation of absorption
    """
    dx = 2e-6
    n_samples = int(lens_radius/dx)
    x = np.linspace(0, lens_radius + dx, n_samples + 1)          # coordinates along lens radius
    ta = [180*(np.arctan(i/focal_length))/np.pi for i in x]      # angles corresponding to distance between the focal point and a point at the coordinate axis
    tas = ta[1::]                                                # angles shifted by 1 step for getting solid angles list 
    a_inner = [tas[i] - ta[i] for i in range(0, n_samples)]      # list of solid angles corresponding to different angles of incidence
    power_distr = [i/np.max(a_inner) for i in a_inner]           # power distribution which equals to solid angles distribution
    power_distr.append(power_distr[-1])                          # getting list equal in size to angles list
    
    # filling up an incidence dictionary
    
    incidence_dict = {}
    if num_angles == 1:
        incidence_dict =  {0: 1}
    elif num_angles > 1:
        ind_set = [int(i) for i in np.linspace(0, n_samples, num_angles)]
        incidence_dict = {ta[i]:power_distr[i] for i in ind_set}
    else:
        print('incorrect amount of angles - normal incidence considered')
        incidence_dict =  {0: 1}
    return incidence_dict

# RCWA
nG_max = nG_max_grid #

gds_file = pixel_model['struct_file'] # !!! REPLACE THIS
gds_cell_prefix = pixel_model['cell'].lower()

inc_dict = get_inc_power_distribution(focal_length = 3e-3, lens_radius = 1.5e-3, num_angles = 1)

power_dist = list(inc_dict.values())
theta_list = list(inc_dict.keys())

def get_absorption():
    # print(f'get_absorption just started:{layers_descr}')
    Lx = param_draw['pix_scale'] * 12.0
    Ly = param_draw['pix_scale'] * 12.0
    ###### loading masks from gds-file
    gds_all = gds2npy(gds_file, Nx, Ny) # all cells are loaded
    # keys filtering
    masks = {}
    for k, v in gds_all.items():
        if k.startswith(gds_cell_prefix):
            layer_name = k.replace(gds_cell_prefix+'-','')
            masks[layer_name] =  v

    ##### constructing RCWA model

    # Table of layers:
    #_________________________________________________________________________________
    # no. | z_from | z_to   | thick  | materials
    # ----|--------| -------| ------ |------------------------------------------------
    #  0  | 0.00μm | 0.00μm | 0.00μm | Air [input]
    #  1  | 0.00μm | 0.15μm | 0.15μm | SiO2 (passivation)
    #  2  | 0.15μm | 0.22μm | 0.07μm | a-Si
    #  3  | 0.22μm | 0.25μm | 0.03μm | TiN (electrodes) + a-Si
    #  4  | 0.25μm | 0.40μm | 0.15μm | SiO2 (support) + TiN (anchors)
    #  5  | 0.40μm | 2.40μm | 2.00μm | Air (gap) + SiO2 (posts) + TiN (anchors 1&2)
    #  6  | 2.40μm | 2.50μm | 0.10μm | SiO2 (base) + TiN (anchors 1&2)
    #  7  | 2.50μm | 2.60μm | 0.10μm | SiO2 (base) + Al (electrode 2) + TiN (anchor 2)
    #  8  | 2.60μm | 2.70μm | 0.10μm | SiO2 (base) + Al (mirror) + TiN (anchor 1)
    #  9  | 2.70μm | 2.80μm | 0.10μm | SiO2 (base) + TiN (anchor 1)
    # 10  | 2.80μm | 2.90μm | 0.10μm | SiO2 (base) + Al (electrode 1)
    # 11  | 2.90μm | 3.00μm | 0.10μm | SiO2 (base)
    #---------------------------------------------------------------------------------

    epsAl = 10000 # some big number; TODO: replace by actual value

    # layer no. 1: SiO2 (passivation)
    epsSiO2Passivation_grid_range = np.array([
        masks['80'] * epsSiO2 for epsSiO2 in epsSiO2_range
    ])
    epsSiO2Passivation_grid_range[epsSiO2Passivation_grid_range == 0] = epsAir

    # layer no. 2: a-Si
    epsSi_grid_range = np.array([
        masks['80'] * epsSi for epsSi in epsSi_range
    ])
    epsSi_grid_range[epsSi_grid_range == 0] = epsAir

    # layer no. 3: TiN (electrodes) + a-Si
    epsTiN_grid_range = np.array([
        masks['45'] * epsTiN + (masks['80']-masks['45']) * epsSi
        for epsTiN, epsSi in np.stack([epsTiN_range, epsSi_range]).T
    ])
    epsTiN_grid_range[epsTiN_grid_range == 0] = epsAir

    # layer no. 4: SiO2 (support) + TiN (anchors)
    epsSiO2Support_grid_range = np.array([
        (masks['80']-masks['20']) * epsSiO2 + masks['20'] * epsTiN
        for epsSiO2, epsTiN in np.stack([epsSiO2_range, epsTiN_range]).T
    ])
    epsSiO2Support_grid_range[epsSiO2Support_grid_range == 0] = epsAir

    # layer no. 5: Air (gap) + SiO2 (posts) + TiN (anchors 1&2)
    epsAirGap_grid_range = np.array([
        masks['20'] * epsTiN + (masks['30']-masks['20']) * epsSiO2
        for epsTiN, epsSiO2 in np.stack((epsTiN_range, epsSiO2_range)).T
    ])
    epsAirGap_grid_range[epsAirGap_grid_range == 0] = epsAir

    # layer no. 6: SiO2 (base) + TiN (anchors 1&2)
    epsSiO2BaseTiNAnchors_grid_range = []
    for epsTiN, epsSiO2 in np.stack((epsTiN_range, epsSiO2_range)).T:
        eps_xy = masks['20'] * epsTiN
        eps_xy[eps_xy == 0] = epsSiO2
        epsSiO2BaseTiNAnchors_grid_range.append(eps_xy)
    epsSiO2BaseTiNAnchors_grid_range = np.array(epsSiO2BaseTiNAnchors_grid_range)

    # layer no. 7: SiO2 (base) + Al (electrode 2) + TiN (anchor 2)
    epsSiO2BaseAlElectrode2_grid_range = []
    for epsTiN, epsSiO2 in np.stack((epsTiN_range, epsSiO2_range)).T:
        eps_xy = masks['20'] * epsTiN
        eps_xy[:Nx//2,:Ny//2] = 0
        eps_xy += masks['11'] * epsAl
        eps_xy[eps_xy == 0] = epsSiO2
        epsSiO2BaseAlElectrode2_grid_range.append(eps_xy)
    epsSiO2BaseAlElectrode2_grid_range = np.array(epsSiO2BaseAlElectrode2_grid_range)

    # layer no. 8: SiO2 (base) + Al (mirror) + TiN (anchor 1)
    epsSiO2BaseAlMirror = []
    for epsTiN, epsSiO2 in np.stack((epsTiN_range, epsSiO2_range)).T:
        eps_xy = masks['20'] * epsTiN
        eps_xy[:Nx//2,:Ny//2] = 0
        eps_xy += masks['10'] * epsAl
        eps_xy[eps_xy == 0] = epsSiO2
        epsSiO2BaseAlMirror.append(eps_xy)
    epsSiO2BaseAlMirror = np.array(epsSiO2BaseAlMirror)

    # layer no. 9: SiO2 (base) + TiN (anchor 1)
    epsSiO2TiNAnchor1_grid_range = []
    for epsTiN, epsSiO2 in np.stack((epsTiN_range, epsSiO2_range)).T:
        eps_xy = masks['20'] * epsTiN
        eps_xy[:Nx//2,:Ny//2] = 0
        eps_xy[eps_xy == 0] = epsSiO2
        epsSiO2TiNAnchor1_grid_range.append(eps_xy)
    epsSiO2TiNAnchor1_grid_range = np.array(epsSiO2TiNAnchor1_grid_range)

    # layer no. 10: SiO2 (base) + Al (electrode 1)
    epsSiO2BaseAlElectrode1_grid_range = []
    for epsSiO2 in epsSiO2_range:
        eps_xy = np.zeros((Nx,Ny),dtype=complex)
        eps_xy[:,:] = masks['12'] * epsAl
        eps_xy[eps_xy == 0] = epsSiO2
        epsSiO2BaseAlElectrode1_grid_range.append(eps_xy)
    epsSiO2BaseAlElectrode1_grid_range = np.array(epsSiO2BaseAlElectrode1_grid_range)

    ##### calculating broadband response

    abs_list = []

    for theta_i in theta_list:

        print(f'current angle: {theta_i}')
        R_range = np.zeros(Nwl)
        T_range = np.zeros(Nwl)
        A_range = np.zeros(Nwl)
        obj_range = np.empty(Nwl, dtype=object)

        for i in range(Nwl):
            layers = [
                ['0',  0.00,                 epsAir],
                ['1',  layers_descr['80 top diel']['thickness'], epsSiO2Passivation_grid_range[i]],
                ['2',  layers_descr['80']['thickness'], epsSi_grid_range[i]],
                ['3',  layers_descr['45']['thickness'], epsTiN_grid_range[i]],
                ['4',  layers_descr['80 bottom diel']['thickness'], epsSiO2Support_grid_range[i]],
                ['5',  layers_descr['air']['thickness'], epsAirGap_grid_range[i]],
                ['6',  0.10, epsSiO2BaseTiNAnchors_grid_range[i]],
                ['7',  0.10, epsSiO2BaseAlElectrode2_grid_range[i]],
                ['8',  0.10, epsSiO2BaseAlMirror[i]],
                ['9',  0.10, epsSiO2TiNAnchor1_grid_range[i]],
                ['10', 0.10, epsSiO2BaseAlElectrode1_grid_range[i]],
                ['11', 0.10, epsSiO2_range[i]],
            ]
            R_range[i], T_range[i], A_range[i], obj_range[i] =\
                grcwa_RTA(nG_max, Lx, Ly, wl_range[i], theta_i, phi_deg,
                        layers, P_wave, return_obj=True)

            sys.stdout.write('\r')
            sys.stdout.write(f'{(i + 1) * 100 / Nwl:.1f} %  ')
            sys.stdout.write(f'{i * int(20 / Nwl) * "="}')

        A_mean = np.mean(A_range)
        abs_list.append(A_mean)
    total_absorption = np.average(abs_list, weights=power_dist)


    return total_absorption
