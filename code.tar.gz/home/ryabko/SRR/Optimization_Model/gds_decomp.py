#!python3

''' GDS decomposer

This script decomposes input GDS on cells and layers and saves the result as
a series of SVG/PNG, or NumPy file.

"data" is default directory for saving files.

Script mode example:
$ python gds_decomp.py -i data/pixels.gds -ow 100 -oh 100 -png -npz

Usage example:
>>> import gds_decomp
>>> arr = gds_decomp.gds2npy('data/pixels.gds')

Requirements:
- Python>=3.9
- gdspy
- NumPy
- CairoSVG
- Matplotlib
'''

__author__  = 'Alexey Wolf'
__date__    = '2022/03/15'
__email__   = 'alexey.wolf@samsung.com'
__version__ = 'testing'


#%% init

import argparse, io
from pathlib import Path
import gdspy
import numpy as np
import cairosvg
import matplotlib.pyplot as plt

DEBUG_FLAG = False # for debugging in IDE

## TODO: Again paths definitions...

# default dirs to save data
svg_save_dir = Path('data').joinpath('svg')
png_save_dir = Path('data').joinpath('png')
npz_save_dir = Path('data').joinpath('npz')

#%% gds2svg

def gds2svg(infile, save_result=False, save_dir=svg_save_dir):

    gds_lib = gdspy.GdsLibrary(infile=infile)

    header = 'cell_name: (layer_names)'
    print(header, '-'*len(header), sep='\n')
    
    svg_dict = {}
    
    transparent_style = {'stroke-opacity': '0', 'fill-opacity': '0'}
    black_style       = {'stroke-opacity': '0', 'fill-opacity': '1', 'fill': 'black'}
    
    for cell in gds_lib.top_level():
        print(f'{cell.name}', end=': ')
        ld, lt = cell.get_svg_classes()
        all_layers = set(layer for layer, typ in ld.union(lt))
        print('(', end='')
        for keep in all_layers:
            print(keep, end=',')
            style = {
                (layer, typ): (transparent_style if layer != keep else black_style) for layer, typ in ld
                }
            buffer = io.StringIO()
            cell.write_svg(buffer, style=style, scaling=1, background=None)
            svg_dict[f'{cell.name}-{keep}'] = buffer.getvalue()
        print(')', end='\n')

    if save_result:
        Path(save_dir).mkdir(parents=True, exist_ok=True)
        for k, v in svg_dict.items():
            save_path =  Path(save_dir).joinpath(k+'.svg')
            mode = 'w' if save_path.exists() else 'x'
            with open(save_path, mode) as f:
                f.write(v)
        print('svg files was saved in ' + str(save_dir) +' directory')        

    return svg_dict


#%% svg2png

def svg2png(svg_dict, output_width=100, output_height=100,
            save_result=False, save_dir=png_save_dir):

    png_dict = {}

    for k, v in svg_dict.items():
            png = cairosvg.svg2png(v, output_width=output_width, output_height=output_height)
            png_dict[k] = png

    if save_result:
        Path(save_dir).mkdir(parents=True, exist_ok=True)
        for k, v in png_dict.items():
            save_path =  Path(save_dir).joinpath(k+'.png')
            mode = 'wb' if save_path.exists() else 'xb'
            with open(save_path, mode) as f:
                f.write(v)
        print('png files was saved in ' + str(save_dir) +' directory') 

    return png_dict


#%% png2npy

def png2npy(png_dict, save_result=False, save_dir=npz_save_dir):

    npy_dict = {}

    for k, v in png_dict.items():
        npy_dict[k] = plt.imread(io.BytesIO(v))[:,:,3] # ! only the last layer will be saved

    if save_result:
        Path(save_dir).mkdir(parents=True, exist_ok=True)
        save_path =  Path(save_dir).joinpath('array.npz')
        np.savez(save_path, **npy_dict)
        print('npz file was saved in ' + str(save_dir) +' directory') 

    return npy_dict


#%% gds2npy

def gds2npy(gdsfile, output_width=100, output_height=100,
            save_as_svg=False, save_as_png=False, save_as_npz=False):

    svg_dict = gds2svg(gdsfile, save_result=save_as_svg)
    png_dict = svg2png(svg_dict, output_width, output_height, save_result=save_as_png)
    npy_dict = png2npy(png_dict, save_result=save_as_npz)

    return npy_dict


#%% gds2polygons

def gds2polygons(infile, plot_result=False, plot_alpha=0.5):
    
    all_polygons_dict = {} # {cell_key: {layer_key: array}, ...} 
    
    gds_lib = gdspy.GdsLibrary(infile=infile)
    
    for cell in gds_lib.top_level():
        cell_polygons_dict = {}        
        print(f'{cell.name}', end=': ')
        all_layers = cell.get_layers()
        print('(', end='')
        for layer in all_layers:
            print(layer, end=',')
            cell_polygons_dict[layer] = cell.get_polygons(by_spec=(layer,0))
        print(')', end='\n')
        all_polygons_dict[cell.name] = cell_polygons_dict
        
    if plot_result:
        fig, axs = plt.subplots(1, len(all_polygons_dict), figsize=(18,4))

        for i, (cell_name, pc_dict) in enumerate(all_polygons_dict.items()):
            for layer_name, pl_list in pc_dict.items():
                [axs[i].fill(p[:,0], p[:,1], alpha=plot_alpha) for p in pl_list] # layer may contain multiple polygons
                axs[i].set_title(cell_name)
                axs[i].set_aspect('equal', adjustable='box')
        
    return all_polygons_dict


# #%% run all

# if __name__ == '__main__':
    
#     if DEBUG_FLAG:
#         # get parent directory
#         curr_dir = Path(__file__).parent
#         gdsfile = curr_dir.joinpath('data', 'pixels.gds')
#         output_width_width, output_width_height = 100, 100
#         save_as_svg, save_as_png, save_as_npz = True, True, True
    
#     else:
        
#         parser = argparse.ArgumentParser()
#         parser.add_argument('-i', type=str, required=True, help='gds file name')
#         parser.add_argument('-svg', action=argparse.BooleanOptionalAction, help='save as svg')
#         parser.add_argument('-png', action=argparse.BooleanOptionalAction, help='save as png')
#         parser.add_argument('-npz', action=argparse.BooleanOptionalAction, help='save as npz')
#         parser.add_argument('-ow', type=int, default=100, help='output image/array width (px)')
#         parser.add_argument('-oh', type=int, default=100, help='output image/array height (px)')
#         args = parser.parse_args()

#         print(vars(args))

#         gdsfile = args.i
#         output_width_width, output_width_height = args.ow, args.oh
#         save_as_svg, save_as_png, save_as_npz = args.svg, args.png, args.npz

#     gds2npy(gdsfile, output_width_width, output_width_height, save_as_svg, save_as_png, save_as_npz)

# # %%
