# Optimization_Model

The mode performs optimization of the pixel structure (topology of TiN finger-type layer, thickness of TiN layer / aSi layer / Air gap / Support SiO2 layer / Passivation SiO2 layer) minimizing NETD of the system. In order to start run "optimization_comsol.py". The project requires the next modules installed: [nlopt](https://nlopt.readthedocs.io/en/latest/#download-and-installation), [gdspy](https://gdspy.readthedocs.io/en/stable/index.html)

## Running at supercomp

We need python virtual environment with all the dependencies prepared in advance.

### 0. Creating python virtual environment `lwir_env.tar.gz`

At any linux PC with python and conda (GPU comp is fine), create new conda environment and install requirements:

```bash
$ conda create -n lwir_env pip numpy scipy matplotlib cairosvg autograd
$ conda activate lwir_env
$ pip install gdspy grcwa mph nlopt
$ conda deactivate
```

Install [conda-pack](https://conda.github.io/conda-pack/) and pack the environment to tar.gz archive:

```bash
$ conda install conda-pack
$ conda pack -n lwir_env
```

This will create `lwir_env.tar.gz` archive we need in current directory.

### 1. Copy everything to supercomp

For a while, we suppose a following default directory structure for simulation scripts (~/ is user home at login server):

```
> ~/LWIR                        # simulation root directory
|   > /lwir_env                 # lwir_env python virtual environment
|   > /Optimization_Model       # local repo clone
|   |   > /data                 # optical spectra
|   |   > /data_comsol          # gds and mph files
|   |   > *.py script files
|   |   > ...
|   |   > run_all.sh            # bash script for starting simulation/optimization
|   > lwir_env.tar.gz           # lwir_env python virtual environment archive
```

1. Login to supercomp login server and create simulation root directory:

```bash
[user@loginx ~]$ mkdir LWIR
```

2. Copy `lwir_env.tar.gz` and `Optimization_Model` folder from github to simulation root directory  `~\LWIR` at supercomp login server.

3. Unpack virtual environment:

```bash
[user@loginx ~]$ cd LWIR
[user@loginx LWIR]$ mkdir lwir_env
[user@loginx LWIR]$ tar -xzf lwir_env.tar.gz -C lwir_env
```

At this point the directory structure should looks like the scheme above.
	
### 2. Start simulation

1. At login server, connect to etxssr01 server: 

```bash
[user@loginx LWIR]$ ssh etxssr01
```

and go to simulation directory

```bash
[user@etxssr01 ~]$ cd LWIR
[user@etxssr01 LWIR]$ cd Opt*
```

2. We are ready to start. Type

```bash
[user@etxsrr01 Optimization_Model]$ ./run_all.sh
```

and wait for results. Highly likely, there will be License Warning message either about comsol itself, or ECAD import module.
Script checks available license first, and starts simulation only if both licenses are available.


