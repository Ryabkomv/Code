#!python3

''' Library of materials for LWIR absorber

This script/module loads complex permittivity for material used in the project.
Data is interpolated with a cubic spline.

The foollowing materials are available:
- Si   - https://refractiveindex.info/?shelf=main&book=Si&page=Chandler-Horowitz
- SiO2 - https://refractiveindex.info/?shelf=main&book=SiO2&page=Kischkat
- SiN  - https://refractiveindex.info/?shelf=main&book=Si3N4&page=Kischkat
- TiN  - (HQ data)

Example of usage:
>>> from materials import Si_eps, SiO2_eps, TiN_eps
>>> lam_range = np.linspace(8.1, 11.9, 39)
>>> Si_eps_range = Si_eps(lam_range)
>>> SiO2_eps_range = SiO2_eps(lam_range)
>>> TiN_eps_range = TiN_eps(lam_range)

Requirements:
- Python>=3.9
- NumPy
- SciPy
- Matplotlib
'''

__author__  = 'Alexey Wolf'
__date__    = '2022/03/15'
__email__   = 'alexey.wolf@samsung.com'
__version__ = 'testing'


import logging
from pathlib import Path
import numpy as np
import matplotlib.pyplot as plt
from scipy.interpolate import CubicSpline


## TODO: another one way to get path to data.
## In mod_par.py and optimizer_grid_simple.py path was hardcoded and changed to 
## os.path.expanduser("~") 
## Need to select one way..

# get parent directory
curr_dir = Path(__file__).parent

Si_n_datafile = curr_dir.joinpath(curr_dir, 'data', 'Si_n_Chandler.txt')
Si_k_datafile = curr_dir.joinpath(curr_dir, 'data', 'Si_k_Chandler.txt')
SiO2_datafile = curr_dir.joinpath(curr_dir, 'data', 'SiO2_Kischkat.txt')
SiN_datafile  = curr_dir.joinpath(curr_dir, 'data', 'SiN_Kischkat.txt')
TiN_datafile  = curr_dir.joinpath(curr_dir, 'data', 'TiN_nk_measured_new.txt')


def Si_eps(wls_range):
    
    Si_n_wls, Si_n = np.loadtxt(Si_n_datafile, delimiter='\t', skiprows=1, unpack=True)
    Si_k_wls, Si_k = np.loadtxt(Si_k_datafile, delimiter='\t', skiprows=1, unpack=True)
    logging.info('Si epsilon was loaded.')

    Si_wl_min = max([min(Si_n_wls),min(Si_k_wls)])
    Si_wl_max = min([max(Si_n_wls),max(Si_k_wls)])
    if (min(wls_range) < Si_wl_min) | (max(wls_range) > Si_wl_max):
        raise Exception(f'Epsilon is defined in the range: {Si_wl_min:.3f}--{Si_wl_max:.3f} um')
    else:
        Si_cs_n = CubicSpline(Si_n_wls, Si_n)
        Si_cs_k = CubicSpline(Si_k_wls, Si_k)
        eps = (Si_cs_n(wls_range) + 1j*Si_cs_k(wls_range))**2
        return eps

def SiO2_eps(wls_range):
    
    SiO2_wls, SiO2_n, SiO2_k = np.loadtxt(SiO2_datafile, delimiter='\t', skiprows=1, unpack=True)    
    logging.info('SiO2 epsilon was loaded.')

    if (min(wls_range) < min(SiO2_wls)) | (max(wls_range) > max(SiO2_wls)):
        raise Exception(f'Epsilon is defined in the range: {min(SiO2_wls):.3f}--{max(SiO2_wls):.3f} um')
    else:
        SiO2_cs_n = CubicSpline(SiO2_wls, SiO2_n)
        SiO2_cs_k = CubicSpline(SiO2_wls, SiO2_k)
        eps = (SiO2_cs_n(wls_range) + 1j*SiO2_cs_k(wls_range))**2
        return eps

def SiN_eps(wls_range):
    
    SiN_wls, SiN_n, SiN_k = np.loadtxt(SiN_datafile, delimiter='\t', skiprows=1, unpack=True)    
    logging.info('SiN epsilon was loaded.')

    if (min(wls_range) < min(SiN_wls)) | (max(wls_range) > max(SiN_wls)):
        raise Exception(f'Epsilon is defined in the range: {min(SiN_wls):.3f}--{max(SiN_wls):.3f} um')
    else:
        SiN_cs_n = CubicSpline(SiN_wls, SiN_n)
        SiN_cs_k = CubicSpline(SiN_wls, SiN_k)
        eps = (SiN_cs_n(wls_range) + 1j*SiN_cs_k(wls_range))**2
        return eps
    
def TiN_eps(wls_range):

    TiN_wls, TiN_n, TiN_k = np.loadtxt(TiN_datafile, delimiter=',', skiprows=1, unpack=True)
    logging.info('TiN epsilon was loaded.')

    if (min(wls_range) < min(TiN_wls)) | (max(wls_range) > max(TiN_wls)):
        raise Exception(f'Epsilon is defined in the range: {min(TiN_wls):.3f}--{max(TiN_wls):.3f} um')
    else:
        TiN_cs_n = CubicSpline(TiN_wls, TiN_n)
        TiN_cs_k = CubicSpline(TiN_wls, TiN_k)
        eps = (TiN_cs_n(wls_range) + 1j*TiN_cs_k(wls_range))**2
        return eps
    
def metal_eps(wls_range, metal='Al'):
    ## Data from https://doi.org/10.1364/AO.37.005271
    ## Lorentz-Drude fit params for several metals in wide spectral range
    data = {'Al':{'wl_min': 0.1,    # um  , Fig 4: 100  -> 0.1 um
                  'wl_max': 100.0,  # um
                  'wp': 14.98,      # eV
                  'f0': 0.523,      # -
                  'G0': 0.047,      # eV
                  'f': [0.227, 0.050,0.116,0.03], # -
                  'G': [0.333, 0.312,1.351,3.382], # eV
                  'w': [0.162, 1.544, 1.808, 3.473] # eV                  
                  },
            'Au':{'wl_min': 1.239/5,    # um  , Fig 2: 0.2  -> 5 eV
                  'wl_max': 1.239/0.2,  # um
                  'wp': 9.03,      # eV
                  'f0': 0.76,      # -
                  'G0': 0.053,     # eV
                  'f': [0.024, 0.010,0.071,0.601,4.384], # -
                  'G': [0.241, 0.345,0.87,2.494,2.214], # eV
                  'w': [0.415, 0.83, 2.969, 4.304, 13.32] # eV                  
                  }
        }
    if (metal not in data.keys()):
        raise Exception('metal_eps(): unknown metal')
        return wls_range*0  # Do we need returns here?
    d = data[metal]
    if (min(wls_range) < d['wl_min']) | (max(wls_range) > d['wl_max']):
        raise Exception('metal_eps(): out of range')
        return wls_range*0
        ##raise Exception(f'Epsilon is defined in the range: {min(TiN_wls):.3f}--{max(TiN_wls):.3f} um') 
        ## TODO: how to put d['wl_min'] and d['wl_min'] with '' inside this message?? :)
    w = 1.239/wls_range  ## um -> eV
    eps = 1 - d['f0']*d['wp']**2 / (w * (w - 1j * d['G0']))
    for idx in range(len(d['f'])):
        eps = eps + d['f'][idx]*d['wp']**2 / ( d['w'][idx]**2 - w**2 + 1j*w*d['G'][idx] )
    return eps

def plot_nk(wls, func, label):
    
    eps = func(wls)
    
    fig, ax = plt.subplots(1,1,figsize=(8,3))
    ax.plot(wls, eps.real, 'o', fillstyle='none', label='Re')
    ax.plot(wls, eps.imag, 'o', fillstyle='none', label='Im')
    ax.set_title(label+' epsilon')
    ax.set_xlabel('wavelength, nm')
    ax.set_ylabel('epsilon')
    ax.legend()
    fig.tight_layout()
    fig.show()

if __name__ == '__main__':
    
    wls_range = np.linspace(8.1, 11.9, 101)
    plot_nk(wls_range, Si_eps, 'Si')
    plot_nk(wls_range, SiO2_eps, 'SiO2')
    plot_nk(wls_range, SiN_eps, 'SiN')
    plot_nk(wls_range, TiN_eps, 'TiN')
