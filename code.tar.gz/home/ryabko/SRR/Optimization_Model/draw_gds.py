
import gdspy
import numpy as np
from mod_par import param_draw, update_layers_descr

def draw_route():

    # we get variables from the parameters dictionary
    path_thck, radius, circ_gap, start_x, start_y, coeff_dist, max_vert,\
        vals, mult, left_x_bound, right_x_bound, pix_scale, \
        infile, outfile, cell, layer, datatype = param_draw.values()

    # we open file and select cell and layer
    gdsii = gdspy.GdsLibrary(infile=infile)
    a_test = gdsii.cells[cell]
    layer_cur = {"layer": layer, "datatype": datatype}

    # update parameters according to pixel size scale factor
    start_x*=pix_scale
    start_y*=pix_scale
    left_x_bound*=pix_scale
    right_x_bound*=pix_scale
    max_vert*=pix_scale

    # initial segment - down and left, then check
    init_shift = 1.2*pix_scale
    end_shift = 0.7*pix_scale

    # polygons enlargement
    for i in range(11):
        existing_polygon = a_test.polygons[i]
        existing_polygon = existing_polygon.scale(pix_scale, pix_scale, (0,0))
        a_test.add(existing_polygon)

    # an initial segment with zero length is placed in the cell
    pm1 = gdspy.Path(path_thck, (start_x, start_y), number_of_paths=1, distance=0)

    pm1.segment(init_shift, direction='-y', final_width = path_thck)
    pm1.segment(0.5 * path_thck, direction='+y', final_width=path_thck)
    dist_hor = np.abs(left_x_bound - start_x + path_thck)
    pm1.segment(dist_hor, direction='-x', final_width=path_thck)
    pm1.segment(0.5 * path_thck, direction='+x', final_width=path_thck)

    # calculate length of full horizontal segment
    hor_right = dist_hor + (right_x_bound - start_x - path_thck)

    # calculate length of full vertical segment
    ver_down = coeff_dist * path_thck

    # calculate amount of segments available
    num_sections = int((max_vert - init_shift - end_shift) / (2 * ver_down - path_thck))

    lengths = (ver_down, 0.5 * path_thck, hor_right, 0.5 * path_thck, ver_down, 0.5 * path_thck, hor_right, 0.5 * path_thck)
    directions = ('-y','+y','+x','-x','-y','+y','-x','+x')

    # put finger-type slit for each sections
    for i in range(num_sections):
        for j,k in zip(lengths, directions):
            pm1.segment(j, direction=k, final_width=path_thck)

    # final section down to contact
    hor_last = np.abs(left_x_bound + start_x + path_thck)
    pm1.segment(hor_last, direction='+x', final_width=path_thck)
    pm1.segment(0.5 * path_thck,direction='-x',final_width=path_thck)

    # we calculate the length of the last vertical segment
    min_y_coord = pm1.get_bounding_box()[0][1]                                                                        # y-coordinate of the path's bottom
    req_min_y = 0.5 * (a_test.polygons[10].get_bounding_box()[0][1] + a_test.polygons[10].get_bounding_box()[1][1])   # center of the Si-pillar - a ref.point

    # calculate length of the last vertical segment

    vert_last = np.abs(req_min_y - min_y_coord)                                                                       # the length is the difference between ref.point and path's bottom
    pm1.segment(vert_last, direction='-y',final_width=path_thck)

    # we cut the finger-type path from the polygon

    existing_polygon = a_test.polygons[6]
    a_test.remove_polygons(lambda pts, layer, datatype: layer == 45)
    existing_polygon = gdspy.boolean(existing_polygon, pm1, 'not', **layer_cur)
    a_test.add(existing_polygon)

    gdsii.write_gds(outfile)


    # this function deals only with areas of layers and its features so we use it to update 'layers_descr'

    update_layers_descr('10','area', a_test.polygons[0].area())
    update_layers_descr('11', 'area', a_test.polygons[6].area())
    update_layers_descr('12', 'area', a_test.polygons[7].area())
    update_layers_descr('20', 'area', a_test.polygons[1].area() + a_test.polygons[2].area())
    update_layers_descr('21', 'area', a_test.polygons[8].area())
    update_layers_descr('22', 'area', a_test.polygons[9].area())
    update_layers_descr('30', 'area', a_test.polygons[3].area() + a_test.polygons[4].area())
    update_layers_descr('45', 'area', a_test.polygons[-1].area()) # this layer was added as the last one --> index [-1]
    update_layers_descr('80', 'area', a_test.polygons[5].area())
    update_layers_descr('80 top diel', 'area', a_test.polygons[5].area())
    update_layers_descr('80 bottom diel', 'area', a_test.polygons[5].area())
    update_layers_descr('air', 'area', a_test.polygons[5].area())


    return None
