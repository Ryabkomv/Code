#!/bin/bash

if test -h ~/.local/bin/comsol
then

unlink ~/.local/bin/comsol

fi

mkdir -p ~/.local/bin
ln -s /apps/Comsol/comsol61/bin/comsol ~/.local/bin/comsol
source ~/LWIR/lwir_env/bin/activate
export LD_LIBRARY_PATH=${LD_LIBRARY_PATH}:/apps/Comsol/comsol61/lib/glnxa64:/apps/Comsol/comsol61/ext/graphicsmagick/glnxa64:/apps/Comsol/comsol61/ext/cadimport/glnxa64
python optimization_comsol.py
