import os

# constants required to calculate blck body emissivity
c1 = 3.742e8
c2 = 1.439e4
c3 = 1.884e27
k = 1.38e-23 # Boltzmann constant

# functions for updating

def update_param_draw(key, value):
    global param_draw
    param_draw[key] = value

def update_layers_descr(layer, parameter, value):
    global layers_descr
    layers_descr[layer][parameter] = value

param_dict = {'D_lens': 2e-3,  # input apeture size - metalens diameter
                  'focal_length': 2e-3,  # focal distance
                  'K': 4e-30,
                  'K_val':1e-11,
                  'v': 4e-16,
                  'TCR': 0.025,  # temperature coeffcienct of resistance
                  'w': 30,  # IR modulation frequency
                  'freq_req': 30,  # frequency for 1/f calculation
                  'fi': 10,  # imaging frame rate
                  'fs': 1.66e-2,  # shutter frequency - uniformity correction frequency
                  'T1': 300,  # detector temperature
                  'xl': 32,  # amount of lines
                  'xc': 32,  # amount of columns
                  'C':1.0e-10,                           # thermal capacitance of a single pixel / COMSOL model
                  'tau_therm': 1.5e-3,  # thermal constant / COMSOL model
                  'Rbol':1e5,                            # pixel resistivity
                  'Rroic':1e5,                           # input impedance of the ROIC
                  'pixel_size': 12e-6,  # pixel side
                  'beta': 0.9,  # pixel fill-factor
                  'gamma':1.25,  # coefficient for 1/f noise estimation
                  'phi': 0.4,  # optics transmission
                  'eps': 0.95,  # infrared absroption rate of the bolometer membrane
                  'lambda_start': 8,
                  'lambda_r': 12,
                  'Vq': 1e-6,  # Input referred ADC quantization interval
                  'Vamp': 0.8e-6,  # Input referred noise voltage of the ROIC
                  'Iroic': 8e-11,
                  'Vbias': 1.5,  # SAIT DR

                  'tiN': {'cp': 600, 'rho': 5440, 't': 3e-8, 'G': 29},
                  'aSi': {'cp': 678, 'rho': 2320, 't': 1e-7, 'G': 3},
                  'SiO2': {'cp': 730, 'rho': 2200, 't': 1e-7, 'G': 1.4,
                           't_30': 1e-6, 't_diel': 0.15e-6, 'post_s': 1.8e-12, 'layer_s': 121e-12, 'layer_fill': 0.9},
                'gap_area': None,
                # ROIC scheme and calculation parameters
                # Noise analysis range [Hz]
               'FREQ_FROM': 100,
               'FREQ_TO': 100000,

                # Noise integration range [Hz]
               'INTEG_FROM': 20000,
               'INTEG_TO': 50000,

                # Bandwidth for integration [Hz]
               'BANDWIDTH': 1000,
               # Temperature [°C]
               'TEMP': 20,

              # Circuit file without extension where:
              # * Vin is AC small-signal voltage source
              # * out is the output node name
              'CIRCUIT_NAME': 'data/pixel+amp',

              # Actual LTSpice executables file names
              'SPICE_EXE_WIN': "c:\Program Files\ADI\LTspice\LTspice.exe",
              'SPICE_EXE_LINUX': "/.wine/drive_c/Program Files/LTC/LTspiceXVII/XVIIx86.exe",
              'SPICE_EXE_DARWIN': "/Applications/LTspice.app/Contents/MacOS/LTspice" # not checked on MAC OS X
              }

params_for_opt = {'D_lens': 2e-3,  # input apeture size - metalens diameter
                  'focal_length': 2e-3,  # focal distance
                  'K': 4e-30,    # coefficient for 1/f calculation option 1
                  'K_val':1e-11, # coefficient for 1/f calculation option 2
                  'v': 4e-16,
                  'TCR': 0.025,  # temperature coeffcienct of resistance
                  'w': 30,  # IR modulation frequency
                  'freq_req': 30,  # frequency for 1/f calculation
                  'fi': 10,  # imaging frame rate
                  'fs': 1.66e-2,  # shutter frequency - uniformity correction frequency
                  'T1': 300,  # detector temperature
                  'xl': 32,  # amount of lines
                  'xc': 32,  # amount of columns
                  'tau_therm': 1.5e-3,  # thermal constant / COMSOL model
                  'C':1e-10,
                  'Rbol':1e5,
                  'pixel_size': 12e-6,  # pixel side
                  'beta': 0.9,  # pixel fill-factor
                  'phi': 0.4,  # optics transmission
                  'eps': 0.95,  # infrared absroption rate of the bolometer membrane
                  'lambda_start': 8,
                  'lambda_r': 12,
                  'Vq': 1e-6,  # Input referred ADC quantization interval
                  'Vamp': 0.8e-6,  # Input referred noise voltage of the ROIC
                  'Iroic': 8e-11,
                  'Vbias': 1.5,  # SAIT DR

                  'tiN': {'cp': 600, 'rho': 5440, 't': 3e-8, 'G': 29},
                  'aSi': {'cp': 678, 'rho': 2320, 't': 1e-7, 'G': 3},
                  'SiO2': {'cp': 730, 'rho': 2200, 't': 1e-7, 'G': 1.4,
                           't_30': 1e-6, 't_diel': 0.15e-6, 'post_s': 1.8e-12, 'layer_s': 121e-12, 'layer_fill': 0.9}}

# PARAMETERS OF IMOPRTED LAYERS FOR COMSOL PIXEL MODEL

imp_layers_dict = {'imp2':{'elevation':['z_10','z_11','z_12','0','z_21','z_22','0','z_45','z_diel_b'],
                           'height':['t_Al','t_Al','t_Al','0','t_21','t_22','0','t_45','t_diel_bottom'],
                           'import':['on','on','on','off','off','off','off','off','off'],
                           'name':'import_Al'},
                   'imp3':{'elevation':['0','0','0','0','z_21','z_22','0','z_45','0'],
                           'height':['0','0','0','0','t_21','t_22','0','t_45','0'],
                           'import':['off','off','off','off','on','on','off','on','off'],
                           'name':'import_TiN'},
                   'imp4':{'elevation':['0','0','0','0','0','0','z_30','0','z_diel_b'],
                           'height':['0','0','0','0','0','0','t_30','0','t_diel_bottom'],
                           'import':['off','off','off','off','off','off','on','off','on'],
                           'name':'import_bottom_diel'},
                   'imp5':{'elevation':['0','0','0','0','0','0','0','0','z_diel_b + t_diel_bottom'],
                           'height':['0','0','0','0','0','0','0','0','t_aSi'],
                           'import':['off','off','off','off','off','off','off','off','on'],
                           'name':'import_aSi'},
                   'imp6':{'elevation':['0','0','0','0','0','0','0','0','z_diel_b + t_diel_bottom + t_aSi'],
                           'height':['0','0','0','0','0','0','0','0','t_diel_top'],
                           'import':['off','off','off','off','off','off','off','off','on'],
                           'name':'import_aSi'}}

## TODO: the same definition is in optimizer_grid_simple.py. 
## How to make it only once in all the scripts??
## Move all this to __init__?
home_path = os.path.expanduser("~") 

pixel_model = {'model_file': home_path + '/LWIR/Optimization_Model/data_comsol/HEAT_PLUS_RESISTIVITY.mph',
               'struct_file': home_path + '/LWIR/Optimization_Model/data_comsol/pixels_edited_x.gds',
               'cell': 'FINGER_05' }

# GDS automatic routing parameters

param_draw = {'path_thck': 0.1,
              'radius':0.5,        # holes radii - perforation feature 
              'circ_gap':0.5,      # gap between adjacent holes
              'start_x': 4,
              'start_y': 4.6,
              'coeff_dist': 2.0,  # value corresponds to vertical gap in path thickness units - min 2
              'max_vert': 8.9,  # distance between y max and min positions on pixel
              'vals': ('-x', '+x'),
              'mult': (-1, 1),
              'left_x_bound': -5.5,  # min x bound on the chip
              'right_x_bound': 5.5,  # max x bound on the chip
              'pix_scale': 1.0,     # pixel area scale factor
              'infile': home_path + '/LWIR/Optimization_Model/data_comsol/pixels_update_united_layer_45_opt.gds',
              'outfile': home_path + '/LWIR/Optimization_Model/data_comsol/pixels_edited_x.gds',
              'cell': 'finger_05',
              'layer': 45,
              'datatype': 0}  # so total length is decreased / increased to stay within bounds

# thickness in [um], area in [um**2] units
layers_descr = {'10':{'material':'Al', 'area':102.688, 'thickness':0.1},
               '11':{'material':'Al', 'area':14.4, 'thickness':0.1},
               '12':{'material':'Al', 'area':14.4, 'thickness':0.1},
               '20':{'material':'TiN', 'area':1.566, 'thickness':0.1e-4},
               '21':{'material':'TiN', 'area':0.783, 'thickness':2.25},
               '22':{'material':'TiN', 'area':0.783, 'thickness':2.55},
               '30':{'material':'SiO2', 'area':1.924, 'thickness':2.25},
               '45':{'material':'TiN', 'area':113.7, 'thickness':0.04},
               '80':{'material':'aSi', 'area':113.7, 'thickness':0.2},
               '80 top diel':{'material':'SiO2', 'area':113.7, 'thickness':0.15},
               '80 bottom diel':{'material':'SiO2', 'area':113.7, 'thickness':0.15},
               'air':{'material':'air', 'area':113.7, 'thickness':2}}


