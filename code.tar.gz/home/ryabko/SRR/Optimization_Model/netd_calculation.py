
import logging
import time
import numpy as np
import mod_par
from mod_par import param_dict, params_for_opt

def get_full_param_dict(param_dict):
    # auxiliary variables
    Vadc = param_dict['main']['Vq'] / (12 ** 0.5)
    Ibias = param_dict['main']['Vbias'] / param_dict['main']['Rbol']
    Reff = param_dict['main']['Rbol'] * param_dict['main']['Rroic'] / (param_dict['main']['Rbol'] + param_dict['main']['Rroic'])
    dP_dT = get_radiance_contrast(param_dict['main']['lambda_start'], param_dict['main']['lambda_r'], param_dict['main']['T1'])
    A = param_dict['main']['pixel_size'] ** 2  # pixel area
    tau_therm = param_dict['main']['C']/param_dict['G']                                                                # thermal time constant of a bolometer pixel
    fr = param_dict['main']['xl'] * param_dict['main']['fi']                                                                   # read-out integration frequency
    fbol = 1 / (4 * tau_therm)                                                                                 # bolometer thermal integration frequency
    f_eff = np.min([fr, fbol])

    F = param_dict['main']['focal_length'] / param_dict['main']['D_lens']  # F-number
    R = param_dict['main']['TCR'] * param_dict['main']['beta'] * param_dict['main']['eps'] * Reff * Ibias / (param_dict['main']['G'] * (1 + param_dict['main']['w'] ** 2 * tau_therm ** 2) ** 0.5)  # bolometer responsivity

    # update dictionary with variables
    param_dict['main'].update({'Vadc':Vadc, 'Ibias':Ibias, 'Reff':Reff, 'dP_dT':dP_dT, 'A':A, 'tau_therm':tau_therm, 'fr':fr, 'fbol':fbol, 'f_eff':f_eff, 'F':F, 'R':R})

# Functions describing black-body radiation, output is used for NETD calculation

def get_bb_spc_radiance(wvl, T):
    return mod_par.c1 / ((wvl ** 5) * np.exp(mod_par.c2 / (wvl * T)) - 1)

def get_bb_photon_flux(wvl, T):
    return mod_par.c3 / ((wvl ** 4) * np.exp(mod_par.c2 / (wvl * T)) - 1)

def get_temp_deriv(wvl, T):
    numerator = mod_par.c1 * mod_par.c2 * np.exp(mod_par.c2 / (wvl * T))
    denominator = (wvl ** 6) * (T ** 2) * (np.exp(mod_par.c2 / (wvl * T)) - 1) ** 2
    return numerator / denominator

def get_flux_deriv(wvl, T):
    return mod_par.c3 * mod_par.c2 * np.exp(mod_par.c2 / (wvl * T)) \
        / ((wvl ** 5) * (T ** 2) * np.exp(mod_par.c2 / (wvl * T)) - 1) ** 2
def get_radiance_contrast(wvl_start, wvl_stop, T, n_samples=1000):
    lambda_distr = np.linspace(wvl_start, wvl_stop, n_samples)
    delta_wvl = lambda_distr[1] - lambda_distr[0]
    P_distr = [get_temp_deriv(wvl, T) for wvl in lambda_distr]
    return delta_wvl * np.sum(P_distr)  # radiance contrast in W/(m**2 * K)



# Common multiplier for NETD expression via separate NETD-related components (thermal, 1/f etc.)

def get_comm_mult(f_number, phi, dP_dT, G, beta, A, eps):
    return ((4 * f_number ** 2) / (phi * dP_dT)) * (G / (beta * A * eps)) # common multuplier calculated for all NETD components equally

# 1/f noise voltage and 1/f-associated NETD
def get_1f_noise(K_val, Vbias, Rbol, gamma, freq_req):
    return (K_val * Vbias ** 2 / (freq_req ** gamma)) ** 0.5

def get_1f_netd(comm_mult, K, v, xl, fi, fs, w, C, G, TCR):
    return comm_mult * ((K/v) * (np.log(xl * fi /fs)) * (1 + w**2 * (C/G)**2))**0.5 / TCR

# Johnson noise voltage and Johnson noise associated NETD
def get_johnson_noise(k, T1, Rbol, fr, Rroic):
    return 2 * (k * T1 * Rbol * fr) ** 0.5 * (Rroic / (Rroic + Rbol))
def get_johnson_netd(comm_mult, k, T1, Rbol, xl, fi, w, C, G, TCR, Vbias):
    return comm_mult * 2 * k**0.5 * ((T1 * Rbol * xl * fi * (1 + w**2 * (C/G)**2))**0.5)/(TCR * Vbias)

# Thermal noise voltage and thermal noise associated NETD

def get_bolometer_responsivity(TCR, beta, eps, Reff, Ibias, G, w, tau_therm):
    return (TCR * beta * eps * Reff * Ibias) / (G * (1 + (w * tau_therm) ** 2) ** 0.5)
def get_thermal_noise(TCR, beta, Reff, Ibias, G, w, tau_therm, f_eff, T1, eps, k, R):
    return (2 * k ** 0.5 * R * T1 * (G * f_eff) ** 0.5) / (beta * eps)
def get_thermal_netd(comm_mult, k, T1, C):
    return comm_mult * k**0.5 * T1 / (C**0.5)

# ROIC noise voltage and ROIC-associated NETD

def get_roic_noise(Rbol, Rroic, Vamp, Vadc, Iroic):
    Reff = Rbol * Rroic / (Rbol + Rroic)
    return (Vamp ** 2 + Vadc ** 2 + Reff ** 2 * Iroic ** 2) ** 0.5
def get_vroic(Rroic, Rbol, Iroic, Vamp, Vq):
    Veff = ((Rroic * Rbol) / (Rroic + Rbol)) * Iroic
    return (Vamp ** 2 + (Vq ** 2 / 12) + Veff**2) ** 0.5
def get_roic_netd(comm_mult, Rroic, Rbol, w, C, G, TCR, Vbias, Vroic):
    Coeff = comm_mult * (Rroic + Rbol) * (1 + w**2 * (C/G)**2)**0.5 / (TCR * Vbias * Rroic)
    return Coeff * Vroic

# NETD calculation via noise voltages of separate components
def th_calculate_netd(name, param_dict):
    logging.info("Thread %s: starting", name)
    # time.sleep(2)
    # aux params calculation
    fr = param_dict['xl'] * param_dict['fi']
    Reff = param_dict['Rbol'] * param_dict['Rroic'] / (param_dict['Rbol'] + param_dict['Rroic'])
    Ibias = param_dict['Vbias'] / param_dict['Rbol']
    G = param_dict['C'] / param_dict['tau_therm']
    fbol = 1 / (4 * param_dict['tau_therm'])
    f_eff = np.min([fr, fbol])
    Vadc = param_dict['Vq'] / 12
    R = get_bolometer_responsivity(param_dict['TCR'], param_dict['beta'], param_dict['eps'], Reff, Ibias, G,
                                   param_dict['w'], param_dict['tau_therm'])
    F = param_dict['focal_length'] / param_dict['D_lens']  # F-number
    A = param_dict['pixel_size'] ** 2  # pixel area
    dP_dT = get_radiance_contrast(param_dict['lambda_start'], param_dict['lambda_r'], param_dict['T1'])

    # NETD calculation
    v_1f = get_1f_noise(param_dict['K_val'], param_dict['Vbias'], param_dict['Rbol'], param_dict['gamma'],
                        param_dict['freq_req'])
    v_johnson = get_johnson_noise(mod_par.k, param_dict['T1'], param_dict['Rbol'], fr,
                                  param_dict['Rroic'])
    v_thermal = get_thermal_noise(param_dict['TCR'], param_dict['beta'], Reff, Ibias, G,
                                  param_dict['w'], param_dict['tau_therm'], f_eff,
                                  param_dict['T1'], param_dict['eps'], mod_par.k, R)
    v_roic = get_roic_noise(param_dict['Rbol'], param_dict['Rroic'], param_dict['Vamp'], Vadc,
                            param_dict['Iroic'])
    Vn = (v_1f ** 2 + v_johnson ** 2 + v_thermal ** 2 + v_roic ** 2) ** 0.5
    NETD = (4 * F * Vn) / (R * A * param_dict['phi'] * dP_dT)
    # print(f'Bolometer responsivity - {1e-6*R:.3f} MV/W')
    # print(f'V_1f - {1e6 * v_1f:.3f} uV')
    # print(f'V johnson - {1e6 * v_johnson:.3f} uV')
    # print(f'V thermal - {1e6 * v_thermal:.3f} uV')
    # print(f'V ROIC - {1e6 * v_roic:.3f} uV')
    # print(f'V full - {1e6 * Vn:.3f} uV')
    # print(f'NETD full is {1e3 * NETD:.3f} mK')
    logging.info("Thread %s: finishing", name)
    return NETD

# Full NETD calculation for optimization task - C and R are arguments of the function
def th_calculate_netd_optimization():
    D_lens, focal_length, K, K_val, v, TCR, w, freq_req, fi, \
    fs, T1, xl, xc, tau_therm, C, Rbol, pixel_size, pix_scale, beta, \
    phi, eps, lambda_start, lambda_r, Vq, Vamp, \
    Iroic, Vbias, TiN, aSi, SiO2 = params_for_opt.values()

    # aux param calculation
    dP_dT = get_radiance_contrast(lambda_start, lambda_r, T1)
    F = focal_length / D_lens  # F-number
    G = C / tau_therm  # total thermal conductance
    Rroic = Rbol
    A = (pixel_size * pix_scale) ** 2  # pixel area

    # NETD calculation
    comm_mult = get_comm_mult(F, phi, dP_dT, G, beta, A, eps)
    NETD_1_f = get_1f_netd(comm_mult, K, v, xl, fi, fs, w, C, G, TCR)
    NETD_johnson = get_johnson_netd(comm_mult, mod_par.k, T1, Rbol, xl, fi, w, C, G, TCR, Vbias)
    NETD_thermal = get_thermal_netd(comm_mult, mod_par.k, T1, C)
    Vroic = get_vroic(Rroic, Rbol, Iroic, Vamp, Vq)
    NETD_roic = get_roic_netd(comm_mult, Rroic, Rbol, w, C, G, TCR, Vbias, Vroic)
#     NETD_full = (NETD_1_f ** 2 + NETD_johnson ** 2 + NETD_thermal ** 2 + NETD_roic ** 2) ** 0.5
    NETD_full = (NETD_1_f ** 2 + NETD_johnson ** 2 + NETD_thermal ** 2) ** 0.5

    # print(f'NETD 1/f - {1e3 * NETD_1_f:.3f} mK')
    # print(f'NETD Johnson - {1e3 * NETD_johnson:.3f} mK')
    # print(f'NETD thermal - {1e3 * NETD_thermal:.3f} mK')
    # print(f'NETD ROIC - {1e3 * NETD_roic:.3f} mK')
    # print(f'NETD Full - {1e3 * NETD_full:.3f} mK')
    return NETD_full










