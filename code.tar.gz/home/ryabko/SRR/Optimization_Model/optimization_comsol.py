
import nlopt
import mph
from draw_gds import draw_route
from mod_par import imp_layers_dict, param_dict, pixel_model, param_draw, layers_descr, params_for_opt
import netd_calculation
from optimizer_grid_simple import get_absorption
import numpy as np
from scipy.optimize import curve_fit
import math
import logging
import os
import subprocess
import sys

## Try to start comsol/load file only once:
global_mph_model = None
client = None

def start_comsol(model_file):
    global client
    if client == None:
        if (sys.platform == 'linux'): ## Running on supercomp, checking licenses available
            ## total licenses
            total_lic = subprocess.check_output('/LSF/flexlm/lmutil lmstat -c 1718\@saitlic1 -f COMSOL | grep Users | awk \'{ print $6 }\'', shell = True, universal_newlines=True)
            ## used licenses
            used_lic = subprocess.check_output('/LSF/flexlm/lmutil lmstat -c 1718\@saitlic1 -f COMSOL | grep Users | awk \'{ print $11 }\'', shell = True, universal_newlines=True)
            if int(total_lic) <= int(used_lic):
                print('No comsol license available. Try later.')
                return False
            #Looks like we have comsol license. Check ECAD Import module
            total_lic = subprocess.check_output('/LSF/flexlm/lmutil lmstat -c 1718\@saitlic1 -f ECADIMPORT | grep Users | awk \'{ print $6 }\'', shell = True, universal_newlines=True)
            used_lic = subprocess.check_output('/LSF/flexlm/lmutil lmstat -c 1718\@saitlic1 -f ECADIMPORT | grep Users | awk \'{ print $11 }\'', shell = True, universal_newlines=True)
            if int(total_lic) <= int(used_lic):
                print('No ECAD import module license available (lmstat). Try later.')        
                return False
        # For some reason, sometimes even if ECAD license is shown available by lmstat, 
        # after trying to load mph model into comsol we get ECAD import license error exception
        # API has 4 functions, in this case two of them (hasProductFor..) return True, and two of them (checkoutLicense...) - False
        client = mph.start()
        prod_for_file = client.java.hasProductForFile(model_file)
        prod_for_file_srv = client.java.hasProductForFileOnServer(model_file)
        chk_lic_file = client.java.checkoutLicenseForFile(model_file)
        chk_lic_file_srv = client.java.checkoutLicenseForFileOnServer(model_file)
        print('Product for File:' + str(prod_for_file))
        print('Product for File on Server:' + str(prod_for_file_srv))
        print('License for File:' + str(chk_lic_file))
        print('License for File on Server:' + str(chk_lic_file_srv))
        if prod_for_file and prod_for_file_srv and chk_lic_file and chk_lic_file_srv:
            print('Comsol started...')
            return True
        else:
            print('No ECAD import module license available (API check). Try later.')  
            return False


def get_model(model_file):
    global global_mph_model
    global client
    if client == None:
        return None    ## use start_comsol() first! 
    if global_mph_model == None:
        pymodel = client.load(model_file)        
        global_mph_model = pymodel.java
    return global_mph_model

def update_mode(pixel_model, layers_descr):
    mph_model = get_model(pixel_model['model_file'])
    for _i in ('imp2', 'imp3', 'imp4', 'imp5', 'imp6'):
        mph_model.component('comp1').geom('geom1').feature(_i).set('filename', pixel_model['struct_file'])
        mph_model.component('comp1').geom('geom1').feature(_i).set('cell', pixel_model['cell'])
        mph_model.component('comp1').geom('geom1').feature(_i).set("grouping", 'layer')
        mph_model.component('comp1').geom('geom1').feature(_i).set("manualelevation", 'on')
        mph_model.component('comp1').geom('geom1').feature(_i).set("elevation", imp_layers_dict[_i]['elevation'])
        mph_model.component('comp1').geom('geom1').feature(_i).set("importlayer", imp_layers_dict[_i]['import'])
        mph_model.component('comp1').geom('geom1').feature(_i).set("height", imp_layers_dict[_i]['height'])

    if layers_descr:
        # update thickness of layers
        for i,j in zip(('t_aSi','t_45','t_diel','t_air'), (layers_descr['80']['thickness'], layers_descr['45']['thickness'], layers_descr['80 top diel']['thickness'], layers_descr['air']['thickness'])):
            mph_model.param().set(i, str(j) + ' [um]')
        mph_model.save()
    
    mph_model.param().set('pix_scale', param_draw['pix_scale'])  # we set pixel size parameter 
    mph_model.component('comp1').geom('geom1').run()
    mph_model.save()
    return mph_model

def get_resistivity(mph_model):
    mph_model.study('std1').run()
    voltage = mph_model.result().numerical("gev1").computeResult()[0][0][2]
    current = mph_model.result().numerical("gev1").computeResult()[0][0][1]
    return (voltage/current)

def get_thermal_properties(mph_model):
    mph_model.study('std2').run()
    data = np.array(mph_model.result().numerical("max1").computeResult()[0])
    time = data[:,0]
    temp = data[:,1]-300
    N = len(time)
    def f(x,tau, dT):
        return dT * (1 - np.exp(-x/tau))
    idx = min(5,N-1)
    p_init = [time[idx], temp[-1]]
    popt, pcov = curve_fit(f, time, temp, p0 = p_init)
    tau_065 = popt[0]
    dT = popt[1]
    P = np.abs(mph_model.result().numerical("gev2").computeResult()[0][0][0])
    G = P/dT
    C = tau_065*G

    check_fun = [f(i, tau_065, dT) for i in time]
    threshold = 0.95 * check_fun[-1]
    for i, j in enumerate(check_fun):
        if j > threshold:
            tau_095 = time[i]
            break
    return tau_065, tau_095, G, C, temp, check_fun
    

# function for getting time response of a bolometer structure
def get_response_time(mph_model):
    # calculation of  thermal constant
    mph_model.study('std2').run()
    res_table = mph_model.result().table("tbl4").getTableData(True)
    time = [float(str(res_table[_i][0])) for _i in range(len(res_table))]
    temp = [float(str(res_table[_i][1])) - 300 for _i in range(len(res_table))]
    threshold = 0.95 * temp[-1]
    for i, j in enumerate(temp):
        if j > threshold:
            tau = time[i]
            break
    return tau, temp

def get_heat_capacity():
    """Calculate pixel's heat capacity
    gap_area = area of a slit/finger gap in the TiN layer which is calculated after each gds rerouting iteration
    """
    # fill_factor = param_init['beta']
    tiN = param_dict['tiN']
    aSi = param_dict['aSi']
    SiO2 = param_dict['SiO2']
    gap_area = param_dict['gap_area']

    # heat capacity of a post structure

    C_post_sio2 = SiO2['cp'] * SiO2['rho'] * layers_descr['30']['thickness'] * layers_descr['30']['area']
    C_post_tin1 = tiN['cp'] * tiN['rho'] * layers_descr['21']['thickness'] * layers_descr['21']['area']
    C_post_tin2 = tiN['cp'] * tiN['rho'] * layers_descr['22']['thickness'] * layers_descr['22']['area']
    C_post = 2 * C_post_sio2 + C_post_tin1 + C_post_tin2

    # heat capacity of a sensitive upper part

    C_layer_tin = tiN['cp'] * tiN['rho'] * layers_descr['45']['thickness'] * layers_descr['45']['area']
    C_asi = aSi['cp'] * aSi['rho'] * (layers_descr['80']['thickness'] - layers_descr['45']['thickness']) *  layers_descr['80']['area'] + aSi['cp'] * aSi['rho'] * layers_descr['45']['thickness'] * layers_descr['80']['area']
    C_top_diel = SiO2['cp'] * SiO2['rho'] * layers_descr['80 top diel']['thickness'] * layers_descr['80 top diel']['area']
    C_bottom_diel = SiO2['cp'] * SiO2['rho'] * layers_descr['80 bottom diel']['thickness'] * layers_descr['80 bottom diel']['area']
    C_upper = C_layer_tin + C_asi + C_top_diel + C_bottom_diel

    C_full = C_post + C_upper
    return 1e-18 * C_full

# Function for optimization

counter = 0
cur_NETD = []
cur_C = []
resist_list = []
thermo_curve = []
optimized_dict = {'correct':[],
                  'netd':[],
                  'resistivity':[],
                  'heat_capacity':[],
                  'heat_cap_manual':[],
                  'path_thck':[],
                  'coeff_dist':[],
                  'tau_065':[],
                  'tau_095':[],
                  'scale_factor':[],
                  't_aSi thickness':[],
                  't_TiN thickness':[],
                  'bottom diel thickness':[],
                  'top diel thickness':[],
                  'absorption coeff':[],
                  'air gap':[]}
film_ff = 0.87

def get_full_NETD(x, grad):
    global counter
    counter+=1
    # check up for some wrong values
    for _i in range(len(x)):
        if math.isnan(x[_i]):
            x = init_values_opt
    # perform rounding
    x = [round(i, j) for i,j in zip(x, precision_list)]

    # param_draw['path_thck'] = x[0]   # route thickness
    # param_draw['coeff_dist'] = x[1]  # vertical gap between slit turns

    if x[1] <= x[3]:
        x[1] = x[3]
    # x[4] = x[5]

    print(f'current params: {x}')
    param_draw['pix_scale'] = x[0]  # pixel size scale factor
    layers_descr['80']['thickness'] = x[1]                # thickness of amorphous silicon layer
    layers_descr['air']['thickness'] = x[2]                # air gap
    layers_descr['45']['thickness'] = x[3]                 # thickness of TiN layer
    layers_descr['80 top diel']['thickness'] = x[4]       # thickness of passivation layer
    layers_descr['80 bottom diel']['thickness'] = x[5]     # thickness of support layer

    # optimized_dict['path_thck'].append(x[0])
    # optimized_dict['coeff_dist'].append(x[1])
    optimized_dict['scale_factor'].append(x[0])
    optimized_dict['t_aSi thickness'].append(x[1])
    optimized_dict['air gap'].append(x[2])
    optimized_dict['t_TiN thickness'].append(x[3])
    optimized_dict['bottom diel thickness'].append(x[4])
    optimized_dict['top diel thickness'].append(x[5])
    
   # draw layers of the pixel
    draw_route()
    # we calculate absorption of the structure
    eps = get_absorption()
    params_for_opt['eps'] = eps
    optimized_dict['absorption coeff'].append(eps)
    print('absorbance calculated')
    # update model
    new_model = update_model(pixel_model, layers_descr, param_draw)
    print('model updated')
    # get alternative heat capacity
    C_manual = get_heat_capacity()
    try:
         # calculate all thermal properties via Comsol
        tau_065, tau_095, G, C, temp, check_fun = get_thermal_properties(new_model) ## Units: [s], [W/K], [J/K]
        print('thermal properties extracted')
        # extract pixel resistivity
        params_for_opt['Rbol'] = get_resistivity(new_model)
        print('resistivity extracted')
        optimized_dict['correct'].append(1)
        optimized_dict['tau_065'], optimized_dict['tau_095'] = tau_065, tau_095
        param_dict['tau_therm'], params_for_opt['tau_therm'] = tau_095, tau_095

        params_for_opt['C'] = C_manual
        params_for_opt['pix_scale'] = param_draw['pix_scale']
        print(f'Step:{counter} Heat capacity - '
              f'{params_for_opt["C"]} / resistivity - '
              f'{1e-6 * params_for_opt["Rbol"]} MOhm / tau - '
              f'{1E3*params_for_opt["tau_therm"]} ms, eps - '
              f'{params_for_opt["eps"]}')
    except Exception:
        optimized_dict['correct'].append(0)
        logger.error(e)
        print('skip_____')

    # calculate NETD with parameters -
    full_NETD = netd_calculation.th_calculate_netd_optimization()
    # save values to dict
    optimized_dict['netd'].append(full_NETD)
    optimized_dict['resistivity'].append(params_for_opt["Rbol"])
    optimized_dict['heat_capacity'].append(params_for_opt["C"])
    optimized_dict['heat_cap_manual'].append(C_manual)

    # save values to lists
    cur_C.append(params_for_opt["C"])
    cur_NETD.append(full_NETD)
    resist_list.append(params_for_opt["Rbol"])
    thermo_curve.append(params_for_opt["tau_therm"])
    return full_NETD

# OPTIMIZATION PROCEDURE
def perform_optimization(init_min, init_max, init_vals, fun):
    maxeval = 5
    opt = nlopt.opt(nlopt.LN_COBYLA, 6)
    opt.set_lower_bounds(init_min)
    opt.set_upper_bounds(init_max)
    opt.set_min_objective(fun)
    opt.set_maxeval(maxeval)
    x = opt.optimize(init_vals)
    minf = opt.last_optimum_value()
    print(f'minimum value = {1e3 * minf:.3f} mK')
    print("result code = ", opt.last_optimize_result())

# free parameters:
# 1 - pixel size, 
# 2 - aSi thickness,
# 3 - air gap, 
# 4 - tiN thickness,
# 5 - support SiO2 layer thickness,
# 6 - top SiO2 layer thickness
min_values_opt = [1.0, 0.05, 1.0, 0.01, 0.1, 0.1]
max_values_opt = [1.0, 0.3, 2.0, 0.07, 0.3, 0.3]
init_values_opt = [1.0, 0.2, 1.0, 0.04, 0.15, 0.15]
# init_values_opt = [0.12, 3.0, 3.4, 0.193, 1.88, 0.022, 0.146, 0.145]

precision_list = [1, 2, 2, 2, 2, 2]


if start_comsol(pixel_model['model_file']):
    # Optimization
    perform_optimization(min_values_opt, max_values_opt, init_values_opt,  get_full_NETD)
