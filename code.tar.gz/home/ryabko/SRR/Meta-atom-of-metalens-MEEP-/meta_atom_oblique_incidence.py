# %%

'''
The meta-atom design of LWIR achromatic polarization insensitive metalens consits of 3 cylindrical pillars
with 6 µm height of each other. The radius of each cylinder varies between 0.5 µm and 2.5 µm. 
The script consists of two parts, the first presents simulations for geting fields for further analysis.
The second part demonstrade postprocessing for getting transmittance and phase maps depend on broadband 
source wavelength and angle of oblique incidence. 

In this case the following basic parameters have been chosen:
wavelength range 8 - 12 µm
polar angle range 0 - 26 degrees
azimuth angle - 30 degree
period of meta atom 6 µm
lower cylinder radius 2.5 µm
middle cylinder radius 2.4 µm
upper cylinder radius 0.5 µm
refractive index of material - 3.42
'''


import math
import meep as mp
import numpy as np
import matplotlib.pyplot as plt

# %% Part 1: simulation

resolution = 14                                             # gives the number of pixels per distance unit (pixels/μm)

dpml = 20                                                   # width of perfectly matched layers (μm) 
gp = 6                                                      # period of unit cell (μm)

sx = 82                                                     # cell size on X direction
sy = gp                                                     # cell size on Y direction
sz = gp                                                     # cell size on Z direction

cell_size = mp.Vector3(sx, sy, sz)                          # 3D model of cell
pml_layers = [mp.PML(thickness=dpml, direction=mp.X)]       # Perfectly Matched Layers (X direction)

wvl_min = 8                                                 # min wavelength (μm)
wvl_max = 12                                                # max wavelength (μm) 
fmin = 1/wvl_max                                            # min frequency
fmax = 1/wvl_min                                            # max frequency
fcen = 0.5*(fmin+fmax)                                      # center frequency
df = fmax - fmin                                            # frequency width
nfreq = 50                                                  # number of frequencies

nSi = 3.42                                                  # refractive index of silicon

src_pt = mp.Vector3(-15, 0, 0)                              # location of source monitor
tran_pt = mp.Vector3(15, 0, 0)                              # location of transmittance monitor
refl_pt = mp.Vector3(-12, 0, 0)                             # location of reflection monitor

thetas = np.linspace(0, 26, 27)                             # polar angles for implemetation oblique incidence in [0,360)
phi_deg = 30                                                # azimuth angle in [0,360)
phi = math.radians(phi_deg)                                 # degrees to radians

# empty 2D arrays for data
transmittance = [0 for row in range(len(thetas))]

input_phase_Ez = [0 for row in range(len(thetas))]
# input_phase_Ey = [0 for row in range(len(thetas))]
# input_phase_Ex = [0 for row in range(len(thetas))]
# input_phase_Hz = [0 for row in range(len(thetas))]
# input_phase_Hy = [0 for row in range(len(thetas))]
# input_phase_Hx = [0 for row in range(len(thetas))]

phase_Ez = [0 for row in range(len(thetas))]
# phase_Ey = [0 for row in range(len(thetas))]
# phase_Ex = [0 for row in range(len(thetas))]
# phase_Hz = [0 for row in range(len(thetas))]
# phase_Hy = [0 for row in range(len(thetas))]
# phase_Hx = [0 for row in range(len(thetas))]

all_kx = np.empty(len(thetas))
all_ky = np.empty(len(thetas))
all_kz = np.empty(len(thetas))


S_polarization = True  # else P-polarization
# condition for source to set S- or P-polarization
eig_band=mp.DiffractedPlanewave((0,0,0),tran_pt,1,0) if S_polarization == True else mp.DiffractedPlanewave((0,0,0),tran_pt,0,1)


for t in range(len(thetas)):
    thet = math.radians(thetas[t])
    # defenition k-vector    
    if thet == 0:
        k = mp.Vector3(0, 0, 0)
    else:
        # scaling k-vector by the minimum frequency to get real kx for all frequencies
        k = mp.Vector3(fmin*nSi, 0, 0).rotate(mp.Vector3(z=1), thet).rotate(mp.Vector3(x=1), phi)

    # source geometry and parameters
    sources = [mp.EigenModeSource(src=mp.GaussianSource(fcen, fwidth=df),
                              center=src_pt,
                              size=mp.Vector3(0, sy, sz),
                              direction=mp.AUTOMATIC if thet == 0 else mp.NO_DIRECTION,
                              eig_kpoint=k,
                              eig_band=1 if thet == 0 else eig_band,
                              eig_parity=mp.NO_PARITY,
                              eig_match_freq=True)]

    # simulation
    sim = mp.Simulation(
        resolution=resolution,
        cell_size=cell_size,
        boundary_layers=pml_layers,
        k_point=k,
        default_material=mp.Medium(index=nSi),
        sources=sources,
    )

    # reflected flux
    refl_flux = sim.add_flux(fcen, df, nfreq, mp.FluxRegion(center=refl_pt, size=mp.Vector3(0,sy,sz)))
    
    # transmitted flux
    tran_flux = sim.add_flux(fcen, df, nfreq, mp.FluxRegion(center=tran_pt, size=mp.Vector3(0,sy,sz)))
    
    # DFT monitor
    dft_mon = sim.add_dft_fields([mp.Ez, mp.Ey, mp.Hz, mp.Hy, mp.Ex, mp.Hx],fcen, df, nfreq, center=tran_pt, size=mp.Vector3(0,sy,sz))        
       
    # simulation is running until power decreased to certain value
    sim.run(until_after_sources=mp.stop_when_fields_decayed(50, mp.Ez, tran_pt, 1e-3)) 

    # get input field for normalization
    input_flux = np.array(mp.get_fluxes(refl_flux)) 
    
    # saving data of different field components from DFT monitor  
    input_phase_Ez[t] = [sim.get_dft_array(dft_mon, mp.Ez, nf) for nf in range(nfreq)]
    # input_phase_Ey[t] = [sim.get_dft_array(dft_mon, mp.Ey, nf) for nf in range(nfreq)]
    # input_phase_Ex[t] = [sim.get_dft_array(dft_mon, mp.Ex, nf) for nf in range(nfreq)]
    # input_phase_Hz[t] = [sim.get_dft_array(dft_mon, mp.Hz, nf) for nf in range(nfreq)]
    # input_phase_Hz[t] = [sim.get_dft_array(dft_mon, mp.Hy, nf) for nf in range(nfreq)]
    # input_phase_Hz[t] = [sim.get_dft_array(dft_mon, mp.Hx, nf) for nf in range(nfreq)]    
           
    sim.reset_meep()                # reset all of Meep's parameters for new simulation  

    # defenition geometry and location of meta atom
    geometry = [
        mp.Block(
        material=mp.Medium(index=nSi),
        size=mp.Vector3(32, mp.inf, mp.inf),
        center=mp.Vector3(-25, 0, 0),        
        ),   
        mp.Cylinder(
            material=mp.Medium(index=nSi),
            radius=1.5, height = 6,   
            center=mp.Vector3(-6, 0, 0),
            axis = mp.Vector3(1, 0, 0),),
        mp.Cylinder(
            material=mp.Medium(index=nSi),
            radius=1, height = 6,   
            center=mp.Vector3(0, 0, 0),
            axis = mp.Vector3(1, 0, 0),),
        mp.Cylinder(
            material=mp.Medium(index=nSi),
            radius=0.5, height = 6,   
            center=mp.Vector3(6, 0, 0),
            axis = mp.Vector3(1, 0, 0),),             
    ]

    # simulation
    sim = mp.Simulation(resolution=resolution,
                    cell_size=cell_size,
                    boundary_layers=pml_layers,
                    k_point=k,
                    geometry=geometry,
                    sources=sources,
                    )

    # transmitted flux
    tran_flux = sim.add_flux(fcen, df, nfreq, mp.FluxRegion(center=tran_pt, size=mp.Vector3(0,sy,sz)))
    
    # DFT monitor
    dft_mon = sim.add_dft_fields([mp.Ez, mp.Ey, mp.Hz, mp.Hy, mp.Ex, mp.Hx],fcen, df, nfreq, center=tran_pt, size=mp.Vector3(0,sy,sz))        
    
    sim.run(until_after_sources=mp.stop_when_fields_decayed(50, mp.Ez, tran_pt, 1e-3))   
        
    # saving data of different field components from DFT monitor at various frequencies    
    phase_Ez[t] = [sim.get_dft_array(dft_mon, mp.Ez, nf) for nf in range(nfreq)]
    # phase_Ey[t] = [sim.get_dft_array(dft_mon, mp.Ey, nf) for nf in range(nfreq)]
    # phase_Ex[t] = [sim.get_dft_array(dft_mon, mp.Ex, nf) for nf in range(nfreq)]
    # phase_Hz[t] = [sim.get_dft_array(dft_mon, mp.Hz, nf) for nf in range(nfreq)]
    # phase_Hz[t] = [sim.get_dft_array(dft_mon, mp.Hy, nf) for nf in range(nfreq)]
    # phase_Hz[t] = [sim.get_dft_array(dft_mon, mp.Hx, nf) for nf in range(nfreq)]   
        
    freqs = mp.get_eigenmode_freqs(tran_flux)           # returns a list of the frequencies 

    tran_flux = mp.get_fluxes(tran_flux)                # get flux fields
    T = tran_flux/input_flux                            # normalization flux fields
    transmittance[t] = T                                # saving transmittance
    
    all_kx[t] = k.x                                     # saving kx
    all_ky[t] = k.y                                     # saving ky
    all_kz[t] = k.z                                     # saving kz
    
frequencies = [freqs[nf] for nf in range(nfreq)]        # saving data of frequencies
wavelengths = [1/freqs[nf] for nf in range(nfreq)]      # saving data of wavelengths



# %% Part 2: Postprocessing

nAir = 1                                        # refractive index of air
L_input = 30                                    # distance between source and transmittance monitor

# recalculate k-vectors to angles of incidence
numberwavelengths = len(wavelengths)
angles_air = np.zeros((len(all_ky), len(wavelengths)))
for i in range(len(all_ky)):
    for j in range(len(wavelengths)):
        angles_air[i,j] = np.arcsin(nSi*np.sin(np.arcsin((all_ky[i]/freqs[j])/np.cos(phi)))/nAir)*180/np.pi

# Interpolation of getting actual injection angle from air as a function of frequency, because the source in simulation is located in meta atom substrate
angleGrid = np.zeros((len(thetas), numberwavelengths))
wavelengthGrid = np.zeros((len(thetas), numberwavelengths))
TGrid = np.zeros((len(thetas), numberwavelengths))

i = 0
for theta in thetas:
    angleGrid[i] = angles_air[i]    
    wavelengthGrid[i] = wavelengths
    TGrid[i] = transmittance[i]
    i = i + 1

# excluding NaN values from angleGrid    
for i in range(len(all_ky)):
    for j in range(len(wavelengths)):
        if np.isnan(angleGrid[i,j]) == True:
            angleGrid[i,j] = 80
            
# visualization of transmittance map
plt.figure()
plt.pcolormesh(angleGrid, wavelengthGrid, TGrid)
plt.ylabel("wavelength, um")
plt.xlabel("angle, degrees")
plt.title("Transmittance")
cbar = plt.colorbar()
plt.xlim(0, 70)
plt.show()


# %%
# finding transmittance cross section at the closest angle to desire angle at each frequency
cross_section_transmittance = np.zeros(nfreq)
desired_angle_transmittance = 60                            

for j in range(len(wavelengths)):
    closest_angle_index = np.argmin(np.abs(angleGrid[:, j] - desired_angle_transmittance))
    cross_section_transmittance[j] = TGrid[closest_angle_index, j]

# visualization of transmittance at desired angle
plt.plot(wavelengths, cross_section_transmittance,  color='C0', marker = "o", label = 'meep')
plt.xlabel('wavelength, nm', fontsize = 14)
plt.ylabel('Transmittance', fontsize = 14)
plt.title(f'Transmittance, theta = {desired_angle_transmittance}', fontsize = 14) 
plt.legend(fontsize = 14)
plt.ylim(0, 1)

# %%

# calculation of phase map
phase_0_do = np.zeros((len(all_ky), nfreq))

# finding index of zero diffraction order
input_array = input_phase_Ez[0][0]
geom_array = phase_Ez[0][0]

# remove two last points of fields, because its repeated aa boundary conditions
for point in (0,1,0,1):
    input_array = np.delete(input_array, -1, point) 
    geom_array = np.delete(geom_array, -1, point) 

# normalization field on source
norm_field = geom_array / input_array

# increase number of monitors         
number_monitors = 81
norm_field = np.tile(norm_field, (number_monitors,number_monitors))
        
# Fourier transform              
ft = np.fft.fftshift(np.fft.fft2(norm_field))/((len(norm_field) * len(norm_field)))

m= np.abs(ft)**2
ind = np.unravel_index(np.argmax(m), m.shape)     # indexes of intensive Fourier peak

index_0_do = ind[0]

for kvector in range(len(all_ky)):         
    for nf in range(nfreq):           
           
        input_array = input_phase_Ez[kvector][nf]
        geom_array = phase_Ez[kvector][nf] 
               
        # remove two last points of fields, because its repeated aa boundary conditions      
        input_array = np.delete(input_array, [-2, -1], 0) 
        input_array = np.delete(input_array, [-2, -1], 1)
        geom_array = np.delete(geom_array, [-2, -1], 0)         
        geom_array = np.delete(geom_array, [-2, -1], 1)  
        
        # subtraction of Si cell phase for getting phase of source     
        phase_factor = (np.exp(1j*2*np.pi*nSi*(L_input*np.cos(np.arcsin((all_ky[kvector]/freqs[nf])/np.cos(phi)))*freqs[nf])))             
        input_array_corr = input_array / phase_factor   
        
        # normalization field on source
        norm_field = geom_array / input_array_corr
        
        # increase number of monitors         
        norm_field = np.tile(norm_field, (number_monitors,number_monitors))
        
        # Fourier transform              
        ft = np.fft.fftshift(np.fft.fft2(norm_field))/((len(norm_field) * len(norm_field)))
        m= np.abs(ft)**2
        ind = np.unravel_index(np.argmax(m), m.shape)     # indexes of intensive Fourier peak

        # cross section of Fourier transform
        cross_fft = ft[:, ind[1]]

        phase_0_do[kvector, nf] = np.angle(cross_fft[index_0_do])

# %%
        
phase_unwrap = np.unwrap(phase_0_do)
numberwavelengths = len(wavelengths)

# recalculate k-vectors to angles of incidence
angles_air = np.zeros((len(all_ky), len(wavelengths)))
for i in range(len(all_ky)):
    for j in range(len(wavelengths)):
        angles_air[i,j] = np.arcsin(nSi*np.sin(np.arcsin((all_ky[i]/freqs[j])/np.cos(phi)))/nAir)*180/np.pi

# Interpolation of getting actual injection angle from air as a function of frequency, because the source in simulation is located in meta atom substrate
angleGrid = np.zeros((len(thetas), numberwavelengths))
angleGrid_Air = np.zeros((len(thetas), numberwavelengths))
wavelengthsGrid = np.zeros((len(thetas), numberwavelengths))
PhaseGrid_unwrap = np.zeros((len(thetas), numberwavelengths))
PhaseGrid = np.zeros((len(thetas), numberwavelengths))

i = 0
for theta in thetas:
    angleGrid_Air[i] = angles_air[i]    
    wavelengthsGrid[i] = wavelengths
    PhaseGrid[i] = phase_0_do[i]
    PhaseGrid_unwrap[i] = phase_unwrap[i]
    i = i + 1

# excluding NaN values from angleGrid
for i in range(len(all_ky)):
    for j in range(len(wavelengths)):
        if np.isnan(angleGrid_Air[i,j]) == True:
            angleGrid_Air[i,j] = 80

# visualization of transmittance map 
plt.figure()
plt.subplot(2, 2, 1)
plt.pcolormesh(angleGrid_Air, wavelengthsGrid, PhaseGrid)
plt.ylabel("wavelength (um)")
plt.xlabel("angle (degrees)")
plt.title("Phase")
cbar = plt.colorbar()
plt.xlim(0, 65)

plt.subplot(2, 2, 2)
plt.pcolormesh(angleGrid_Air, wavelengthsGrid, PhaseGrid_unwrap)
plt.ylabel("wavelength (um)")
plt.xlabel("angle (degrees)")
plt.title("Unwrap Phase")
cbar = plt.colorbar()
plt.xlim(0, 65)
plt.show()

# %%
# finding transmittance cross section at the closest angle to desire angle at each frequency
cross_section_phase = []
desired_angle_phase = 60

for j in range(len(wavelengths)):
    closest_angle_index = np.argmin(np.abs(angleGrid[:, j] - desired_angle_phase))
    cross_section_phase.append(PhaseGrid[closest_angle_index, j])

plt.plot(wavelengths, np.unwrap(cross_section_phase),  color='C1', marker = "o", label = 'meep')
plt.xlabel('wavelength, nm', fontsize = 14)
plt.ylabel('phase, rad', fontsize = 14)
plt.title(f'Phase, theta = {desired_angle_phase}', fontsize = 14)
plt.legend(fontsize = 14)
