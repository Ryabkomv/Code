
# %%

import meep as mp
import numpy as np
import matplotlib.pyplot as plt

'''
The meta-atom design of LWIR achromatic polarization insensitive metalens has been represented according
to the Manuscript https://doi.org/10.1063/5.0120717. The meta-atom has rectangular substrate with square 
side 8 µm and semi-infinite height. The meta atom has two rectangular pillars with 2 µm gap between them 
and 45° or 45° rotation angles. The geometric parameters of the first pillar length and width are 2.4 and 
1.6 µm, respectively. The geometric parameters of the second pillar length and width are 2 and 
1.4 µm, respectively.
'''


# %% Geometry of the meta-atom model

def metaatom_meep(x, gap, rot_angle_deg, wl_max, wl_min, component):

    # general parameters
    h = 7.5                                             # pillar height
    a = 8
    l1, w1, l2, w2 = x                                  # lengths/widths fo pillars
    sy = sz = a                                         # lattice width/height (um)
    gap = 2.0

    fmin = 1/wl_max                                     # min frequency
    fmax = 1/wl_min                                     # max frequency
    fcen = 0.5*(fmin+fmax)                              # center frequency
    df = fmax-fmin                                      # frequency width
    nfreq = 100                                         # number of frequencies

    n1 = 3.42                                           # refractive index of silicon
    n2 = 1                                              # refractive index of air
    Si = mp.Medium(index=n1)                          # define material
    Air = mp.Medium(index=n2)                            # define material 

    # parameters only for MEEP
    resolution = 4                                     # gives the number of pixels per distance unit (pixels/μm)
    dpml = 12                                           # perfectly matched layers 

    sx = 51.22                                          # cell size on X direction 
    sy = a                                             # cell size on Y direction
    sz = a                                             # cell size on Z direction
    cell_size = mp.Vector3(sx, sy, sz)                  # 3D model of cell

    k_point = mp.Vector3(0, 0, 0)                       #the boundaries are Bloch-periodic

    pml_layers = [mp.PML(thickness=dpml, direction=mp.X)] # Perfectly Matched Layers (X direction)
    
    L = 10.11                                           # the total distance from source to interface  

    # define parameters of substrate
    dsub = 25.61                                        # substrate thickness 
    substrate_size = mp.Vector3(dsub, a, a)
    substrate_center = mp.Vector3(-12.8, 0, 0)

    # define parameters of pillar centers
    yc_gap1 = -0.5*gap # distance from center to left-handed  pillar #1 edge
    yc_gap2 =  0.5*gap # distance from center to right-handed pillar #2 edge
    angle = rot_angle_deg*np.pi/180
    
    # center vectors of pillars
    p1_cent = mp.Vector3(y=yc_gap1+np.sign(yc_gap1)*0.5*l1).rotate(mp.Vector3(x=1),angle)
    p2_cent = mp.Vector3(y=yc_gap2+np.sign(yc_gap2)*0.5*l2).rotate(mp.Vector3(x=1),angle)   

    #define parameters of source polarization and parity
    cross_polarization = True       # else co_polarization = True

    if component == mp.Ey:
        eig_parity = mp.ODD_Y + mp.EVEN_Z 
        if cross_polarization:
            eig_parity_ph = mp.ODD_Z + mp.EVEN_Y   
        else:
            eig_parity_ph = mp.ODD_Y + mp.EVEN_Z             
    else:                             # component == mp.Ez:  
        eig_parity = mp.ODD_Z + mp.EVEN_Y 
        if cross_polarization:
            eig_parity_ph = mp.ODD_Y + mp.EVEN_Z  
        else:
            eig_parity_ph = mp.ODD_Z + mp.EVEN_Y             

    source_center = mp.Vector3(-2.5, 0, 0)
    source_size = mp.Vector3(0, a, a)

    #define parameters of monitors
    tran_monitor_center = mp.Vector3(7.61, 0, 0)
    tran_monitor_size = mp.Vector3(0, a, a)

    refl_monitor_center = mp.Vector3(-2.3, 0, 0)
    refl_monitor_size = mp.Vector3(0, a, a)

    # geometry and parameters of the source
    sources = [
        mp.Source(
        mp.GaussianSource(fcen, fwidth=df),
        component=component,
        center=source_center,
        size=source_size,
        )
        ]     

    # simulation
    sim = mp.Simulation(
        resolution=resolution,
        cell_size=cell_size,
        boundary_layers=pml_layers,
        default_material=Air,
        k_point=k_point,
        sources=sources,
        )

    # transmitted flux
    tran = sim.add_flux(fcen, df, nfreq, mp.FluxRegion(
        center=tran_monitor_center, size=tran_monitor_size))
    
    # call the simulation
    sim.run(until = 400)            

    # return a list of the frequencies
    flux_freqs = mp.get_flux_freqs(tran)

    # define the initial phase for normalization
    res_tran = sim.get_eigenmode_coefficients(tran, [1], eig_parity = eig_parity)
    input_phase = (np.angle(res_tran.alpha[0, :, 0])) - (2 * np.pi * np.array(flux_freqs[:]) * n2 * L) 

    # a list of the wavelength
    wl = (1/np.array(flux_freqs[:]))
    input_phase = np.unwrap(input_phase)

    sim.reset_meep()

    # geometry and parameters of the source
    sources = [
        mp.Source(
        mp.GaussianSource(fcen, fwidth=df),
        component=component,
        center=source_center,
        size=source_size,
        )
        ]     

    # simulation
    sim = mp.Simulation(
        resolution=resolution,
        cell_size=cell_size,
        boundary_layers=pml_layers,
        default_material=Si,
        k_point=k_point,
        sources=sources,
        )

    # transmitted flux
    tran = sim.add_flux(fcen, df, nfreq, mp.FluxRegion(
        center=tran_monitor_center, size=tran_monitor_size))

    # reflected flux    
    refl = sim.add_flux(fcen, df, nfreq, mp.FluxRegion(
        center=refl_monitor_center, size=refl_monitor_size))

    # call the simulation
    sim.run(until = 400)                        

    input_flux = mp.get_fluxes(tran) # save incident power for transmission plane
    straight_refl_data = sim.get_flux_data(refl) # for normalization run, save flux fields data for reflection plane

    sim.reset_meep()

    # geometry of substrate
    geometry =[mp.Block(
        material=Si,
        size=substrate_size, 
        center=substrate_center,
        ),
        mp.Block(
            size=mp.Vector3(h,l1,w1),
            center=p1_cent,
            material=Si,
            e1=mp.Vector3(x=1),
            e2=mp.Vector3(y=1).rotate(mp.Vector3(x=1),angle),
            e3=mp.Vector3(z=1).rotate(mp.Vector3(x=1),angle)),
        mp.Block(
            size=mp.Vector3(h,l2,w2),
            center=p2_cent,
            material=Si,
            e1=mp.Vector3(x=1),
            e2=mp.Vector3(y=1).rotate(mp.Vector3(x=1),angle),
            e3=mp.Vector3(z=1).rotate(mp.Vector3(x=1),angle)),
    ]

    # simulation
    sim = mp.Simulation(
        resolution=resolution,
        cell_size=cell_size,
        boundary_layers=pml_layers,
        geometry=geometry,
        k_point=k_point,
        sources=sources,
        )

    # transmitance monitor
    tran = sim.add_flux(fcen, df, nfreq, mp.FluxRegion(
                center=tran_monitor_center, size=tran_monitor_size))

    # reflected flux    
    refl = sim.add_flux(fcen, df, nfreq, mp.FluxRegion(
        center=refl_monitor_center, size=refl_monitor_size))            
    # cross section visualisation of the simulation domain
    sim.plot2D(output_plane=mp.Volume(center=mp.Vector3(1, 0), size=mp.Vector3(0, a, a)))

    sim.load_minus_flux_data(refl, straight_refl_data) 
 
    # call the simulation
    sim.run(until = 400)                            

    #freqs = mp.get_eigenmode_freqs(tran)
    res = sim.get_eigenmode_coefficients(tran, [1], eig_parity = eig_parity_ph)

    Ps = np.angle(res.alpha[0,:,0]) - input_phase[:] - (2 * np.pi * np.array(flux_freqs[:]) * n1 * 0.11) - (2 * np.pi * np.array(flux_freqs[:]) * n2 * 2.5) 
    # mode_tran = abs(res.alpha[0,:,0])**2/input_flux[:]
    bend_tran_flux = np.array(mp.get_fluxes(tran))
    bend_refl_flux = np.array(mp.get_fluxes(refl))

    Tr_total = bend_tran_flux[:]/input_flux[:]
    Rf_total = -bend_refl_flux[:]/input_flux[:]

    return wl, Ps, Tr_total, Rf_total


x = [2, 1.4, 1.6, 2.4]                              # lengths and widths of rectangular pillars
gap = 2.0                                           # distance between rectangular pillars
angle_deg = 45                                      # rotation angle of eacg pillar
wl_max = 12                                         # max wavelength 
wl_min = 8                                          # min wavelength 
component = mp.Ey                                   # specify the direction and type of the current component

wl, Ps, Ts, Rt= metaatom_meep(x, gap, angle_deg, wl_max, wl_min, component)

Ps= np.unwrap(Ps)

plt.figure()
plt.plot(wl, Ps, color = "C3", marker="*", label="Phase")
plt.xlabel("wavelength (μm)")
plt.ylabel("phase (rad)")
plt.legend(loc="upper right")
plt.title('Phase')
plt.show()

plt.figure()
plt.plot(wl, Ts, color = "C1", marker="*", label="Transmittance")
plt.plot(wl, Rt, color = "C2", marker="*", label="Reflectance")
plt.xlabel("wavelength (μm)")
plt.legend(loc="upper right")
plt.title('Phase')
plt.show()


# %%
