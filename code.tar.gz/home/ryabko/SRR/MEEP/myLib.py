#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Aug 18 10:27:51 2023

@author: ryabko
"""
import matplotlib.pyplot as plt
import numpy as np
import shelve
import scipy.fftpack

def fourierTransform2D(E, k, res, sx,sy, resx=1e3, resy=1e3, cutoff = 1e-10):
    keys = list(E.keys())
    FourierFields=dict.fromkeys(keys)

    Nx = int(resx/k.x/sx)
    Ny = int(resy/k.y/sy)
    
    
    
    numberOfPointsX = Nx*(res*sx)
    numberOfPointsY = Ny*(res*sy)
    # deltaK = 1/(sy*N)

    fx = np.linspace(0.0, res/(2.0), int(numberOfPointsX//2))
    fy = np.linspace(0.0, res/(2.0), int(numberOfPointsX//2))
    
    for comp in keys:
        E_enlarged = np.tile(E[comp], (Ny,Nx))
        F = scipy.fftpack.fft2(E_enlarged)
        FourierFields[comp] = 2.0/numberOfPointsX/numberOfPointsY * np.abs(F[:int(numberOfPointsX//2),:int(numberOfPointsY//2)])
   
    return fx, fy, FourierFields

def fourierTransform(E, k, res, sx, resx=1e3):
    keys = list(E.keys())
    FourierFields=dict.fromkeys(keys)
    FourierFields_1=dict.fromkeys(keys)
    
    Nx = int(resx/k.z/sx)

    
    numberOfPointsX = Nx*(res*sx)
    fx = np.linspace(0.0, res/(2.0), int(numberOfPointsX//2))
    step = res/(2.0)/int(numberOfPointsX//2)
    fx_1 = np.linspace(-res/(2.0)-step, res/(2.0), int(numberOfPointsX))
    
    for i, k in enumerate(E):
        
        G = np.tile(E[k], (Nx,1))
        
        F = scipy.fftpack.fft(G.T)
        # print(F.shape)
        FourierFields[k] = 2.0/numberOfPointsX * np.abs(F[0,:int(numberOfPointsX//2)])
        FourierFields_1[k] = 2.0/numberOfPointsX * np.abs(np.concatenate((F[0,-int(numberOfPointsX//2):],F[0,:int(numberOfPointsX//2)])))
        # FourierFields_1[k] = 2.0/numberOfPointsX * np.abs(F[0,int(numberOfPointsX//2):-1])
        

    return fx, FourierFields, fx_1, FourierFields_1

   
def saveWorkspace(filename):
    
    my_shelf = shelve.open(filename,'n') # 'n' for new
    
    for key in dir():
        try:
            my_shelf[key] = globals()[key]
        except :
            #
            # __builtins__, my_shelf, and imported modules can not be shelved.
            #
            print('ERROR shelving: {0}'.format(key))
    my_shelf.close()
    
def restoreWorkspace(filename):    
    my_shelf = shelve.open(filename)
    for key in my_shelf:
        globals()[key]=my_shelf[key]
    my_shelf.close()

def calibrateFieldonIncidentWave(Field, E):
    keys = list(Field.keys())
    F=dict.fromkeys(keys)
    sizeX = E.shape[0]
    sizeY = E.shape[1]
    for i, k in enumerate(Field):
        F[k] = np.divide(Field[k],E)[:(-2 if (sizeX%2 == 0 and sizeX>2) else sizeX-1),:(-2 if (sizeY%2 == 0 and sizeY>2) else sizeY-1)]
    return  F
  
def calibrateFieldonPlaneWave(sx, sy, res, k, E):
    keys = list(E.keys())
    sizeX = E[keys[0]].shape[0]
    sizeY = E[keys[0]].shape[1]
    dx=1/res 
    dy=1/res
    x = np.linspace(0, sx-dx, sizeX-2 if (sizeX%2 == 0 and sizeX>2) else sizeX-1).T
    x = np.exp(1j*2*np.pi*(k.x*x))
    x = np.vstack((x,) * (sizeY-2 if (sizeY%2 == 0 and sizeY>2) else sizeY-1))
    
    y = np.linspace(0, sy, sizeY-2 if (sizeY%2 == 0 and sizeY>2) else sizeY-1).T
    y = np.exp(1j*2*np.pi*(k.y*y))
    y = np.vstack((y,) * (sizeX-2 if (sizeX%2 == 0 and sizeX>2) else sizeX-1)).T
    
    for comp in keys:
        E[comp] = np.divide(E[comp][:(-2 if (sizeX%2 == 0 and sizeX>2) else sizeX-1),:(-2 if (sizeY%2 == 0 and sizeY>2) else sizeY-1)], np.multiply(x,y).T)
    
    # x = np.linspace(0, sx, sizeX-1).T
    
    # # x = np.append(x,x[0])
    # if sizeX%2 == 0:
    #    x = np.append(x,x[-1]+x[1])
    # x = np.exp(1j*2*np.pi*(k.x*x))
    # x = np.vstack((x,) * (sizeY if sizeY%2 == 0 else sizeY-1))
    # print(x.shape)
    # y = np.linspace(0, sy, sizeY-1)
   
    # # y =np.append(y,y[0])
    # if sizeY%2 == 0:
    #     y = np.append(y,y[1]+y[-1])
    # y = np.exp(1j*2*np.pi*(k.y*y))
    # y = np.vstack((y,) * (sizeX if sizeX%2 == 0 else sizeX-1)).T

    return E, np.multiply(x,y).T

# def calculateAngles(ee,hh,kk):
#     eee =(np.array(ee))
#     hhh =(np.array(hh))
#     ek=eee[0]*0
#     hk=eee[0]*0
#     eh=eee[0]*0
#     e_norm=eee[0]*0
#     h_norm=eee[0]*0
#     for i in range(len(ee)):
#         ek += (eee[i])*kk[i]
#         hk += hhh[i]*kk[i]
#         eh += (eee[i])*(hhh[i])
#         e_norm += eee[i]**2
#         h_norm += hhh[i]**2

#     k_norm = np.linalg.norm(kk)
#     e_norm = abs(e_norm**0.5)
#     h_norm = abs(h_norm**0.5)

#     angle_eh = np.degrees(np.arccos(abs(eh)/(h_norm)/(e_norm)))
#     angle_ek = (np.degrees(np.arccos(abs(hk)/(h_norm)/(k_norm))))
#     angle_hk = (np.degrees(np.arccos(abs(ek)/(k_norm)/(e_norm))))
    
#     return angle_eh, angle_ek, angle_hk

def calculateFieldAngles(Fields, k):
    angle =dict.fromkeys(['eh', 'ek', 'hk'])
    k_norm = np.sqrt(k.x**2 + k.y**2 + k.z**2)
    e_norm = np.abs((np.sqrt(Fields['Ex']**2 + Fields['Ey']**2 + Fields['Ez']**2)))
    h_norm = np.abs((np.sqrt(Fields['Hx']**2 + Fields['Hy']**2 + Fields['Hz']**2)))
    
    ek = (Fields['Ex']*k.x +Fields['Ey']*k.y + Fields['Ez']*k.z)
    eh = (Fields['Ex']*Fields['Hx'] +Fields['Ey']*Fields['Hy'] + Fields['Ez']*Fields['Hz'])
    hk = (Fields['Hx']*k.x +Fields['Hy']*k.y + Fields['Hz']*k.z)


    angle['eh'] = np.degrees(np.arccos(abs(eh)/(h_norm)/(e_norm)))
    angle['hk'] = (np.degrees(np.arccos(np.abs(hk)/(h_norm)/(k_norm))))
    angle['ek'] = (np.degrees(np.arccos(abs(ek)/(k_norm)/(e_norm))))
    
    return angle

def FresnelReflTrans(alpha, phi, n1, n2):
    Rs = ( (n1*np.cos(phi)- n2*np.sqrt(1-(n1*np.sin(phi)/n2)**2) ) / (n1*np.cos(phi) + n2*np.sqrt(1-(n1*np.sin(phi)/n2)**2)) )**2
    Ts = 1-Rs
    Rp = ( (n2*np.cos(phi)- n1*np.sqrt(1-(n1*np.sin(phi)/n2)**2) ) / (n2*np.cos(phi) + n1*np.sqrt(1-(n1*np.sin(phi)/n2)**2)) )**2
    Tp = 1-Rp

    # fig, (ax1, ax2) = plt.subplots(nrows=2, figsize=(6, 5.4))
    # im = ax1.plot(angle, Rs, angle, Ts)
    # ax1.set_title('S polarization ')
    # ax1.set_xlim([0, 90])

    # im = ax2.plot(angle, Rp, angle, Tp)
    # ax2.set_title('P polarization ')
    # ax2.set_xlim([0, 90])

    # plt.show()
    return Rs, Rp, Ts, Tp

# def FieldsDecomposition(Vs_i, Vp_i, e_i, h_i):
#     e_i_s = e_i[0]*Vs_i[0] + e_i[1]*Vs_i[1] + e_i[2]*Vs_i[2]
#     h_i_s = h_i[0]*Vs_i[0] + h_i[1]*Vs_i[1] + h_i[2]*Vs_i[2]


#     e_i_p = e_i[0]*Vp_i[0] + e_i[1]*Vp_i[1] + e_i[2]*Vp_i[2]
#     h_i_p = h_i[0]*Vp_i[0] + h_i[1]*Vp_i[1] + h_i[2]*Vp_i[2]
    
#     return e_i_s, e_i_p, h_i_s, h_i_p

def FieldsDecomposition(Fields, k): 
    
    #Decomposition of the Field in to s- ans p- components
    # s vector is a normal vector (vector product) to substrate norm: 0,0,1 and k
    # p vector is norm to s and k     
    
    F = dict.fromkeys('Es','Ep', 'Hs', 'Hp', 'Vs', 'Vp')
    Vs = np.cross(np.array([k.x, k.y, -k.z]),np.array([0,0,1]))
    Vs = Vs/np.linalg.norm(Vs)
    Vp = np.cross(np.array([k.x, k.y, -k.z]),Vs)
    Vp = Vp/np.linalg.norm(Vp)
    
    F['Es'] = Fields['Ex']*Vs[0]+Fields['Ey']*Vs[1]+Fields['Ez']*Vs[2]
    F['Hp'] = Fields['Hx']*Vs[0]+Fields['Hy']*Vs[1]+Fields['Hz']*Vs[2]
    F['Ep'] = Fields['Ex']*Vp[0]+Fields['Ey']*Vp[1]+Fields['Ez']*Vp[2]
    F['Hs'] = Fields['Hx']*Vp[0]+Fields['Hy']*Vp[1]+Fields['Hz']*Vp[2]
    F['Vs'] = Vs
    F['Vp'] = Vp

    return F

def Pointing(Fields):

    Sz = np.real(np.multiply(Fields['Ex'],np.conj(Fields['Hy'])) - np.multiply(Fields['Ey'],np.conj(Fields['Hx'])))
    return  Sz

def plotFieldsAbs(E, labels):
    from matplotlib import cm
    cmap = cm.PRGn
    
    fig, _axs = plt.subplots(nrows=len(E), ncols=1)
    axs = _axs.flatten()
    k=0

    for i in E:
        
        axs[k].set_title(labels[k])
        im=axs[k].imshow(np.abs(i), cmap=cmap)
        fig.colorbar(im, ax=axs[k])
        k+=1
    fig.suptitle('Field distributions')

    plt.show()

def plotFieldsReal(E, labels):
    from matplotlib import cm
    cmap = cm.PRGn
    
    fig, _axs = plt.subplots(nrows=len(E), ncols=1)
    axs = _axs.flatten()
    k=0

    for i in E:
        
        axs[k].set_title(labels[k])
        im=axs[k].imshow(np.real(i), cmap=cmap)
        fig.colorbar(im, ax=axs[k])
        k+=1
    fig.suptitle('Field distributions')

    plt.show()
    
def plotFieldsAngle(E, labels):
    from matplotlib import cm
    cmap = cm.PRGn
    
    fig, _axs = plt.subplots(nrows=len(E), ncols=1)
    axs = _axs.flatten()
    k=0

    for i in E:
        
        axs[k].set_title(labels[k])
        im=axs[k].imshow(np.angle(i), cmap=cmap)
        fig.colorbar(im, ax=axs[k])
        k+=1
    fig.suptitle('Field distributions')

    plt.show()
    