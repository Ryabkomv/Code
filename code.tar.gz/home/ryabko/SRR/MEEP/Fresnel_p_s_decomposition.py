#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Aug  8 16:50:05 2023

@author: ryabko
"""

import meep as mp
import math
import cmath
import numpy as np

import matplotlib.pyplot as plt
plt.close('all')
plotSimulationRegion = False

def calibrateFieldonPlaneWave(sx, sy, N, k, E):
    x = np.linspace(0, sx, N+1).T
    
    # x = np.append(x,x[0])
    if N%2 == 0:
       x = np.append(x,x[-1]+x[1])
    x = np.exp(1j*2*np.pi*(k.x*x))
    x = np.vstack((x,) * (N+2 if N%2 == 0 else N+1))

    y = np.linspace(0, sy, N+1)
   
    # y =np.append(y,y[0])
    if N%2 == 0:
        y = np.append(y,y[1]+y[-1])
    y = np.exp(1j*2*np.pi*(k.y*y))
    y = np.vstack((y,) * (N+2 if N%2 == 0 else N+1)).T

    return np.divide(E, np.multiply(x,y).T), np.multiply(x,y).T
   
    
def calculateAngles(ee,hh,kk):
    eee =(np.array(ee))
    hhh =(np.array(hh))
    ek=eee[0]*0
    hk=eee[0]*0
    eh=eee[0]*0
    e_norm=eee[0]*0
    h_norm=eee[0]*0
    for i in range(len(ee)):
        ek += (eee[i])*kk[i]
        hk += hhh[i]*kk[i]
        eh += (eee[i])*(hhh[i])
        e_norm += eee[i]**2
        h_norm += hhh[i]**2

    k_norm = np.linalg.norm(kk)
    e_norm = abs(e_norm**0.5)
    h_norm = abs(h_norm**0.5)

    angle_eh = np.degrees(np.arccos(abs(eh)/(h_norm)/(e_norm)))
    angle_ek = (np.degrees(np.arccos(abs(hk)/(h_norm)/(k_norm))))
    angle_hk = (np.degrees(np.arccos(abs(ek)/(k_norm)/(e_norm))))
    
    return angle_eh, angle_ek, angle_hk


N = 40
resolution = 10
                            # gives the number of pixels per distance unit (pixels/μm)

dpml = 10                                                                                                           
pml_layers = [mp.PML(thickness=dpml, direction=mp.Z)] # Perfectly Matched Layers (X direction)                                         # perfectly matched layers 

sz=40
sx = sy = N/resolution

wl_max = 12                                        # max wavelength 
wl_min =8                                          # min wavelength 


fmin = 1/wl_max                                     # min frequency
fmax = 1/wl_min                                     # max frequency
fcen = 0.5*(fmin+fmax)                              # center frequency
df = fmax-fmin                                      # frequency width
nfreq = 100                                         # number of frequencies
frequency = np.linspace(fmin,fmax,nfreq)
frequency_num = 50

n2 = 3.42                                           # refractive index of silicon
n1 = 1                                              # refractive index of air
Si = mp.Medium(index=n2)                          # define material
Air = mp.Medium(index=n1)                            # define material   

component = mp.Ex#mp.Ex+mp.Hx

theta = math.radians(30)
phi = math.radians(20)


substrate_size = mp.Vector3(mp.inf, mp.inf,sz/2)
substrate_center = mp.Vector3(0, 0, -sz/4)

source_center = mp.Vector3(0, 0, 7)
source_size = mp.Vector3(sx, sy, 0)

tran_monitor_center = mp.Vector3(0, 0, -5)
tran_monitor_size = mp.Vector3(sx, sy, 0)

refl_monitor_center = mp.Vector3(0, 0, 5)
refl_monitor_size = mp.Vector3(sx, sy, 0)

check_monitor_center = mp.Vector3(-7, 0, 0)
# check_monitor_center = mp.Vector3(-15, 0, 0)
# check_monitor_size = mp.Vector3(sx, sy, 0)


cell_size = mp.Vector3(sx,sy,sz)

# rotation angle of incident planewave; counter clockwise (CCW) about Z axis, 0 degrees along +X axis                                   


Rs = ( (n1*np.cos(phi)- n2*np.sqrt(1-(n1*np.sin(phi)/n2)**2) ) / (n1*np.cos(phi) + n2*np.sqrt(1-(n1*np.sin(phi)/n2)**2)) )**2
Ts = 1-Rs
Rp = ( (n2*np.cos(phi)- n1*np.sqrt(1-(n1*np.sin(phi)/n2)**2) ) / (n2*np.cos(phi) + n1*np.sqrt(1-(n1*np.sin(phi)/n2)**2)) )**2
Tp = 1-Rp


# k (in source medium) with correct length (plane of incidence: XY)                                                                     
k = mp.Vector3(math.sin(phi)*math.cos(theta), math.sin(phi)*math.sin(theta), math.cos(phi)).scale(frequency[frequency_num])
# k_r = mp.Vector3(-math.sin(phi)*math.cos(theta), -math.sin(phi)*math.sin(theta), -math.cos(phi)).scale(frequency[frequency_num])


Vs_i = np.cross(np.array([k.x, k.y, -k.z]),np.array(mp.Vector3(0,0,1)))
Vs_i = Vs_i/np.linalg.norm(Vs_i)
Vp_i = np.cross(np.array([k.x, k.y, -k.z]),Vs_i)
Vp_i = Vp_i/np.linalg.norm(Vp_i)

Vs_r = np.cross(np.array(k),np.array(mp.Vector3(0,0,1)))
Vs_r = Vs_r/np.linalg.norm(Vs_r)
Vp_r = np.cross(np.array(k),Vs_r)
Vp_r = Vp_r/np.linalg.norm(Vp_r)

Vs_t = np.cross(np.array([k.x, k.y, -np.sqrt(frequency[frequency_num]**2 * n2**2 - k.x**2 - k.y**2)]),np.array(mp.Vector3(0,0,1)))
Vs_t = Vs_t/np.linalg.norm(Vs_t)
Vp_t = np.cross(np.array([k.x, k.y, -np.sqrt(frequency[frequency_num]**2 * n2**2 - k.x**2 - k.y**2)]),Vs_t)
Vp_t = Vp_t/np.linalg.norm(Vp_t)

# Ve = Vs
# Vh = Vp

# Vs_r = np.cross(k_r,mp.Vector3(0,0,1))
# Vs_r = Vs_r/np.linalg.norm(Vs_r)
# Vp_r = np.cross(k,Vs_r)
# Vp_r = Vp_r/np.linalg.norm(Vp_r)

# Ve_n = Vs_r
# Vh_n = Vp_r

# Ve = [1,1,1]
# Vh = [1,1,1]

# Ve_n = [1,1,1]
# Vh_n = [1,1,1]

# def pw_amp(k,r0):
#   def _pw_amp(x):
#     return cmath.exp(1j*2*np.pi*(k.x*r0.x + k.y*r0.y + k.z*r0.z))
#   return _pw_amp

def tiltFunction(vec):
    return np.exp(1j*2*np.pi*(k.x*vec.x + k.y*vec.y + k.z*vec.z))

sources = [mp.Source(mp.GaussianSource(fcen, fwidth=df),
                     component=component,
                     center=source_center,
                     size=source_size,
                     amp_func=tiltFunction)]

geometry =[
    mp.Block(
    material=Si,
    size=substrate_size, 
    center=substrate_center,
    ),
    
]

sim = mp.Simulation(
                    resolution=resolution,
                    cell_size=cell_size,
                    # geometry=geometry,
                    boundary_layers=pml_layers,
                    default_material=Air,
                    k_point=k,
                    sources=sources,
                    force_complex_fields = True)


E_list = [mp.Ex, mp.Ey, mp.Ez]
fields_list = [mp.Ex, mp.Ey, mp.Ez, mp.Hx, mp.Hy, mp.Hz]
# %% Meep's flux monitor
transmission_monitor_normalization = sim.add_flux(frequency, mp.FluxRegion(
            center=tran_monitor_center, size=tran_monitor_size))

reflection_monitor_normalization = sim.add_flux(frequency, mp.FluxRegion(
            center=refl_monitor_center, size=refl_monitor_size))


# %% Along Z-axis monitors to check for incident angle
dft_obj_E_xz_Normalization = sim.add_dft_fields(E_list, frequency, center=mp.Vector3(), size=mp.Vector3(sx,0,sz))
# dft_obj_Ey_xz_Normalization = sim.add_dft_fields([mp.Ey], frequency, center=mp.Vector3(), size=mp.Vector3(sx,0,sz))
# dft_obj_Ez_xz_Normalization = sim.add_dft_fields([mp.Ez], frequency, center=mp.Vector3(), size=mp.Vector3(sx,0,sz))

dft_obj_E_yz_Normalization = sim.add_dft_fields(E_list, frequency, center=mp.Vector3(), size=mp.Vector3(0,sy,sz))
# dft_obj_Ey_yz_Normalization = sim.add_dft_fields([mp.Ey], frequency, center=mp.Vector3(), size=mp.Vector3(0,sy,sz))
# dft_obj_Ez_yz_Normalization = sim.add_dft_fields([mp.Ez], frequency, center=mp.Vector3(), size=mp.Vector3(0,sy,sz))


# %% Cross sectional monitors for power calculation
dft_obj_Reflection_Normalization = sim.add_dft_fields(fields_list, frequency, center=refl_monitor_center, size=refl_monitor_size)
# dft_obj_Ey_Reflection_Normalization = sim.add_dft_fields([mp.Ey], frequency, center=refl_monitor_center, size=refl_monitor_size)
# dft_obj_Ez_Reflection_Normalization = sim.add_dft_fields([mp.Ez], frequency, center=refl_monitor_center, size=refl_monitor_size)

dft_obj_Transmission_Normalization = sim.add_dft_fields(fields_list, frequency, center=tran_monitor_center, size=tran_monitor_size)
# dft_obj_Ey_Transmission_Normalization = sim.add_dft_fields([mp.Ey], frequency, center=tran_monitor_center, size=tran_monitor_size)
# dft_obj_Ez_Transmission_Normalization = sim.add_dft_fields([mp.Ez], frequency, center=tran_monitor_center, size=tran_monitor_size)



# dft_obj_Hx_Reflection_Normalization = sim.add_dft_fields([mp.Hx], frequency, center=refl_monitor_center, size=refl_monitor_size)
# dft_obj_Hy_Reflection_Normalization = sim.add_dft_fields([mp.Hy], frequency, center=refl_monitor_center, size=refl_monitor_size)
# dft_obj_Hz_Reflection_Normalization = sim.add_dft_fields([mp.Hz], frequency, center=refl_monitor_center, size=refl_monitor_size)

# dft_obj_Hx_Transmission_Normalization = sim.add_dft_fields([mp.Hx], frequency, center=tran_monitor_center, size=tran_monitor_size)
# dft_obj_Hy_Transmission_Normalization = sim.add_dft_fields([mp.Hy], frequency, center=tran_monitor_center, size=tran_monitor_size)
# dft_obj_Hz_Transmission_Normalization = sim.add_dft_fields([mp.Hz], frequency, center=tran_monitor_center, size=tran_monitor_size)





sim.init_sim()

# source_fields=sim.get_source(component=component, center= mp.Vector3(-10,0,0), size = source_size)

if plotSimulationRegion:
    

    plt.figure()
    sim.plot2D(output_plane=mp.Volume(center=mp.Vector3(), size=mp.Vector3(sx, sy, 0)))
    
    plt.figure()
    sim.plot2D(output_plane=mp.Volume(center=mp.Vector3(), size=mp.Vector3(sx, 0, sz)))
    
    
    plt.figure()
    sim.plot2D(output_plane=mp.Volume(center=mp.Vector3(), size=mp.Vector3(0, sy, sz)))
    
    src_data = sim.get_source(component, center=mp.Vector3(), size=mp.Vector3(sx,sy,0))


sim.run(until_after_sources=mp.stop_when_fields_decayed(50, component, check_monitor_center, 1e-8))


# %% Processing normalization data

R_negation=sim.get_flux_data(reflection_monitor_normalization)

T_normalization = np.array(mp.get_fluxes(transmission_monitor_normalization))
R_normalization = np.array(mp.get_fluxes(reflection_monitor_normalization))

Ex_xz_Normalization = (sim.get_dft_array(dft_obj_E_xz_Normalization, mp.Ex, frequency_num))
Ey_xz_Normalization = (sim.get_dft_array(dft_obj_E_xz_Normalization, mp.Ey, frequency_num))
Ez_xz_Normalization = (sim.get_dft_array(dft_obj_E_xz_Normalization, mp.Ez, frequency_num))

Ex_yz_Normalization = (sim.get_dft_array(dft_obj_E_yz_Normalization, mp.Ex, frequency_num))
Ey_yz_Normalization = (sim.get_dft_array(dft_obj_E_yz_Normalization, mp.Ey, frequency_num))
Ez_yz_Normalization = (sim.get_dft_array(dft_obj_E_yz_Normalization, mp.Ez, frequency_num))


Ex_Transmission_Normalization = (sim.get_dft_array(dft_obj_Transmission_Normalization, mp.Ex, frequency_num))
Ey_Transmission_Normalization = (sim.get_dft_array(dft_obj_Transmission_Normalization, mp.Ey, frequency_num))
Ez_Transmission_Normalization = (sim.get_dft_array(dft_obj_Transmission_Normalization, mp.Ez, frequency_num))

Ex_Reflection_Normalization = (sim.get_dft_array(dft_obj_Reflection_Normalization, mp.Ex, frequency_num))
Ey_Reflection_Normalization = (sim.get_dft_array(dft_obj_Reflection_Normalization, mp.Ey, frequency_num))
Ez_Reflection_Normalization = (sim.get_dft_array(dft_obj_Reflection_Normalization, mp.Ez, frequency_num))


Hx_Transmission_Normalization = (sim.get_dft_array(dft_obj_Transmission_Normalization, mp.Hx, frequency_num))
Hy_Transmission_Normalization = (sim.get_dft_array(dft_obj_Transmission_Normalization, mp.Hy, frequency_num))
Hz_Transmission_Normalization = (sim.get_dft_array(dft_obj_Transmission_Normalization, mp.Hz, frequency_num))

Hx_Reflection_Normalization = (sim.get_dft_array(dft_obj_Reflection_Normalization, mp.Hx, frequency_num))
Hy_Reflection_Normalization = (sim.get_dft_array(dft_obj_Reflection_Normalization, mp.Hy, frequency_num))
Hz_Reflection_Normalization = (sim.get_dft_array(dft_obj_Reflection_Normalization, mp.Hz, frequency_num))


# R_normalization_my = np.real(Ex_Reflection_Normalization*np.conj(Hy_Reflection_Normalization) - Hx_Reflection_Normalization*np.conj(Ey_Reflection_Normalization))
T_normalization_my = np.real(Ex_Transmission_Normalization*np.conj(Hy_Transmission_Normalization) - Ey_Transmission_Normalization*np.conj(Hx_Transmission_Normalization))


plt.figure()
plt.plot(1/frequency,-T_normalization)

# %% SIMULATION WITH GEOMETRY
# %%
sim.reset_meep()

sim = mp.Simulation(
                    resolution=resolution,
                    cell_size=cell_size,
                    geometry=geometry,
                    boundary_layers=pml_layers,
                    default_material=Air,
                    k_point=k,
                    sources=sources,
                    force_complex_fields = True)





# %% Meep's flux monitor
transmission_monitor = sim.add_flux(frequency, mp.FluxRegion(
            center=tran_monitor_center, size=tran_monitor_size))

reflection_monitor = sim.add_flux(frequency, mp.FluxRegion(
            center=refl_monitor_center, size=refl_monitor_size))


# %% Along Z-axis monitors to check for incident angle
dft_obj_E_xz = sim.add_dft_fields(E_list, frequency, center=mp.Vector3(), size=mp.Vector3(sx,0,sz))
# dft_obj_Ey_xz = sim.add_dft_fields([mp.Ey], frequency, center=mp.Vector3(), size=mp.Vector3(sx,0,sz))
# dft_obj_Ez_xz = sim.add_dft_fields([mp.Ez], frequency, center=mp.Vector3(), size=mp.Vector3(sx,0,sz))

dft_obj_E_yz = sim.add_dft_fields(E_list, frequency, center=mp.Vector3(), size=mp.Vector3(0,sy,sz))
# dft_obj_Ey_yz = sim.add_dft_fields([mp.Ey], frequency, center=mp.Vector3(), size=mp.Vector3(0,sy,sz))
# dft_obj_Ez_yz = sim.add_dft_fields([mp.Ez], frequency, center=mp.Vector3(), size=mp.Vector3(0,sy,sz))


# %% Cross sectional monitors for power calculation
dft_obj_Reflection = sim.add_dft_fields(fields_list, frequency, center=refl_monitor_center, size=refl_monitor_size)
# dft_obj_Ey_Reflection = sim.add_dft_fields([mp.Ey], frequency, center=refl_monitor_center, size=refl_monitor_size)
# dft_obj_Ez_Reflection = sim.add_dft_fields([mp.Ez], frequency, center=refl_monitor_center, size=refl_monitor_size)

dft_obj_Transmission = sim.add_dft_fields(fields_list, frequency, center=tran_monitor_center, size=tran_monitor_size)
# dft_obj_Ey_Transmission = sim.add_dft_fields([mp.Ey], frequency, center=tran_monitor_center, size=tran_monitor_size)
# dft_obj_Ez_Transmission = sim.add_dft_fields([mp.Ez], frequency, center=tran_monitor_center, size=tran_monitor_size)



# dft_obj_Hx_Reflection = sim.add_dft_fields([mp.Hx], frequency, center=refl_monitor_center, size=refl_monitor_size)
# dft_obj_Hy_Reflection = sim.add_dft_fields([mp.Hy], frequency, center=refl_monitor_center, size=refl_monitor_size)
# dft_obj_Hz_Reflection = sim.add_dft_fields([mp.Hz], frequency, center=refl_monitor_center, size=refl_monitor_size)

# dft_obj_Hx_Transmission = sim.add_dft_fields([mp.Hx], frequency, center=tran_monitor_center, size=tran_monitor_size)
# dft_obj_Hy_Transmission = sim.add_dft_fields([mp.Hy], frequency, center=tran_monitor_center, size=tran_monitor_size)
# dft_obj_Hz_Transmission = sim.add_dft_fields([mp.Hz], frequency, center=tran_monitor_center, size=tran_monitor_size)


sim.load_minus_flux_data(reflection_monitor, R_negation)

sim.run(until_after_sources=mp.stop_when_fields_decayed(50, component, check_monitor_center, 1e-6))


# %% Processing data with geometry

T = np.array(mp.get_fluxes(transmission_monitor))
R = np.array(mp.get_fluxes(reflection_monitor))

Ex_xz = (sim.get_dft_array(dft_obj_E_xz, mp.Ex, frequency_num))
Ey_xz = (sim.get_dft_array(dft_obj_E_xz, mp.Ey, frequency_num))
Ez_xz = (sim.get_dft_array(dft_obj_E_xz, mp.Ez, frequency_num))

Ex_yz = (sim.get_dft_array(dft_obj_E_yz, mp.Ex, frequency_num))
Ey_yz = (sim.get_dft_array(dft_obj_E_yz, mp.Ey, frequency_num))
Ez_yz = (sim.get_dft_array(dft_obj_E_yz, mp.Ez, frequency_num))


Ex_Transmission = (sim.get_dft_array(dft_obj_Transmission, mp.Ex, frequency_num))
Ey_Transmission = (sim.get_dft_array(dft_obj_Transmission, mp.Ey, frequency_num))
Ez_Transmission = (sim.get_dft_array(dft_obj_Transmission, mp.Ez, frequency_num))

Ex_Reflection = (sim.get_dft_array(dft_obj_Reflection, mp.Ex, frequency_num))
Ey_Reflection = (sim.get_dft_array(dft_obj_Reflection, mp.Ey, frequency_num))
Ez_Reflection = (sim.get_dft_array(dft_obj_Reflection, mp.Ez, frequency_num))


Hx_Transmission = (sim.get_dft_array(dft_obj_Transmission, mp.Hx, frequency_num))
Hy_Transmission = (sim.get_dft_array(dft_obj_Transmission, mp.Hy, frequency_num))
Hz_Transmission = (sim.get_dft_array(dft_obj_Transmission, mp.Hz, frequency_num))

Hx_Reflection = (sim.get_dft_array(dft_obj_Reflection, mp.Hx, frequency_num))
Hy_Reflection = (sim.get_dft_array(dft_obj_Reflection, mp.Hy, frequency_num))
Hz_Reflection = (sim.get_dft_array(dft_obj_Reflection, mp.Hz, frequency_num))


ex_normalized = Ex_Reflection-Ex_Reflection_Normalization
ey_normalized = Ey_Reflection-Ey_Reflection_Normalization
hx_normalized = Hx_Reflection-Hx_Reflection_Normalization
hy_normalized = Hy_Reflection-Hy_Reflection_Normalization


R_my = np.real(ex_normalized*np.conj(hy_normalized) - ey_normalized*np.conj(hx_normalized))
T_my = np.real(Ex_Transmission*np.conj(Hy_Transmission) - Ey_Transmission*np.conj(Hx_Transmission))


T_my=np.sum(T_my)/np.sum(T_normalization_my)
R_my=np.sum(R_my)/np.sum(T_normalization_my)

T_meep=T/T_normalization
R_meep=R/T_normalization

print('Meep transmission: ' + str(T_meep[frequency_num]))
print('My transmission: ' + str(T_my))
print('Meep reflection: ' + str(R_meep[frequency_num]))
print('My reflection: ' + str(R_my))

# %matplotlib qt

from matplotlib import cm
cmap = cm.PRGn
fig, _axs = plt.subplots(nrows=6, ncols=1)
axs = _axs.flatten()

axs[0].set_title('Field distribution Ex component XZ plane')
im1=axs[0].imshow(np.real(Ex_xz_Normalization), cmap=cmap)
fig.colorbar(im1, ax=axs[0])

axs[1].set_title('Field distribution Ex component YZ plane')
im2=axs[1].imshow(np.real(Ex_yz_Normalization), cmap=cmap)
fig.colorbar(im2, ax=axs[1])

axs[2].set_title('Field distribution Ey component XZ plane')
im3=axs[2].imshow(np.real(Ey_xz_Normalization), cmap=cmap)
fig.colorbar(im3, ax=axs[2])

axs[3].set_title('Field distribution Ey component YZ plane')
im4=axs[3].imshow(np.real(Ey_yz_Normalization), cmap=cmap)
fig.colorbar(im4, ax=axs[3])

axs[4].set_title('Field distribution Ez component XZ plane')
im5=axs[4].imshow(np.real(Ez_xz_Normalization), cmap=cmap)
fig.colorbar(im5, ax=axs[4])

axs[5].set_title('Field distribution Ez component YZ plane')
im6=axs[5].imshow(np.real(Ez_yz_Normalization), cmap=cmap)
fig.colorbar(im6, ax=axs[5])

fig.suptitle('Field distributions')

plt.show()


fig, _axs = plt.subplots(nrows=6, ncols=1)
axs = _axs.flatten()

axs[0].set_title('Field distribution Ex component XZ plane')
im1=axs[0].imshow(np.real(Ex_xz), cmap=cmap)
fig.colorbar(im1, ax=axs[0])

axs[1].set_title('Field distribution Ex component YZ plane')
im2=axs[1].imshow(np.real(Ex_yz), cmap=cmap)
fig.colorbar(im2, ax=axs[1])

axs[2].set_title('Field distribution Ey component XZ plane')
im3=axs[2].imshow(np.real(Ey_xz), cmap=cmap)
fig.colorbar(im3, ax=axs[2])

axs[3].set_title('Field distribution Ey component YZ plane')
im4=axs[3].imshow(np.real(Ey_yz), cmap=cmap)
fig.colorbar(im4, ax=axs[3])

axs[4].set_title('Field distribution Ez component XZ plane')
im5=axs[4].imshow(np.real(Ez_xz), cmap=cmap)
fig.colorbar(im5, ax=axs[4])

axs[5].set_title('Field distribution Ez component YZ plane')
im6=axs[5].imshow(np.real(Ez_yz), cmap=cmap)
fig.colorbar(im6, ax=axs[5])

fig.suptitle('Field distributions')

plt.show()

# fig, _axs = plt.subplots(nrows=6, ncols=1)
# axs = _axs.flatten()

# axs[0].set_title('Field distribution Ex component XZ plane')
# im1=axs[0].imshow(np.abs(Ex_xz_Normalization), cmap=cmap)
# fig.colorbar(im1, ax=axs[0])

# axs[1].set_title('Field distribution Ex component YZ plane')
# im2=axs[1].imshow(np.abs(Ex_yz_Normalization), cmap=cmap)
# fig.colorbar(im2, ax=axs[1])

# axs[2].set_title('Field distribution Ey component XZ plane')
# im3=axs[2].imshow(np.abs(Ey_xz_Normalization), cmap=cmap)
# fig.colorbar(im3, ax=axs[2])

# axs[3].set_title('Field distribution Ey component YZ plane')
# im4=axs[3].imshow(np.abs(Ey_yz_Normalization), cmap=cmap)
# fig.colorbar(im4, ax=axs[3])

# axs[4].set_title('Field distribution Ez component XZ plane')
# im5=axs[4].imshow(np.abs(Ez_xz_Normalization), cmap=cmap)
# fig.colorbar(im5, ax=axs[4])

# axs[5].set_title('Field distribution Ez component YZ plane')
# im6=axs[5].imshow(np.abs(Ez_yz_Normalization), cmap=cmap)
# fig.colorbar(im6, ax=axs[5])

# fig.suptitle('Field distributions')

# plt.show()

e_i=[(Ex_Transmission_Normalization), (Ey_Transmission_Normalization), (Ez_Transmission_Normalization)]
h_i=[(Hx_Transmission_Normalization), (Hy_Transmission_Normalization), (Hz_Transmission_Normalization)]

angle_eh_i, angle_ek_i, angle_hk_i = calculateAngles(e_i,h_i,np.array([k.x, k.y, -k.z]))

e_t=[(Ex_Transmission), (Ey_Transmission), (Ez_Transmission)]
h_t=[(Hx_Transmission), (Hy_Transmission), (Hz_Transmission)]

angle_eh_t, angle_ek_t, angle_hk_t = calculateAngles(e_t,h_t,np.array([k.x, k.y, -np.sqrt(frequency[frequency_num]**2 * n2**2 - k.x**2 - k.y**2)]))

e_r=[(Ex_Reflection-Ex_Reflection_Normalization), (Ey_Reflection-Ey_Reflection_Normalization), (Ez_Reflection-Ez_Reflection_Normalization)]
h_r=[(Hx_Reflection-Hx_Reflection_Normalization), (Hy_Reflection-Hy_Reflection_Normalization), (Hz_Reflection-Hz_Reflection_Normalization)]

angle_eh_r, angle_ek_r, angle_hk_r = calculateAngles(e_r,h_r,np.array([k.x, k.y, k.z]))

# %% Incident field  
e_i_s = e_i[0]*Vs_i[0] + e_i[1]*Vs_i[1] + e_i[2]*Vs_i[2]
h_i_s = h_i[0]*Vs_i[0] + h_i[1]*Vs_i[1] + h_i[2]*Vs_i[2]


e_i_p = e_i[0]*Vp_i[0] + e_i[1]*Vp_i[1] + e_i[2]*Vp_i[2]
h_i_p = h_i[0]*Vp_i[0] + h_i[1]*Vp_i[1] + h_i[2]*Vp_i[2]


# %% Reflected field  

e_r_s = e_r[0]*Vs_r[0] + e_r[1]*Vs_r[1] + e_r[2]*Vs_r[2]
h_r_s = h_r[0]*Vs_r[0] + h_r[1]*Vs_r[1] + h_r[2]*Vs_r[2]


e_r_p = e_r[0]*Vp_r[0] + e_r[1]*Vp_r[1] + e_r[2]*Vp_r[2]
h_r_p = h_r[0]*Vp_r[0] + h_r[1]*Vp_r[1] + h_r[2]*Vp_r[2]

# %% Transmitted field  

e_t_s = e_t[0]*Vs_t[0] + e_t[1]*Vs_t[1] + e_t[2]*Vs_t[2]
h_t_s = h_t[0]*Vs_t[0] + h_t[1]*Vs_t[1] + h_t[2]*Vs_t[2]


e_t_p = e_t[0]*Vp_t[0] + e_t[1]*Vp_t[1] + e_t[2]*Vp_t[2]
h_t_p = h_t[0]*Vp_t[0] + h_t[1]*Vp_t[1] + h_t[2]*Vp_t[2]


# %% Power calculation  

pow_i_s = np.sum(np.real(e_i_s*np.conj(h_i_p)))
pow_i_p =  np.sum(np.real(e_i_p*np.conj(h_i_s)))

pow_r_s =  np.sum(np.real(e_r_s*np.conj(h_r_p)))
pow_r_p =  np.sum(np.real(e_r_p*np.conj(h_r_s)))

pow_t_s =  np.sum(np.real(e_t_s*np.conj(h_t_p)))
pow_t_p =  np.sum(np.real(e_t_p*np.conj(h_t_s)))

R_s_my = pow_r_s/pow_i_s
T_s_my = pow_t_s/pow_i_s

R_p_my = pow_r_p/pow_i_p
T_p_my = pow_t_p/pow_i_p
print('____________________________________________ ')
print('P_reflection: ' + str(Rp))
print('My P_reflection: ' + str(R_p_my))
print('S_reflection: ' + str(Rs))
print('My S_reflection: ' + str(R_s_my))



x, y=calibrateFieldonPlaneWave(sx, sy, N, k, Ex_Transmission_Normalization)

zz1=np.angle(Ex_Transmission_Normalization)
zz2=np.angle(Ex_Transmission)

zz1=zz1-zz1[0][0]
zz2=zz2-zz2[0][0]

xx=np.angle(x)

yy=np.angle(y)



# def f(r,fc):
#     print("({:.5f}, {:.5f}, {:.5f})".format(r.x,r.y,r.z))
#     return r

# sim.integrate_field_function([mp.Ex], f, center=tran_monitor_center, size=tran_monitor_size)

# np.fft2(Ex_Transmission)

# plt.figure()
# sim.plot2D(output_plane=mp.Volume(center=mp.Vector3(), size=mp.Vector3(sx, 0, sz)))
# source_fields=sim.get_source(component=mp.Ez, center= source_center, size = source_size)
# plt.figure()
# plt.imshow(np.real(Ex))
# cbar = plt.colorbar()
# plt.show()