#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Aug 18 11:24:12 2023

@author: ryabko
"""

from myLib import *
import numpy as np
import meep as mp
import math
import cmath
import matplotlib.pyplot as plt


filename='shelve.out'

plt.close('all')
resolution = 60        # pixels/μm. Use only odd number
decay =1e-9

dpml = 1.0             # PML thickness
dsub = 3.0             # substrate thickness
dpad = 3.0             # padding between grating and PML
gp_x = 10.0              # grating period
gp_y= mp.inf
gh = 0.5               # grating height
gdc_x = 0.5              # grating duty cycle
gdc_y = 1



sz = dpml+dsub+gh+dpad+dpml
sy=1/resolution
sx = gp_x

cell_size = mp.Vector3(sx,sy,sz)
pml_layers = [mp.PML(thickness=dpml,direction=mp.Z)]

wvl_min = 0.4           # min wavelength
wvl_max = 0.6           # max wavelength
fmin = 1/wvl_max        # min frequency
fmax = 1/wvl_min        # max frequency
fcen = 0.5*(fmin+fmax)  # center frequency
df = fmax-fmin          # frequency width
nfreq = 21

n2 = 1.5                                           # refractive index of silicon
n1 = 1                                              # refractive index of air
Si = mp.Medium(index=n2)                          # define material
Air = mp.Medium(index=n1) 


frequency = np.linspace(fmin,fmax,nfreq)
frequency_num = 8

component = mp.Ey#mp.Ex+mp.Hx

theta = math.radians(0)
phi = math.radians(10.7)

k = mp.Vector3(math.sin(phi)*math.cos(theta), math.sin(phi)*math.sin(theta), math.cos(phi)).scale(frequency[frequency_num]*n2)


substrate_size = mp.Vector3(mp.inf, mp.inf,dpml+dsub)
substrate_center = mp.Vector3(0,0,-0.5*sz+0.5*(dpml+dsub))
#change y coordinate of the grating
block_size = mp.Vector3(gp_x*gdc_x, gp_y*gdc_y , gh)
block_center = mp.Vector3(0,0,-0.5*sz+(dpml+dsub)+0.5*gh)

source_center = mp.Vector3(0, 0, -0.5*sz+dpml+dsub/2)
source_size = mp.Vector3(sx, sy, 0)

tran_monitor_center = mp.Vector3(0, 0, -0.5*sz+dpml+dsub+gh+dpad/2)
tran_monitor_size = mp.Vector3(sx, sy, 0)

refl_monitor_center = mp.Vector3(0, 0, -0.5*sz+dpml+dsub/2-0.5)
refl_monitor_size = mp.Vector3(sx, sy, 0)

check_monitor_center = mp.Vector3(0, 0, 0.5*sz-dpml-0.5*dpad)


# E_list = [mp.Ex, mp.Ey, mp.Ez]
# H_list = [mp.Hx, mp.Hy, mp.Hz]
Fields_list = [mp.Ex, mp.Ey, mp.Ez, mp.Hx, mp.Hy, mp.Hz]

keys = ['Ex', 'Ey', 'Ez', 'Hx', 'Hy', 'Hz']

Fields_Tran_n = dict.fromkeys(keys)
Fields_Tran_xz = dict.fromkeys(keys)
Fields_Tran_yz = dict.fromkeys(keys)

Fields_Refl_n = dict.fromkeys(keys)
Fields_Tran = dict.fromkeys(keys)
Fields_Refl = dict.fromkeys(keys)

Fields_Sub = dict.fromkeys(keys)                                               #Fields on reflection monitor main run minus normalization run

Fluxes = dict.fromkeys(['T_norm', 'R_norm', 'T', 'R'])  

def tiltFunction(vec):
    return np.exp(1j*2*np.pi*(k.x*vec.x + k.y*vec.y + k.z*vec.z))


geometry = [mp.Block(
                     material=Si,
                     size=substrate_size,
                     center=substrate_center),
            mp.Block(
                      material=Si,
                      size=block_size,
                      center=block_center)
        ]

sources = [mp.Source(mp.GaussianSource(fcen, fwidth=df),
                     component=component,
                     center=source_center,
                     size=source_size,
                     amp_func=tiltFunction)]

                     
sim = mp.Simulation(resolution=resolution,
                    # geometry = geometry,
                    cell_size=cell_size,
                    boundary_layers=pml_layers,
                    k_point=k,
                    default_material=Si,
                    sources=sources,
                    
                    )


# %% Meep's flux monitor
transmission_monitor_normalization = sim.add_flux(frequency, mp.FluxRegion(
            center=tran_monitor_center, size=tran_monitor_size))

reflection_monitor_normalization = sim.add_flux(frequency, mp.FluxRegion(
            center=refl_monitor_center, size=refl_monitor_size))

# %% Along Z-axis monitors to check for incident angle
dft_obj_xz_Normalization = sim.add_dft_fields(Fields_list, frequency, center=mp.Vector3(), size=mp.Vector3(sx,0,sz))
dft_obj_yz_Normalization = sim.add_dft_fields(Fields_list, frequency, center=mp.Vector3(), size=mp.Vector3(0,sy,sz))

# %% Cross sectional monitors for power calculation
dft_obj_Reflection_Normalization = sim.add_dft_fields(Fields_list, frequency, center=refl_monitor_center, size=refl_monitor_size)
dft_obj_Transmission_Normalization = sim.add_dft_fields(Fields_list, frequency, center=tran_monitor_center, size=tran_monitor_size)

sim.init_sim()

plotSimulationRegion = True
if plotSimulationRegion:
    
    if mp.am_master():
        plt.figure()
        sim.plot2D(output_plane=mp.Volume(center=mp.Vector3(), size=mp.Vector3(sx, sy, 0)))
        
        plt.figure()
        sim.plot2D(output_plane=mp.Volume(center=mp.Vector3(), size=mp.Vector3(sx, 0, sz)))
        
        
        plt.figure()
        sim.plot2D(output_plane=mp.Volume(center=mp.Vector3(), size=mp.Vector3(0, sy, sz)))
    
    # src_data = sim.get_source(component, center=mp.Vector3(), size=mp.Vector3(sx,sy,0))
    
sim.run(until_after_sources=mp.stop_when_fields_decayed(50, component, check_monitor_center, decay))


R_negation=sim.get_flux_data(reflection_monitor_normalization)

T_normalization = np.array(mp.get_fluxes(transmission_monitor_normalization))
# R_normalization = np.array(mp.get_fluxes(reflection_monitor_normalization))


c=0
for comp in Fields_list:
    # Fields_Tran_xz[keys[c]] = sim.get_dft_array(dft_obj_xz_Normalization, comp, frequency_num)
    # Fields_Tran_yz[keys[c]] = sim.get_dft_array(dft_obj_yz_Normalization, comp, frequency_num)
    
    Fields_Tran_n[keys[c]] = sim.get_dft_array(dft_obj_Transmission_Normalization, comp, frequency_num)
    Fields_Refl_n[keys[c]] = sim.get_dft_array(dft_obj_Reflection_Normalization, comp, frequency_num)   
    c+=1


sim.reset_meep()

sim = mp.Simulation(resolution=resolution,
                    geometry = geometry,
                    cell_size=cell_size,
                    boundary_layers=pml_layers,
                    k_point=k,
                    default_material=Air,
                    sources=sources,
                    
                    )


# %% Meep's flux monitor
transmission_monitor = sim.add_flux(frequency, mp.FluxRegion(
            center=tran_monitor_center, size=tran_monitor_size))

reflection_monitor = sim.add_flux(frequency, mp.FluxRegion(
            center=refl_monitor_center, size=refl_monitor_size))


# %% Along Z-axis monitors to check for incident angle
# dft_obj_xz = sim.add_dft_fields(E_list, frequency, center=mp.Vector3(), size=mp.Vector3(sx,0,sz))
# dft_obj_yz = sim.add_dft_fields(E_list, frequency, center=mp.Vector3(), size=mp.Vector3(0,sy,sz))


# %% Cross sectional monitors for power calculation
dft_obj_Reflection = sim.add_dft_fields(Fields_list, frequency, center=refl_monitor_center, size=refl_monitor_size)

dft_obj_Transmission = sim.add_dft_fields(Fields_list, frequency, center=tran_monitor_center, size=tran_monitor_size)

sim.load_minus_flux_data(reflection_monitor, R_negation)

sim.run(until_after_sources=mp.stop_when_fields_decayed(50, component, check_monitor_center, decay))


# %% Processing data with geometry








T = np.array(mp.get_fluxes(transmission_monitor))
R = np.array(mp.get_fluxes(reflection_monitor))
c=0

for comp in Fields_list:
    Fields_Tran[keys[c]] = sim.get_dft_array(dft_obj_Transmission, comp, frequency_num)
    Fields_Refl[keys[c]] = sim.get_dft_array(dft_obj_Reflection, comp, frequency_num)   
    
    Fields_Sub[keys[c]] = Fields_Refl[keys[c]] - Fields_Refl_n[keys[c]] 
    c+=1
        
if mp.am_master():
        
    Fluxes['T_norm'] = Pointing(Fields_Tran_n)
    Fluxes['R'] = Pointing(Fields_Sub)
    Fluxes['T'] =Pointing(Fields_Tran)
    
    
    T_my=np.sum(Fluxes['T'])/np.sum(Fluxes['T_norm'])
    R_my=np.sum(Fluxes['R'])/np.sum(Fluxes['T_norm'])
    
    T_meep=T/T_normalization
    R_meep=R/T_normalization


    saveWorkspace(filename)

    print('Meep transmission: ' + str(T_meep[frequency_num]))
    print('My transmission: ' + str(T_my))
    print('Meep reflection: ' + str(R_meep[frequency_num]))
    print('My reflection: ' + str(R_my))

    Fields_Tran_Normilized_On_Incident_Wave = calibrateFieldonIncidentWave(Fields_Tran,Fields_Tran_n["Ey"])
    Fields_Incident_Normilized_On_Incident_Wave = calibrateFieldonIncidentWave(Fields_Tran_n,Fields_Tran_n["Ey"])
    
    kk = mp.Vector3(math.sin(phi)*math.cos(theta), math.sin(phi)*math.sin(theta), math.cos(phi)).scale(frequency[frequency_num]*n1)
    
    fx,  FourierField_Tran = fourierTransform(Fields_Tran_Normilized_On_Incident_Wave, kk, resolution, sx)
    fx,  FourierField_Incident = fourierTransform(Fields_Incident_Normilized_On_Incident_Wave, kk, resolution, sx)
    
    S = Pointing(FourierField_Tran)/Pointing(FourierField_Incident)[0]
    
    a = S>1e-6
    
    print(S[a][:10])
    # print(np.degrees(np.arcsin(((fx[a]+k.x)[0:10]/frequency[frequency_num]))))
    print(np.degrees(np.arcsin(((fx[a]-k.x)[0:10]/frequency[frequency_num]))))
    
    angles=calculateFieldAngles(Fields_Tran_n, k)
    print(angles['hk'][0:10,0:2])
    
    
# Meep transmission: 0.9420695545117664
# My transmission: 0.9554159293118764
# Meep reflection: -0.057547869621954406
# My reflection: -0.057737757095944926
# [0.00178142 0.39000096 0.00107747 0.04238713 0.00114866 0.01460784
#  0.00123149 0.00690075 0.00132458 0.00364758]
# [10.7        13.63111725 16.59909811 19.61368786 22.68595885 25.82878022
#  29.05746746 32.39071425 35.85198245 39.47167044]
# [-10.7         -7.796976    -4.91397554  -2.04340669   0.82203464
#    3.68953576   6.56633076   9.45986704  12.37798574  15.32912857]
