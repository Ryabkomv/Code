#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Aug 18 10:27:14 2023

@author: ryabko
"""

from myLib import *
import numpy as np
import meep as mp
import math
import cmath
import matplotlib.pyplot as plt


resolution = 60        # pixels/μm

dpml = 1.0             # PML thickness
dsub = 3.0             # substrate thickness
dpad = 3.0             # padding between grating and PML
gp = 10.0              # grating period
gh = 0.5               # grating height
gdc = 0.5              # grating duty cycle

sx = dpml+dsub+gh+dpad+dpml
sy = gp

cell_size = mp.Vector3(sx,sy,0)
pml_layers = [mp.PML(thickness=dpml,direction=mp.X)]

wvl_min = 0.4           # min wavelength
wvl_max = 0.6           # max wavelength
fmin = 1/wvl_max        # min frequency
fmax = 1/wvl_min        # max frequency
fcen = 0.5*(fmin+fmax)  # center frequency
df = fmax-fmin          # frequency width
nfreq = 21
frequency = np.linspace(fmin,fmax,nfreq)
frequency_num = 0

src_pt = mp.Vector3(-0.5*sx+dpml+0.5*dsub,0,0)

sources = [mp.Source(mp.GaussianSource(fcen, fwidth=df),
                     component=mp.Ez,
                     center=src_pt,
                     size=mp.Vector3(0,sy,0))]

k_point = mp.Vector3(0,0,0)

glass = mp.Medium(index=1.5)

# symmetries=[mp.Mirror(mp.Y)]

sim = mp.Simulation(resolution=resolution,
                    cell_size=cell_size,
                    boundary_layers=pml_layers,
                    k_point=k_point,
                    default_material=glass,
                    sources=sources,
                    # symmetries=symmetries
                    )


mon_pt = mp.Vector3(0.5*sx-dpml-0.5*dpad,0,0)
flux_mon = sim.add_flux(fcen,
                        df,
                        nfreq,
                        mp.FluxRegion(center=mon_pt, size=mp.Vector3(0,sy,0)))

dft_obj_Transmission_Normalization = sim.add_dft_fields([mp.Ez, mp.Hy, mp.Hx], frequency, center=mon_pt, size=mp.Vector3(0,sy,0))



sim.run(until_after_sources=mp.stop_when_fields_decayed(50, mp.Ez, mon_pt, 1e-9))

input_flux = mp.get_fluxes(flux_mon)



Ez_norm = sim.get_dft_array(dft_obj_Transmission_Normalization, mp.Ez, frequency_num)
Hx_norm = sim.get_dft_array(dft_obj_Transmission_Normalization, mp.Hx, frequency_num)
Hy_norm = sim.get_dft_array(dft_obj_Transmission_Normalization, mp.Hy, frequency_num)

sim.reset_meep()

geometry = [mp.Block(material=glass,
                     size=mp.Vector3(dpml+dsub,mp.inf,mp.inf),
                     center=mp.Vector3(-0.5*sx+0.5*(dpml+dsub),0,0)),
            mp.Block(material=glass,
                      size=mp.Vector3(gh,gdc*gp,mp.inf),
                      center=mp.Vector3(-0.5*sx+dpml+dsub+0.5*gh,0,0))
        ]

sim = mp.Simulation(resolution=resolution,
                    cell_size=cell_size,
                    boundary_layers=pml_layers,
                    geometry=geometry,
                    k_point=k_point,
                    sources=sources,
                    # symmetries=symmetries
                    )

mode_mon = sim.add_flux(fcen,
                        df,
                        nfreq,
                        mp.FluxRegion(center=mon_pt, size=mp.Vector3(0,sy,0)))

dft_obj_Transmission = sim.add_dft_fields([mp.Ez, mp.Hx, mp.Hy], frequency, center=mon_pt, size=mp.Vector3(0,sy,0))

sim.run(until_after_sources=mp.stop_when_fields_decayed(50, mp.Ez, mon_pt, 1e-9))

Ez_tran = sim.get_dft_array(dft_obj_Transmission, mp.Ez, frequency_num)
Hx_tran = sim.get_dft_array(dft_obj_Transmission, mp.Hx, frequency_num)
Hy_tran = sim.get_dft_array(dft_obj_Transmission, mp.Hy, frequency_num)

freqs = mp.get_eigenmode_freqs(mode_mon)

nmode = 10
res = sim.get_eigenmode_coefficients(mode_mon, range(1,nmode+1), eig_parity=mp.ODD_Z+mp.EVEN_Y)
coeffs = res.alpha
kdom = res.kdom

mode_wvl = []
mode_angle = []
mode_tran = []

for nm in range(nmode):
  for nf in range(nfreq):
    mode_wvl.append(1/freqs[nf])
    mode_angle.append(math.degrees(math.acos(kdom[nm*nfreq+nf].x/freqs[nf])))
    tran = abs(coeffs[nm,nf,0])**2/input_flux[nf]
    mode_tran.append(0.5*tran if nm != 0 else tran)
    print("grating{}:, {:.5f}, {:.2f}, {:.8f}".format(nm,mode_wvl[-1],mode_angle[-1],mode_tran[-1]))

k=frequency[frequency_num]
f1, FEz = fourierTransform(Ez_tran, k, resolution, sy)
f2, FHx = fourierTransform(Hx_tran, k, resolution, sy)
f3, FHy = fourierTransform(Hy_tran, k, resolution, sy)

f4, FEz_n = fourierTransform(Ez_norm, k, resolution, sy)
f5, FHx_n = fourierTransform(Hx_norm, k, resolution, sy)
f6, FHy_n = fourierTransform(Hy_norm, k, resolution, sy)

F_n = FEz_n*FHy_n
F_t = FEz*FHy/F_n[0]
# grating0:, 0.60000, 0.00, 0.06741467
# grating0:, 0.58537, 0.00, 0.05221034
# grating0:, 0.57143, 0.00, 0.03901841
# grating0:, 0.55814, 0.00, 0.02755083
# grating0:, 0.54545, 0.00, 0.01808692
# grating0:, 0.53333, 0.00, 0.01064760
# grating0:, 0.52174, 0.00, 0.00523874
# grating0:, 0.51064, 0.00, 0.00186864
# grating0:, 0.50000, 0.00, 0.00059813
# grating0:, 0.48980, 0.00, 0.00144386
# grating0:, 0.48000, 0.00, 0.00441803
# grating0:, 0.47059, 0.00, 0.00940877
# grating0:, 0.46154, 0.00, 0.01650931
# grating0:, 0.45283, 0.00, 0.02570566
# grating0:, 0.44444, 0.00, 0.03689741
# grating0:, 0.43636, 0.00, 0.05005715
# grating0:, 0.42857, 0.00, 0.06510668
# grating0:, 0.42105, 0.00, 0.08201170
# grating0:, 0.41379, 0.00, 0.10060183
# grating0:, 0.40678, 0.00, 0.12106467
# grating0:, 0.40000, 0.00, 0.14319845
# grating1:, 0.60000, 3.44, 0.36468761
# grating1:, 0.58537, 3.36, 0.37060298
# grating1:, 0.57143, 3.28, 0.37575803
# grating1:, 0.55814, 3.20, 0.38007455
# grating1:, 0.54545, 3.13, 0.38363607
# grating1:, 0.53333, 3.06, 0.38631464
# grating1:, 0.52174, 2.99, 0.38811446
# grating1:, 0.51064, 2.93, 0.38910373
# grating1:, 0.50000, 2.87, 0.38922253
# grating1:, 0.48980, 2.81, 0.38841721
# grating1:, 0.48000, 2.75, 0.38676287
# grating1:, 0.47059, 2.70, 0.38428402
# grating1:, 0.46154, 2.65, 0.38088987
# grating1:, 0.45283, 2.60, 0.37665523
# grating1:, 0.44444, 2.55, 0.37161035
# grating1:, 0.43636, 2.50, 0.36573286
# grating1:, 0.42857, 2.46, 0.35906271
# grating1:, 0.42105, 2.41, 0.35164694
# grating1:, 0.41379, 2.37, 0.34348811
# grating1:, 0.40678, 2.33, 0.33464025
# grating1:, 0.40000, 2.29, 0.32513147
# grating2:, 0.60000, 6.89, 0.00059786
# grating2:, 0.58537, 6.72, 0.00061367
# grating2:, 0.57143, 6.56, 0.00065895
# grating2:, 0.55814, 6.41, 0.00069689
# grating2:, 0.54545, 6.26, 0.00072544
# grating2:, 0.53333, 6.12, 0.00076112
# grating2:, 0.52174, 5.99, 0.00080390
# grating2:, 0.51064, 5.86, 0.00083266
# grating2:, 0.50000, 5.74, 0.00085779
# grating2:, 0.48980, 5.62, 0.00091153
# grating2:, 0.48000, 5.51, 0.00093518
# grating2:, 0.47059, 5.40, 0.00095500
# grating2:, 0.46154, 5.30, 0.00100513
# grating2:, 0.45283, 5.20, 0.00102981
# grating2:, 0.44444, 5.10, 0.00105953
# grating2:, 0.43636, 5.01, 0.00108343
# grating2:, 0.42857, 4.92, 0.00111766
# grating2:, 0.42105, 4.83, 0.00113894
# grating2:, 0.41379, 4.75, 0.00117430
# grating2:, 0.40678, 4.67, 0.00120529
# grating2:, 0.40000, 4.59, 0.00121035
# grating3:, 0.60000, 10.37, 0.04036546
# grating3:, 0.58537, 10.11, 0.04101988
# grating3:, 0.57143, 9.87, 0.04157603
# grating3:, 0.55814, 9.64, 0.04199779
# grating3:, 0.54545, 9.42, 0.04240147
# grating3:, 0.53333, 9.21, 0.04267235
# grating3:, 0.52174, 9.01, 0.04282021
# grating3:, 0.51064, 8.81, 0.04292772
# grating3:, 0.50000, 8.63, 0.04294297
# grating3:, 0.48980, 8.45, 0.04281109
# grating3:, 0.48000, 8.28, 0.04260767
# grating3:, 0.47059, 8.12, 0.04235681
# grating3:, 0.46154, 7.96, 0.04195710
# grating3:, 0.45283, 7.81, 0.04147305
# grating3:, 0.44444, 7.66, 0.04092399
# grating3:, 0.43636, 7.52, 0.04026285
# grating3:, 0.42857, 7.39, 0.03951334
# grating3:, 0.42105, 7.26, 0.03869927
# grating3:, 0.41379, 7.13, 0.03778854
# grating3:, 0.40678, 7.01, 0.03679520
# grating3:, 0.40000, 6.89, 0.03574929
# grating4:, 0.60000, 13.89, 0.00061846
# grating4:, 0.58537, 13.54, 0.00063266
# grating4:, 0.57143, 13.21, 0.00067638
# grating4:, 0.55814, 12.90, 0.00071451
# grating4:, 0.54545, 12.60, 0.00074279
# grating4:, 0.53333, 12.32, 0.00077612
# grating4:, 0.52174, 12.05, 0.00081953
# grating4:, 0.51064, 11.79, 0.00084914
# grating4:, 0.50000, 11.54, 0.00087215
# grating4:, 0.48980, 11.30, 0.00092624
# grating4:, 0.48000, 11.07, 0.00095019
# grating4:, 0.47059, 10.85, 0.00097007
# grating4:, 0.46154, 10.64, 0.00101967
# grating4:, 0.45283, 10.44, 0.00104462
# grating4:, 0.44444, 10.24, 0.00107409
# grating4:, 0.43636, 10.05, 0.00109661
# grating4:, 0.42857, 9.87, 0.00113107
# grating4:, 0.42105, 9.70, 0.00115167
# grating4:, 0.41379, 9.53, 0.00118623
# grating4:, 0.40678, 9.36, 0.00121687
# grating4:, 0.40000, 9.21, 0.00122074
# grating5:, 0.60000, 17.46, 0.01437149
# grating5:, 0.58537, 17.02, 0.01461171
# grating5:, 0.57143, 16.60, 0.01480522
# grating5:, 0.55814, 16.20, 0.01491358
# grating5:, 0.54545, 15.83, 0.01506972
# grating5:, 0.53333, 15.47, 0.01515232
# grating5:, 0.52174, 15.12, 0.01516675
# grating5:, 0.51064, 14.79, 0.01520425
# grating5:, 0.50000, 14.48, 0.01521641
# grating5:, 0.48980, 14.18, 0.01513766
# grating5:, 0.48000, 13.89, 0.01504886
# grating5:, 0.47059, 13.61, 0.01497912
# grating5:, 0.46154, 13.34, 0.01482033
# grating5:, 0.45283, 13.09, 0.01463663
# grating5:, 0.44444, 12.84, 0.01444799
# grating5:, 0.43636, 12.60, 0.01420604
# grating5:, 0.42857, 12.37, 0.01393156
# grating5:, 0.42105, 12.15, 0.01364781
# grating5:, 0.41379, 11.94, 0.01331908
# grating5:, 0.40678, 11.74, 0.01295491
# grating5:, 0.40000, 11.54, 0.01258797
# grating6:, 0.60000, 21.10, 0.00065425
# grating6:, 0.58537, 20.56, 0.00066573
# grating6:, 0.57143, 20.05, 0.00070601
# grating6:, 0.55814, 19.57, 0.00074433
# grating6:, 0.54545, 19.10, 0.00077231
# grating6:, 0.53333, 18.66, 0.00080079
# grating6:, 0.52174, 18.24, 0.00084503
# grating6:, 0.51064, 17.84, 0.00087631
# grating6:, 0.50000, 17.46, 0.00089537
# grating6:, 0.48980, 17.09, 0.00094954
# grating6:, 0.48000, 16.74, 0.00097404
# grating6:, 0.47059, 16.40, 0.00099419
# grating6:, 0.46154, 16.08, 0.00104261
# grating6:, 0.45283, 15.77, 0.00106808
# grating6:, 0.44444, 15.47, 0.00109720
# grating6:, 0.43636, 15.18, 0.00111729
# grating6:, 0.42857, 14.90, 0.00115229
# grating6:, 0.42105, 14.63, 0.00117178
# grating6:, 0.41379, 14.38, 0.00120487
# grating6:, 0.40678, 14.13, 0.00123491
# grating6:, 0.40000, 13.89, 0.00123673
# grating7:, 0.60000, 24.83, 0.00714095
# grating7:, 0.58537, 24.19, 0.00727685
# grating7:, 0.57143, 23.58, 0.00737938
# grating7:, 0.55814, 23.00, 0.00739902
# grating7:, 0.54545, 22.45, 0.00749410
# grating7:, 0.53333, 21.92, 0.00753240
# grating7:, 0.52174, 21.42, 0.00750909
# grating7:, 0.51064, 20.94, 0.00752775
# grating7:, 0.50000, 20.49, 0.00754674
# grating7:, 0.48980, 20.05, 0.00748244
# grating7:, 0.48000, 19.63, 0.00742308
# grating7:, 0.47059, 19.23, 0.00740700
# grating7:, 0.46154, 18.85, 0.00731665
# grating7:, 0.45283, 18.48, 0.00721609
# grating7:, 0.44444, 18.13, 0.00712786
# grating7:, 0.43636, 17.79, 0.00700390
# grating7:, 0.42857, 17.46, 0.00686185
# grating7:, 0.42105, 17.14, 0.00672688
# grating7:, 0.41379, 16.84, 0.00656145
# grating7:, 0.40678, 16.54, 0.00637149
# grating7:, 0.40000, 16.26, 0.00619386
# grating8:, 0.60000, 28.69, 0.00070716
# grating8:, 0.58537, 27.92, 0.00071510
# grating8:, 0.57143, 27.20, 0.00074859
# grating8:, 0.55814, 26.52, 0.00078682
# grating8:, 0.54545, 25.87, 0.00081529
# grating8:, 0.53333, 25.26, 0.00083476
# grating8:, 0.52174, 24.67, 0.00087936
# grating8:, 0.51064, 24.11, 0.00091377
# grating8:, 0.50000, 23.58, 0.00092644
# grating8:, 0.48980, 23.07, 0.00097941
# grating8:, 0.48000, 22.58, 0.00100475
# grating8:, 0.47059, 22.12, 0.00102583
# grating8:, 0.46154, 21.67, 0.00107186
# grating8:, 0.45283, 21.24, 0.00109821
# grating8:, 0.44444, 20.83, 0.00112693
# grating8:, 0.43636, 20.43, 0.00114341
# grating8:, 0.42857, 20.05, 0.00117956
# grating8:, 0.42105, 19.68, 0.00119766
# grating8:, 0.41379, 19.33, 0.00122842
# grating8:, 0.40678, 18.99, 0.00125775
# grating8:, 0.40000, 18.66, 0.00125697
# grating9:, 0.60000, 32.68, 0.00407480
# grating9:, 0.58537, 31.79, 0.00418048
# grating9:, 0.57143, 30.95, 0.00425997
# grating9:, 0.55814, 30.15, 0.00424049
# grating9:, 0.54545, 29.40, 0.00431855
# grating9:, 0.53333, 28.69, 0.00435133
# grating9:, 0.52174, 28.01, 0.00431322
# grating9:, 0.51064, 27.36, 0.00432395
# grating9:, 0.50000, 26.74, 0.00435611
# grating9:, 0.48980, 26.16, 0.00429965
# grating9:, 0.48000, 25.59, 0.00424973
# grating9:, 0.47059, 25.06, 0.00425990
# grating9:, 0.46154, 24.54, 0.00420080
# grating9:, 0.45283, 24.05, 0.00413497
# grating9:, 0.44444, 23.58, 0.00408897
# grating9:, 0.43636, 23.12, 0.00401651
# grating9:, 0.42857, 22.69, 0.00393029
# grating9:, 0.42105, 22.27, 0.00385941
# grating9:, 0.41379, 21.86, 0.00376490
# grating9:, 0.40678, 21.48, 0.00364729
# grating9:, 0.40000, 21.10, 0.00354967