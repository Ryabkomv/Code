import numpy as np
import matplotlib.pyplot as plt
from scipy.optimize import minimize
from scipy.optimize import Bounds

k0 = np.array([0.96, 0.68, 0.25])
# ro = (1-k)**0.5

band =0.45

alpha = 0
nu = np.linspace(-1, 1,1000)

perform_optimization = True

def target(ro, alpha=0):
    
    gamma = 10**(alpha/20)

    z=gamma*np.exp(1j*2*np.pi*nu)
    
    Hbar = 0.5*( (ro[0]+z**(-2))*(ro[2]+z**(-2))/(1+ro[0]*z**(-2))/(1+ro[2]*z**(-2)) - (ro[1]+z**(-2))/(1+ro[1]*z**(-2))/z)
    
    Hcross= -1j*0.5*( (ro[0]+z**(-2))*(ro[2]+z**(-2))/(1+ro[0]*z**(-2))/(1+ro[2]*z**(-2)) + (ro[1]+z**(-2))/(1+ro[1]*z**(-2))/z)
    return Hcross, Hbar

def tar(k):
    ro = (1-k)**0.5
    nu = np.linspace(-band/2, band/2,1000)
    gamma = 10**(alpha/20)

    z=gamma*np.exp(1j*2*np.pi*nu)
    
    
    Hbar = 0.5*( (ro[0]+z**(-2))*(ro[2]+z**(-2))/(1+ro[0]*z**(-2))/(1+ro[2]*z**(-2)) - (ro[1]+z**(-2))/(1+ro[1]*z**(-2))/z)
    
    Hcross= -1j*0.5*( (ro[0]+z**(-2))*(ro[2]+z**(-2))/(1+ro[0]*z**(-2))/(1+ro[2]*z**(-2)) + (ro[1]+z**(-2))/(1+ro[1]*z**(-2))/z)
    
    return -np.max(10*np.log(abs(Hcross)**2)/np.log(10)) +  np.max(10*np.log(abs(Hbar)**2)/np.log(10))

k_solution = k0
if (perform_optimization):
    k_solution = np.random.random(3)
    solution = 0
    bounds = [(0,1), (0,1), (0,1)]
    for i in range(0,10):
        res = minimize(tar, k0, method = 'nelder-mead', options={'xtol':1e-8, 'disp':True}, bounds=bounds)
        if (res.fun<solution):
            solution = res.fun
            k_solution = res.x
            
        k0 = np.random.random(3)
    
    print(solution)
    print(k_solution)

Hcross, Hbar = target((1-k_solution)**0.5)
# Hcross1, Hbar1 = target((1-k_solution)**0.5, 1)
# Hcross2, Hbar2 = target((1-k_solution)**0.5, 2)
plt.figure()
plt.plot(nu, 10*np.log(abs(Hcross)**2)/np.log(10),'C1')
plt.plot(nu, 10*np.log(abs(Hbar)**2)/np.log(10),'C2')
# plt.plot(nu, 10*np.log(abs(Hcross1)**2)/np.log(10),'C2')
# plt.plot(nu, 10*np.log(abs(Hcross2)**2)/np.log(10),'C3')
plt.ylim(-50,1)
plt.title('Cross and Bar ports signal. \n Loss=' + str(alpha) + ' dB. \n Coupling coefficiens k1, k2, k3 = ' + str(np.round(k_solution,2)))
plt.xlabel('Frequency/FSR')
plt.ylabel('Transmission, dB')
# plt.legend(['No ring loss', 'Ring loss = 2 dB', 'Ring loss = 4 dB'], loc = 1)
plt.legend(['Hcross', 'Hbar'], loc = 1)
plt.show