'''
This file is for near-to-far field projection.

'''

#%% IMPORTS & DATA LOADING

import logging
import numpy as np
import matplotlib.pyplot as plt
from concurrent.futures import ProcessPoolExecutor

from primitives import *
from params import *

# where to write output files
script_path = os.path.dirname(os.path.realpath(__file__))
save_path = os.path.join(script_path, save_dir)
if not os.path.isdir(save_path): os.makedirs(save_path) # create dir if not exists

# logger params
logging.basicConfig(
    level=logging.INFO,
    format='[%(asctime)s] [%(levelname)-5.5s] %(message)s'
)

# data loading

Rc_opt, r1_opt, r2_opt, r3_opt, RMSE_opt = np.loadtxt(os.path.join(save_path,'opt_hist.txt'),
    delimiter='\t', unpack=True)

rs_rcwa_opt = np.vstack([r1_opt,r2_opt,r3_opt]).T

phase_opt_unique = np.loadtxt(os.path.join(save_path,'opt_phases.txt'), skiprows=2, delimiter='\t')


#%% CALCULATION

# target phase of a metalens

xc_lens = yc_lens = np.arange(0.5*dr, R, dr)        # centers of meta-atoms along x- and y-axes
xc_lens = np.concatenate([-xc_lens[::-1], xc_lens]) # mirroring x-axis
yc_lens = np.concatenate([-yc_lens[::-1], yc_lens]) # mirroring y-axis
Nx_lens, Ny_lens = len(xc_lens), len(yc_lens)

XC_lens, YC_lens = np.meshgrid(xc_lens, yc_lens)
RC_lens = np.sqrt(XC_lens**2+YC_lens**2)  # distances from (0,0) to center of each meta-atom
RC_lens[RC_lens>R] = np.nan               # NaN if outside R

k_range = 2 * np.pi * nAir / wl_range_inv                     # wavenumbers
dF_range = np.sqrt(RC_lens**2 + F**2) - np.sqrt(R0**2 + F**2) # distance from each meta-atom to focal point
phase_lens = np.array([-k*dF_range for k in k_range])         # target phase distribution for each wavenumber
phase_lens_wrap = np.angle(np.exp(1j*phase_lens))             # "wrapped" target phase distribution

for i, wl in enumerate(wl_range_inv):
    
    logging.info(f'Target/optimized phase distributions plotting: wl = {wl:.2f} um.')

    ##### filling phase response of a metalens based on optimized values
     
    phase_opt = np.zeros(RC_lens.shape)
    phase_opt[np.isnan(RC_lens)] = np.nan

    for Rc_idx, Rc in np.ndenumerate(RC_lens):
        # filling only if not NaN
        if ~np.isnan(Rc):
            _, Rc_opt_idx = find_nearest(Rc_opt, Rc)
            phase_opt[Rc_idx] = phase_opt_unique[Rc_opt_idx,i]

    ##### plotting target and calculated phase distributions
    
    fig, axs = plt.subplots(1,2,figsize=(7,2.5))
    fig.suptitle(f'wavelength = {wl}um')
    
    c0 = axs[0].pcolormesh(xc_lens, yc_lens, phase_lens_wrap[i])# / np.pi, vmin=-1, vmax=1)
    cbar0 = fig.colorbar(c0, ax=axs[0])
    cbar0.set_label('$\phi_{min}} / \pi$')
    axs[0].set_title('target phase')
    axs[0].set_xlabel('xc (μm)')
    axs[0].set_ylabel('yc (μm)')
    axs[0].set_aspect('equal')

    c1 = axs[1].pcolormesh(xc_lens, yc_lens, phase_opt)# / np.pi, vmin=-1, vmax=1)
    cbar1 = fig.colorbar(c1, ax=axs[1])
    cbar1.set_label('$\phi_{min}$')
    axs[1].set_title('inverse design phase')
    axs[1].set_xlabel('xc (μm)')
    axs[1].set_ylabel('yc (μm)')
    axs[1].set_aspect('equal')

    fig.tight_layout()
    fig.savefig(os.path.join(save_path,f'phase_target_optimized_wl={wl:.2f}um.png'),dpi=fig_dpi)
    
    ##### near-to-far fiel projection
    
    # input amplitudes for HF approximation
    amp0 = np.ones((Nx_lens,Ny_lens),dtype=complex)
    amp0 = np.exp(1j*phase_opt)
    amp0[np.isnan(amp0)] = 0

    # z = F
    logging.info(f'Near-to-far field projection: wl = {wl:.2f} um, XY plane, Z=F.')

    amps_xy = hf_approx_xy(k_range[i], xc_lens, yc_lens, F, amp0)
    int_xy = np.abs(amps_xy)**2 # intensity
    int_xy /= np.max(int_xy)
    
    # z = z_range
    logging.info(f'Near-to-far field projection: wl = {wl:.2f} um, YZ plane.')
    
    z_range = np.linspace(1500, 4500, 41)
    # parallel processing to acceletar extraction
    with ProcessPoolExecutor() as executor:
        futures = {z: executor.submit(hf_approx_xy, k_range[i], xc_lens, yc_lens, z, amp0) for z in z_range}
        amps_zxy = np.array([futures[z].result() for z in z_range])
    
    int_zxy = np.abs(amps_zxy[:,Nx_lens//2,:])**2 # intensity
    int_zxy /= np.max(int_zxy)

    # plotting
    fig, axs = plt.subplots(1,2, figsize=(7,2.5))
    fig.suptitle(f'wavelength = {wl}um')

    p0 = axs[0].pcolormesh(xc_lens, yc_lens, int_xy)
    cbar1 = fig.colorbar(p0, ax=axs[0])
    axs[0].set_title(f'intensity: XY, Z = {F/1000} mm')
    # axs[0].set_aspect('equal')
    axs[0].set_xlabel('X (μm)')
    axs[0].set_ylabel('Y (μm)')

    p1 = axs[1].pcolormesh(yc_lens, z_range, int_zxy)
    cbar1 = fig.colorbar(p1, ax=axs[1])
    axs[1].axhline(y=F, ls='--', lw=1, c='white')
    axs[1].set_title('intensity: YZ')
    # axs[1].set_aspect('equal')
    axs[1].set_xlabel('Y (μm)')
    axs[1].set_ylabel('Z (μm)')

    fig.tight_layout()
    fig.savefig(os.path.join(save_path,f'near_to_far_wl={wl:.2f}um.png'), dpi=fig_dpi)
    

# %%
