'''
This file contains basic functions.

'''

import sys
import numpy as np
import grcwa
import matplotlib.pyplot as plt

from params import *

def find_nearest(x: np.ndarray,
                 val: float) -> tuple:
    '''
    Returns an array element nearest to the given at input, as well as its index.
    '''
    
    x = np.asarray(x)
    idx = np.argmin(np.abs(x-val))
    return x[idx], idx

def ndix_unique(x: np.ndarray) -> tuple:
    '''
    Returns an unique values containing in N-dimensional array x and their indices.
    ----------
    x: np.array
       Array with arbitrary dimensions
    Returns
    -------
    - 1D-array of sorted unique values
    - Array of arrays. Each array contains the indices where a given value in x is found.
    
    Source:
    https://stackoverflow.com/questions/54734545/indices-of-unique-values-in-n-dimensional-array
    '''
    
    x_flat = x.ravel()
    ix_flat = np.argsort(x_flat)
    u, ix_u = np.unique(x_flat[ix_flat], return_index=True)
    ix_ndim = np.unravel_index(ix_flat, x.shape)
    ix_ndim = np.c_[ix_ndim] if x.ndim > 1 else ix_flat
    return u, np.split(ix_ndim, ix_u[1:])

def update_last_line(new_str: str):
    '''
    Updates the last string in console output.
    '''
    sys.stdout.write('\r')
    sys.stdout.write(new_str)
    sys.stdout.flush()

def draw_progress_bar(progress: float,
                      bar_len: int = 20) -> None:
    '''
    Draws simple updatable progress bar. Takes values in the range of [0,1].
    Based on:
    https://stackoverflow.com/questions/3002085/how-to-print-out-status-bar-and-percentage
    '''
    
    assert  0 <= progress <= 1, 'Incorrect input value. Should be in the range of [0,1].'
    update_last_line('TASK PROGRESS: [{:<{}}] {:.2%}'.format('='*int(bar_len*progress), bar_len, progress))
    if progress == 1: print('\n')

def circle_mask(X: np.ndarray,
                Y: np.ndarray,
                R: float,
                x0: float = 0.,
                y0: float = 0.):
    '''
    Returns binary mask for a cylinder with R radius on a defined (X,Y) grid.
    '''
    
    return (X-x0)**2 + (Y-y0)**2 <= R**2

def cyl_pillar_rcwa(rs: np.ndarray,
                    thicks: np.ndarray,
                    wl: float,
                    planewave_params: dict = P_wave,
                    theta: float = theta_rad,
                    phi: float = phi_rad,
                    return_amps_only: bool = True,
                    plot_masks: bool = False) -> tuple:
    '''
    Basic model of meta-atoms consisting on cylindrical pillars. Returns complex amplitudes
    and rerlection/transmission coefficients.
    '''
    
    assert len(rs) == len(thicks), 'Lengths of rs and thicks vectors should be equal.'
    rs = sorted(rs, reverse=True)     # sorting radii of pillars 
    Nl = len(rs)                      # number of patterned layers
    L1, L2 = [a_rcwa,0.], [0.,a_rcwa] # lattice vectors for RCWA
    freq = 1. / wl + 1j*1e-20         # radiation frequency; small imaginary part is to avoid singular matrix
    
    obj = grcwa.obj(nG_max, L1, L2, freq, theta, phi, verbose=0)
    obj.Add_LayerUniform(0, epsSi)                 # Si Substrate, layer no. 0
    for thick in thicks:
        obj.Add_LayerGrid(thick, Nx_rcwa, Ny_rcwa) # Cyl. pillars, layer no. 1 to Nl
    obj.Add_LayerUniform(0, epsAir)                # Air,          layer no. Nl+2
    obj.Init_Setup(Gmethod=0)                      # Gmethod=0 for circular, 1 for rectangular

    # grid for x- and y-axes
    x_rcwa = np.linspace(-0.5*a_rcwa, 0.5*a_rcwa, Nx_rcwa)  # grid for x- and y-axes
    y_rcwa = np.linspace(-0.5*a_rcwa, 0.5*a_rcwa, Ny_rcwa)
    X_rcwa, Y_rcwa = np.meshgrid(x_rcwa, y_rcwa)
        
    # epsilon patterning of non-uniform layers
    epgrids = []
    for r in rs:
        epgrid = np.ones((Nx_rcwa,Ny_rcwa),dtype=float)*epsAir # Air is surrounding medium
        epgrid[circle_mask(X_rcwa,Y_rcwa,r)] = epsSi           # Si is pillar material
        epgrids.append(epgrid.flatten())                       # all eps should be flattened and concatenate
    obj.GridLayer_geteps(np.concatenate(epgrids))
    
    obj.MakeExcitationPlanewave(**planewave_params)
    
    # debug info: epsilon plotting
    if plot_masks:
        
        fig, axs = plt.subplots(1,Nl, figsize=(3*Nl,3))
        fig.suptitle(f'rs = ' + np.array2string(np.array(rs)))
        for ax, epgrid in zip(axs, epgrids):
            ax.pcolormesh(X_rcwa, Y_rcwa, epgrid.reshape(Nx_rcwa,Ny_rcwa))
            ax.set_aspect('equal')
            ax.set_xlabel('x (μm)')
            ax.set_ylabel('y (μm)')
        fig.tight_layout()
        # fig.savefig('rcwa_patterned_layers.png', dpi=fig_dpi)
    
    # 0-th diffraction order amplitudes
    amps_fwd, _ = obj.GetAmplitudes(which_layer=Nl+1, z_offset=0)
    amp_s0 = amps_fwd[0]       # S-polarization
    amp_p0 = amps_fwd[obj.nG]  # P-polarization
    
    if return_amps_only:
        return amp_s0, amp_p0 # faster
    else:
        refl, tran = obj.RT_Solve(normalize=1) # solve for R and T, slower
        return amp_s0, amp_p0, refl, tran
    
def phase_resp_rcwa(rs: np.ndarray,
                    thicks: np.ndarray,
                    wl_range_inv: np.ndarray,
                    planewave_params: dict = P_wave,
                    unwrap_phase: bool = False,
                    plot_amp_phase: bool = False) -> tuple:
    '''
    Returns phase response of meta-atom depending on input params.
    '''

    amp_s0 = np.zeros(len(wl_range_inv), dtype=complex)
    amp_p0 = np.zeros(len(wl_range_inv), dtype=complex)

    for i, wl in enumerate(wl_range_inv):
        amp_s0[i], amp_p0[i] = cyl_pillar_rcwa(rs, thicks, wl, planewave_params, return_amps_only=True)
    
    abs_amp_s0_range = np.abs(amp_s0)
    abs_amp_p0_range = np.abs(amp_p0)
    phase_s0_range = np.unwrap(np.angle(amp_s0)) if unwrap_phase else np.angle(amp_s0)
    phase_p0_range = np.unwrap(np.angle(amp_p0)) if unwrap_phase else np.angle(amp_p0)

    if plot_amp_phase:
        
        fig, axs = plt.subplots(1,2,figsize=(8,3))
        fig.suptitle(f'rs = ' + np.array2string(np.array(rs)))
        axs[0].plot(wl_range_inv, abs_amp_s0_range, 's-', fillstyle='none', label='s-pol.')
        axs[0].plot(wl_range_inv, abs_amp_p0_range, 'o-', fillstyle='none', label='p-pol.')
        axs[1].plot(wl_range_inv, phase_s0_range,   's-', fillstyle='none', label='s-pol.')
        axs[1].plot(wl_range_inv, phase_p0_range,   'o-', fillstyle='none', label='p-pol.')
        [ax.set_xlabel('wavelength (μm)') for ax in axs]
        axs[0].set_ylabel('abs. amplitude')
        axs[1].set_ylabel('unwrapped phase')
        [ax.legend() for ax in axs]
        fig.tight_layout()
        # fig.savefig('rcwa_phase_response.png', dpi=fig_dpi)
    
    return phase_s0_range, phase_p0_range

def hf_approx_xy(k: float,
                 x_range: np.ndarray,
                 y_range: np.ndarray,
                 z: np.ndarray,
                 amp0: complex) -> np.ndarray:
    '''
    Returns complex amplitudes for wave with wavenumber k=2πn/λ and init. amplitudes amp0 at defined distance z.
    '''

    Nx, Ny = len(x_range), len(y_range)
    assert amp0.shape == (Nx, Ny), f'Incorrect dimenstions. Shape of amp0 should be len(x_range), len(y_range).'
    
    # mutual distances between meta-atoms along x- and y-axes
    dx_ij = np.array([np.concatenate([x_range[i:0:-1], x_range[0:Nx-i]]) - x_range.min() for i in range(Nx)])
    dy_ij = np.array([np.concatenate([y_range[i:0:-1], y_range[0:Nx-i]]) - y_range.min() for i in range(Nx)])
    
    amps = np.zeros((Nx,Ny), dtype=complex)
    
    for nx, ny in np.ndindex(Nx,Ny):
        Dx_ij, Dy_ij = np.meshgrid(dx_ij[nx], dy_ij[ny])
        R_ij = np.sqrt(Dx_ij**2 + Dy_ij**2 + z**2)
        amps[nx,ny] = np.sum(amp0 * np.exp(1j*k*R_ij))
        
    return amps
