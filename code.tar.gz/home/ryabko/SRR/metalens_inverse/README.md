# Inverse desing of metalens

This repository contains a set of scripts for inverse design of a metalens. First, metalens with defined parameters is descritized of rectangular grid, then unique meta-atoms are optimized to get target phase response in the wavelength range. Finally, we project complex amplitudes of optimized meta-atoms to focal point to check the performance of the metalens. Fig. 1 presents the logic of optimizer. 

<img src='data/scheme.png'>

*Fig. 1. [LEFT] Scheme of optimization. [RIGHT] Basic structure of a meta-atom: $r_{min}$ = 0.5 μm, $r_{max}$ = 2.5 μm, $h$ = 6 μm for each cylinder, total height $H$ = 18 μm.*


## Initial thoughts

* In all scripts basic units are μm and radians.
* A basic meta-atom consists of three stacked cylinders with radii *$r_1,r_2,r_3$* in the range of [0.5,2.5] μm; total height $H$=18 μm (6 μm each); pitch $dr$ = 6 μm. It can be replaced by meta-atom with another geometry.
* Rigorous coupled-wave analysis (RCWA) is used as a basic solver for extracting phase response of a meta-atom, however alternatives are possible, such as FDTD (e.g. MEEP), or eigenmode propagation method (e.g. MBP);
* Each unique meta-atom in defined metalens to be optimized; 
* The optimizer tries to find radii of cylinders $r_1,r_2,r_3$ that give phase response similar to the target; 
* The optimizer uses root-mean-square error (RMSE) as an objective function.
* The optimizer uses gradient-free algorithm COBYLA, or Constrained Optimization BY Linear Approximations. It's quite difficult to usrealize automatic differentiation in RCWA model with patterned layers, and so to construct fast gradient-based objective function;
* Actual code works work metalens with $F$ = 3 mm, $D$ = 0.77 mm, but can be easily adapted for an another case. Note, that phase dispersion of a metalens should fit phase dispersion space of meta-atoms.

## Local environment setup
```
$ conda create -n rcwa
$ conda activate rcwa
$ conda update conda --all
$ conda install -c intel intelpython numpy scipy matplotlib
$ conda install -c conda-forge nlopt autograd
$ pip install grcwa
```

MKL (Math Kernel Library) is low-level library needed to accelerate NumPy. Note, that `grcwa` package (https://github.com/weiliangjinca/grcwa) shoul be installed using `pip`.

## Running scrips locally
```
$ conda activate rcwa
$ cd metalens_inverse
$ python ./optimizer.py
$ python ./postproc.py
```

## Performance
With basic design ($F$ = 3 mm, $D$ = 0.77 mm, meta-atom pitch $dr$ = 6 μm, meta-atom height (3 cyl.) $H$ = 3$h$ = 18 μm) optimization took about 16 hours in my case. I ran the code on local server where 56 cores are available, but MKL used about half of them. Further acceleration and parallelization is possible.

## How to run on supercomputer (!!! should be verified one more time):

I successfully run the code on https://supercom.samsung.net/sc/

0. Miniconda (https://docs.conda.io/en/main/miniconda.html) should be installed both in local and remote computers. `x86_64` architecture is essential.


1. Create local environment under Linux of WSL (Windows) as proposed above, then install another one package:

```
$ conda install -c conda-forge conda-pack
```

2. Compress local environment and transfer it to the supercomputer with `scp`. Use your actual user name and home directory (e.g. it’s `/home/sr5/alexey.wolf` in my case):

```
$ conda pack -n rcwa -o rcwa.tar.gz
$ scp rcwa.tar.gz alexey.wolf@202.20.183.100:/home/sr5/alexey.wolf
```

After that you will find archive in the supercomputer's home foldel.

3. Connect to the supercomputer, decompress archive and update local paths with `conda-unpack`:

```
$ ssh alexey.wolf@202.20.183.100
$ mkdir -p ~/envs/rcwa
$ tar -zxf rcwa.tar.gz -C ~/envs/rcwa
$ source ~/envs/rcwa/bin/activate
$ conda-unpack
```

4. Copy project dir (`metalens_inverse`) to the server with `scp` and decompress it into home directory:

```
$ scp metalens_inverse.tar.gz alexey.wolf@202.20.183.100:/home/sr5/alexey.wolf
$ ssh alexey.wolf@202.20.183.100
$ tar -zxf metalens_inverse.tar.gz
```

5. Write batch script for execution in the next way using your actual paths:

```
#!/bin/ksh
#BSUB -P "metalens"
#BSUB -J "inverse"
#BSUB -q "usercode_64cpu"
#BSUB -n "64"
#BSUB -o %J.out
#BSUB -e %J.err

WORK_DIR=/home/sr5/alexey.wolf/metalens_inverse
PYTHON_DIR=/home/sr5/alexey.wolf/envs/rcwa/bin

source $PYTHON_DIR/activate
$PYTHON_DIR/python $WORK_DIR/optimizer.py
$PYTHON_DIR/python $WORK_DIR/postproc.py
```

Save it as `rcwa.batch` or any other name.

6. Add `rcwa.batch` script to scheduler:
```
$ bsub < rcwa.batch
```

That's all. Get ID of the job with `$ bjobs` and see the progress with `$ bjobs -l job_id`.

## Files description

`params.py` – File to start with; it contains parameters of metalens, RCWA, NLOpt etc. See commentary inside for more information.

`primitives.py` – It contains basic functions, including RCWA model, near-to-far field transfer function etc. Some commentary can be found in a function's doc-string.

`optimizer.py` – The main script calculating parameters of a metalens and performing its inverse design. It generates a logger information and save some figures into `data` folder by default. At the output the script gives two files:

* `opt_hist.txt` – contains history of optimization; 1st column is a distance between (0,0) to centers of unique meta-atoms; 2nd, 3rd, and 4th contains optimized radii of cylindrical pillars for unique meta-atoms; 5th column contains best RMSE value reached in the optimization process.

* `opt_phases.txt` – phase response of unique meta-atoms depending on wavelength (first row).

`postproc.py` – takes information from `params.py`, `opt_hist.txt`, and `opt_phases.txt` to compare target/inverse phase distributions and to plot intensity near the focal point; see figures in `data` folder.

`data` folder – by default all data is stored here.


## Results

<img src='data/phase_dist_1d_min_max.png'>

*Fig. 2. [LEFT] Target phase distribution for min/max wavelengths (or max/min wavenumbers). [CENTER] Unwrapped phase distributions. [RIGHT] Phase dispersion space to realize metalens with defined parameters. Generated by `optimizer.py`.*

<img src='data/phase_dispersion_space.png' width='400'>

Fig. 3. [BLUE] Phase dispersion space calculated from RCWA for meta-atoms with randomized radii. [RED] Target phase dispersion from Fig. 3. Generated by `optimizer.py`.

<img src='data/phase_target_optimized_wl=10.00um.png' width='600'>

Fig. 4. Target/inverse phase distributions for 10 μm wavelength radiation. Generated by `postproc.py`.

<img src='data/near_to_far_wl=8.00um.png'  width='600'>
<img src='data/near_to_far_wl=10.00um.png' width='600'>
<img src='data/near_to_far_wl=12.00um.png' width='600'>
 
Fig. 5. XY and YZ intensity profiles for designed metalens at 8, 10, and 12 μm. Generated by `postproc.py`.
