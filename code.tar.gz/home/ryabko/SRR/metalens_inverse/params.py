'''
This file contains parameters of a models.

'''

import os
import numpy as np
import nlopt

##### common

save_dir = 'data/' # where to save data
fig_dpi = 300      # default resolution for matplotib figures

##### materials

nAir = 1.0       # refractive index of Air
nSi =  3.44      # refractive index of Si
epsAir = nAir**2
epsSi  = nSi**2 

##### min/max wavelengths range

wl_min = 8  # min. wavelength
wl_max = 12 # max. wavelength
Nwl = 5 # number of wavelengths in the range
wl_range_inv = np.linspace(wl_max,wl_min,Nwl) # !!! max to min order is essential

##### metalens parameters

F = 3000   # focal length (μm)
D = 770    # diameter (μm)
R = 0.5*D  # radius (μm)
# TODO: to set optimal R0 value automatically; current R0 was choosen manually for metalens with F=3000 and D=770
R0 = 1.7*R # zero dispersion point (μm); should be choosen based on dispersion space analysis
dr = 6     # pitch of a meta-atom (μm)

##### gRCWA model params

nG_max = 100                  # maximum number of Fourier expansion orders in XY plane; higher is better
a_rcwa = 6                    # cell size along x and y axes
Nx_rcwa = Ny_rcwa = 601       # points along x and y axes
thicks_rcwa = [6.0, 6.0, 6.0] # thicknesses of patterned layers 
Npl_rcwa = len(thicks_rcwa)   # number of patterned layers

# angles of planewave incidence
phi_deg = 0.0                      # azimuthal angle theta in [0,360)
phi_rad = phi_deg * np.pi/180      # degrees to radians
theta_deg = 0.0                    # polar angle phi in [0,180)
theta_rad = theta_deg * np.pi/180  # degrees to radians

# P-polarized wave (electric field along x axis if normally incident planewave)
# !!! P_wave is used by default in RCWA model 
P_wave = {
    'p_amp':     1.0,
    'p_phase':   0.0,
    's_amp':     0.0,
    's_phase':   0.0,
    'order':     0,
    'direction': 'forward'
}

# S-polarized wave (electric field along y axis if normally incident planewave)
S_wave = {
    'p_amp':     0.0,
    'p_phase':   0.0,
    's_amp':     -1.0, # negative sign is for initial phase zeroing while simulations
    's_phase':   0.0,
    'order':     0,
    'direction': 'forward'
}

# params for disperion space plotting
Nr_trial = 200 # number of trial runs should be enought for space analysis
Nwl_trial = 41 # number of wavelengths in [wl_max,wl_min] range; should be enought for phase unwrapping
wl_range_inv_trial  = np.linspace(wl_max,wl_min,Nwl_trial) # !!! max to min order is essential

##### NLOpt optimizer params

r_min, r_max = 0.5, 2.5 # mix/max possible radii in optimization

# lower & upper boundaries for rs = [r1, r2, r3]
rs_lb   = np.array([r_min]*Npl_rcwa)
rs_ub   = np.array([r_max]*Npl_rcwa)

opt_ndof = Npl_rcwa        # degrees of freedom
opt_alg = nlopt.LN_COBYLA  # COBYLA = Constrained Optimization BY Linear Approximations

# quality parameter & number of optimization steps
RMSE_threshold = 0.3  # this value or lower should be achieved
maxeval_inner  = 30   # number of steps in the inner optimization cycle
maxeval_outer  = 900  # absolute max. number of optimization steps
