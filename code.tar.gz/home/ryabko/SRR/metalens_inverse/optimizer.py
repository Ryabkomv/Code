'''
This is main script calculating parameters of a metalens and performing its inverse design.

'''

#%% IMPORTS & BASIC FUNCTIONS

import sys
import logging
import time
import mkl
import nlopt
import numpy as np
import matplotlib.pyplot as plt

from primitives import *
from params import *

# MKL settings
mkl.set_num_threads(64)
mkl.set_dynamic(0)

# where to write output files
script_path = os.path.dirname(os.path.realpath(__file__))
save_path = os.path.join(script_path, save_dir)
if not os.path.isdir(save_path): os.makedirs(save_path) # create dir if not exists

# Matplotlib
MPL_OUTPUT_FLAG = True # plot figures
plt.rcParams.update({'figure.max_open_warning': 0}) # supress warnings on the number of figures

# NumPy formatter for printing arrays
np_formatter = {'float_kind': lambda x: f'{x:.3f}'} 
np.set_printoptions(formatter=np_formatter)

# logger params
logging.basicConfig(
    level=logging.INFO,
    format='[%(asctime)s] [%(levelname)-5.5s] %(message)s',
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler(os.path.join(save_path,'opt_info.log'), mode='w'),
    ]
)


#%% METALENS ANALYSIS & TARGET PHASE EXTRACTION

##### preliminary estimations

NA = nAir*np.sin(np.arctan(D/(2*F))) # numerical aperture

k_min_Air = 2 * np.pi * nAir / wl_max
k_max_Air = 2 * np.pi * nAir / wl_min
delta_k_Air = k_max_Air - k_min_Air

k_min_Si = 2 * np.pi * nSi / wl_max
k_max_Si = 2 * np.pi * nSi / wl_min
delta_k_Si = k_max_Si - k_min_Si

delta_phi0_lower = R*delta_k_Air*(1-np.sqrt(1-NA**2))/NA # minimal delta_phi0 required to realize metalens
h_min = delta_phi0_lower / delta_k_Si # minimal possible height of a meta-atom

logging.info(f'For a given lens parameters NA is {NA:.3f}.')
logging.info(f'Δφ0 should be more than {delta_phi0_lower/np.pi:.2f} π to realize desired metalens.')
logging.info(f'Minimal possible height of a meta-atom is h_min = {h_min:.2f} μm if Si is used as medium.')

##### counting unique meta-atoms (MA)

xc_lens = yc_lens = np.arange(0.5*dr, R, dr) # centers of meta-atoms along x- and y-axes
Nx_lens, Ny_lens = len(xc_lens), len(yc_lens)
XC_lens, YC_lens = np.meshgrid(xc_lens, yc_lens)
RC_lens = np.sqrt(XC_lens**2+YC_lens**2)     # distances from (0,0) to center of each meta-atom
RC_lens[RC_lens>R] = np.nan                  # NaN if outside R

RC_lens_unique, idx_unique = ndix_unique(RC_lens)                 # unique Rs and their indices
RC_lens_unique, idx_unique = RC_lens_unique[:-1], idx_unique[:-1] # dropping last NaN value

# XY coordinates of unique meta-atoms
XC_lens_unique = [XC_lens[tuple(idxs[0])] for idxs in idx_unique]
YC_lens_unique = [YC_lens[tuple(idxs[0])] for idxs in idx_unique]

logging.info(f'Total number of unique meta-atoms for the target lens is {len(RC_lens_unique)}.')

if MPL_OUTPUT_FLAG:
    
    fig, ax = plt.subplots(1,1,figsize=(5,3))

    ax.plot(XC_lens_unique, YC_lens_unique, '.')
    ax.set_title('unique meta-atoms')
    ax.set_xlabel('x (μm)')
    ax.set_ylabel('y (μm)')
    ax.set_aspect('equal')
    fig.tight_layout()
    fig.savefig(save_path+'unique_meta_atoms.png', dpi=fig_dpi)

##### getting disperion space

k_range = 2 * np.pi * nAir / wl_range_inv                     # wavenumbers
dF_range = np.sqrt(RC_lens**2 + F**2) - np.sqrt(R0**2 + F**2) # distance from each meta-atom to focal point
phase_lens = np.array([-k*dF_range for k in k_range])         # target phase distribution for each wavenumber
phase_lens_wrap = np.angle(np.exp(1j*phase_lens))             # "wrapped" target phase distribution

# phase distributions for min/max wavenumbers
phase_lens_min,      phase_lens_max      = phase_lens[0],      phase_lens[-1]
phase_lens_min_wrap, phase_lens_max_wrap = phase_lens_wrap[0], phase_lens_wrap[-1]

# target dispersion space
phi0_lens = phase_lens_min
delta_phi0_lens = phase_lens_max - phase_lens_min

# target phase response for each unique meta-atom
phase_target_range = np.array([phase_lens_wrap[:,idx[0][0],idx[0][1]] for idx in idx_unique])

logging.info('Target phase distribution has been succesfully extracted.')

if MPL_OUTPUT_FLAG:
    
    ##### plotting phase distributions for k_min, k_max in 2D

    fig, axs = plt.subplots(1,2,figsize=(8,3))
    fig.suptitle(f'Lens parameters: F = {F/1000} mm, D = {D/1000} mm, NA = {NA:.3f}')

    c0 = axs[0].pcolormesh(xc_lens, yc_lens, phase_lens_min_wrap/np.pi)
    fig.colorbar(c0, ax=axs[0]).set_label('phase / π')
    axs[0].set_title('$\phi(x,y,k) | k=k_{min}$')

    c1 = axs[1].pcolormesh(xc_lens, yc_lens, phase_lens_max_wrap/np.pi)
    fig.colorbar(c1, ax=axs[1]).set_label('phase / π')
    axs[1].set_title('$\phi(x,y,k) | k=k_{max}$')

    for ax in axs.flatten():
        ax.set_aspect('equal')
        ax.set_xlabel('x (μm)')
        ax.set_ylabel('y (μm)')

    fig.tight_layout()
    fig.savefig(save_path+'phase_dist_2d_min_max.png', dpi=fig_dpi)

    ##### plotting phase distributions for k_min, k_max in 1D

    fig, axs = plt.subplots(1,3,figsize=(12,3))
    fig.suptitle(f'Lens parameters: F = {F/1000} mm, D = {D/1000} mm, NA = {NA:.3f}')

    # wrapped phase distribution
    axs[0].plot(xc_lens, phase_lens_min_wrap[0,:]/np.pi, '-', fillstyle='none', label='k_min')
    axs[0].plot(xc_lens, phase_lens_max_wrap[0,:]/np.pi, '-', fillstyle='none', label='k_max')
    axs[0].set_title('$\phi(r,k) | k=k_{min}$ and $k=k_{max}$')
    axs[0].set_xlabel('radius (μm)')
    axs[0].set_ylabel('phase / π')
    axs[0].set_xlim([xc_lens[0], xc_lens[-1]])

    # unwrapped phase distribution 
    axs[1].plot(xc_lens, phase_lens_min[0,:]/np.pi, '-', fillstyle='none',
                label=f'k_min={k_min_Air:.2f} μm$^{-1}$')
    axs[1].plot(xc_lens, phase_lens_max[0,:]/np.pi, '-', fillstyle='none',
                label=f'k_max={k_max_Air:.2f} μm$^{-1}$')
    axs[1].set_title('unwrapped $\phi(r,k) | k=k_{min}$ and $k=k_{max}$')
    axs[1].set_xlabel('radius (μm)')
    axs[1].set_ylabel('phase / π')
    axs[1].set_xlim([xc_lens[0], xc_lens[-1]])
    axs[1].legend(loc='lower left')

    # phase disperion space
    axs[2].plot(np.angle(np.exp(1j*phi0_lens[0,:]))/np.pi, delta_phi0_lens[0,:]/np.pi, '.', fillstyle='none')
    axs[2].set_title('phase dispersion space')
    axs[2].set_xlabel('$\phi_{min} / \pi$')
    axs[2].set_ylabel('$(\phi_{max}-\phi_{min}) / \pi$')

    fig.tight_layout()
    fig.savefig(save_path+'phase_dist_1d_min_max.png', dpi=150)


#%% TEST OF RCWA MODEL OF META-ATOM

# RCWA test
_, _, refl_test, tran_test = cyl_pillar_rcwa(rs=[1.5, 1.0, 0.5],
                                             thicks=thicks_rcwa,
                                             wl=10.0,
                                             return_amps_only=False,
                                             plot_masks=MPL_OUTPUT_FLAG)

logging.info(f'RCWA model test: R+T = {refl_test+tran_test:.5f} ' +\
              '[OK]' if (1-refl_test-tran_test) < 0.01 else '[NOT OK]')


#%% META-ATOM: DISPERSION SPACE EXTRACTION

# phase response test
_, phase_min_rcwa = phase_resp_rcwa([r_min]*3, thicks_rcwa, wl_range_inv_trial,
                                    unwrap_phase=True, plot_amp_phase=MPL_OUTPUT_FLAG)
_, phase_max_rcwa = phase_resp_rcwa([r_max]*3, thicks_rcwa, wl_range_inv_trial,
                                    unwrap_phase=True, plot_amp_phase=MPL_OUTPUT_FLAG)

logging.info('Phase extraction test: ' +\
             f'Δφ0_min = {phase_min_rcwa[-1]-phase_min_rcwa[0]:.2f} at r_min = {r_min}, ' +\
             f'Δφ0_max = {phase_max_rcwa[-1]-phase_max_rcwa[0]:.2f} at r_max = {r_max}.')

# empty lists for collecting phase dispersion data
phi0_trial = []
delta_phi0_trial = []

logging.info(f'Calculating phase disperion space for N={Nr_trial} random meta-atoms...')

for i in range(Nr_trial):

    rs_cur = rs_lb + (rs_ub-rs_lb)*np.random.random(opt_ndof) # randomized starting point
    _, phase_p0_range = phase_resp_rcwa(rs_cur, thicks_rcwa, wl_range_inv_trial, unwrap_phase=True) # !!! unwrap is essential
    
    phi0_trial.append(phase_p0_range[0])
    delta_phi0_trial.append(phase_p0_range[-1]-phase_p0_range[0])

    progress = (i+1)/Nr_trial
    draw_progress_bar(progress)

print(f'Δφ0 statistics for N={Nr_trial} meta-atoms with randomized parameters:',
      f'----------------------------------------------------------------------'
      f'min       | {np.min(delta_phi0_trial):5.2f} rad',
      f'max       | {np.max(delta_phi0_trial):5.2f} rad',
      f'mean      | {np.mean(delta_phi0_trial):5.2f} rad',
      f'std       | {np.std(delta_phi0_trial):5.2f} rad',
      f'median    | {np.median(delta_phi0_trial):5.2f} rad',
      f' 2.5 %ile | {np.quantile(delta_phi0_trial,0.05):5.2f} rad',
      f'97.5 %ile | {np.quantile(delta_phi0_trial,0.95):5.2f} rad\n',
      sep='\n')

# TODO: to analyze delta_phi0 to choose optimal R0

if MPL_OUTPUT_FLAG:

    fig, ax = plt.subplots(1,1,figsize=(5,3))
    ax.plot(phi0_trial, delta_phi0_trial, '.', fillstyle='none', label='RCWA')
    ax.plot(np.angle(np.exp(1j*phi0_lens[0,:])), delta_phi0_lens[0,:], 'r.', fillstyle='none', label='target')
    ax.set_title('phase dispersion space')
    ax.set_xlabel('$\phi_{min}$ (rad)')
    ax.set_ylabel('$\phi_{max}-\phi_{min}$ (rad)')
    ax.legend(loc='center left', bbox_to_anchor=(1,.5))
    fig.tight_layout()
    fig.savefig(save_path+'phase_dispersion_space.png', dpi=fig_dpi)


#%% NLOPT OPTIMIZATION

# history of optimization
Rc_hist = []
rs_best_hist = []
RMSE_best_hist = []

logging.info('##### START OF OPTIMIZATION #####')

# looking for optimal phase response for all unique meta-atoms
for Rc, phase_target in zip(RC_lens_unique, phase_target_range):

    start_time = time.time() # timer

    logging.info(f'Current targets: Rc = {Rc:7.3f}.')

    # resetting params for outer optimizataion cycle
    counter = 0     # current step of optimizer
    RMSE_list = []  # all RMSE values for current target
    RMSE_best = 999 # lowest RMSE reached for current target
    rs_best = None  # rs giving lowest RMSE for current target 

    # gradient-free objective function for current target
    def objective_no_grad(rs, gradn=0):
        
        global counter, RMSE_list, RMSE_best
        
        # !!! P-polarization is excited and extracted used by default
        _, phase_p0_range = phase_resp_rcwa(rs, thicks_rcwa, wl_range_inv, unwrap_phase=False)
        RMSE = np.sqrt(np.mean((phase_target-phase_p0_range)**2))

        update_last_line(f'step no. {counter:2}: RMSE = {RMSE:7.3f} (best outer is {RMSE_best:7.3f}), ' +\
                         f'rs = {np.array2string(rs)} μm')
        
        counter += 1
        RMSE_list.append(RMSE)
        
        return RMSE
    
    # inner optimization cycle for current target 
    def inner_opt(rs_init):
        
        opt = nlopt.opt(opt_alg, opt_ndof)
        opt.set_lower_bounds(rs_lb)
        opt.set_upper_bounds(rs_ub)
        opt.set_xtol_rel(1e-5)
        opt.set_maxeval(maxeval_inner)
        opt.set_min_objective(objective_no_grad)
        rs_opt = opt.optimize(rs_init)
        
        return rs_opt
    
    # trying to reuse last found rs if not the first meta-atom; in some casese this will save our time
    if len(rs_best_hist) > 0:
        
        logging.info('Trying to reoptimize previously found rs.')
        
        rs_prev = rs_best_hist[-1]
        rs_best = inner_opt(rs_prev)
        RMSE_best = np.min(RMSE_list)
        
        # if we reached RMSE below threshold then go to the next meta-atom
        if RMSE_best <= RMSE_threshold:
            Rc_hist.append(Rc)
            rs_best_hist.append(sorted(rs_best, reverse=True))
            RMSE_best_hist.append(RMSE_best)
            print()
            continue
        else:
            logging.info('New rs to be found.')
    
    # trying to find new rs until RMSE_threshold is reached
    while RMSE_best > RMSE_threshold:
    
        rs_init = rs_lb + (rs_ub-rs_lb)*np.random.random(opt_ndof) # randomized starting point
        rs_opt = inner_opt(rs_init)
        
        # updating "best" values if inner optimizer is better than prevous runs
        if np.min(RMSE_list) < RMSE_best:
            RMSE_best = np.min(RMSE_list)
            rs_best = rs_opt
        
        # stopping outer optimization cycle if maxeval_outer is reached
        if counter >= maxeval_outer:
            logging.info('Target RMSE was never achieved.')
            print()
            break
    
    Rc_hist.append(Rc)
    rs_best_hist.append(sorted(rs_best, reverse=True))
    RMSE_best_hist.append(RMSE_best)
    print()
    
    logging.info(f'Optimization took {time.time()-start_time:7.2f} seconds, ' +\
                 f'best RMSE = {RMSE_best:7.3f}')

logging.info('##### END OF OPTIMIZATION #####')


#%% FINAL CALCULATIONS & RESULTS SAVING

# saving data

logging.info('History of optimization has been succesfully dumped.')

Rc_hist        = np.array(Rc_hist)
rs_opt_hist    = np.array(rs_best_hist)
RMSE_best_hist = np.array(RMSE_best_hist)

dump_hist = np.hstack([Rc_hist[:,np.newaxis], rs_opt_hist, RMSE_best_hist[:,np.newaxis]])
dump_header = 'Rc (μm)\tr1 (μm)\tr2 (μm)\tr3 (μm)\tRMSE (μm)'
np.savetxt(save_path+'opt_hist.txt', dump_hist, header=dump_header, delimiter='\t')

logging.info('Optimal phases calculation...')

# optimized phases calculation

phase_opt = []

for i, rs in enumerate(rs_best_hist):
    
    # !!! P-polarization is excited and extracted used by default
    _, phase_p0_opt = phase_resp_rcwa(rs, thicks_rcwa, wl_range_inv, unwrap_phase=False)
    phase_opt.append(phase_p0_opt)
    
    draw_progress_bar((i+1)/len(rs_best_hist))

phase_opt = np.array(phase_opt)

dump_phase = np.vstack([wl_range_inv,phase_opt]) # !!! first row is a wavlength
dump_heared = 'wl_1, ..., wl_N (μm)'
np.savetxt(save_path+'opt_phases.txt', dump_phase, header=dump_heared, delimiter='\t')

logging.info('History of optimization has been succesfully dumped.')

