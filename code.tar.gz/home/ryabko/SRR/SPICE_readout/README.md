# SPICE_readout
Readout circuits SPICE simulations

## Contents

### Bolometer bridge circuit
Bridge readout circuits simulation

#### Bridge circuit (AD8664 opamp version)

* `bridge.asc` **LTspice schematics file**
* `bridge.plt` LTspice plot settings

![Schematic diagram](img/bridge.png)

![Output voltage vs. temperature](img/bridge.raw.png)

#### Bridge circuit (LT6370 instrumentation amplifier version)

* `bridge_inamp.asc` **LTspice schematics file**
* `bridge_inamp.plt` LTspice plot settings

![Schematic diagram](img/bridge_inamp.png)

![Output voltage vs. temperature](img/bridge_inamp.raw.png)

#### Miscellaneous

* `delbak.cmd` script to delete temporary files from working directory
* `LT6370.pdf` LT6370 instrumentation amplifier datasheet
* `rieke1989.pdf` F. M. Rieke, A. E. Lange, J. W. Beeman and E. E. Haller, "An AC bridge readout for bolometric detectors," in *IEEE Transactions on Nuclear Science,* vol. 36, no. 1, pp. 946-949, Feb. 1989, doi: [10.1109/23.34581](https://doi.org/10.1109/23.34581).

### Integrator

* `Integrator.asc` **LTspice schematics file**
* `Integrator.plt` LTspice plot settings
* `Integrator_SS.asc` **LTspice schematics file (single-supply version)**
* `Integrator_SS.plt` LTspice plot settings

![Schematic diagram](img/Integrator_SS.png)

![Simulation results](img/Integrator_SS_waveform.png)

#### Miscellaneous

* `delbak.cmd` script to delete temporary files from working directory

### `img`
Images to use in this document.

## Software required
* [LTspice XVII](https://www.analog.com/en/design-center/design-tools-and-calculators/ltspice-simulator.html)
* [MS Excel](https://www.microsoft.com/en-us/microsoft-365/excel)
