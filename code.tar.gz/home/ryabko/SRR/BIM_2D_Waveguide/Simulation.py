#!/usr/bin/env python3
# -*- coding: utf-8 -*-


"""TO DO
Implemets parametrized borders with splines
Visualize borders

"""


# =============================================================================
""" 
Create a borders for the simulation. Border points are used to evaluate the integrals for the dedicated interval

Create simulation domains using created borders. Domains will be used while creating the intervals

Create a set of domains for the simulation with the class Omega

"""
# =============================================================================

import numpy as np
from scipy.optimize import minimize
from scipy.optimize import Bounds
import scipy.interpolate as interpolate
import matplotlib.pyplot as plt
import scipy.special as sc

class Waveguide():
    def __init__(self, wavelength, symmetric, mode, h , n3 , n2 , n1):
        
        self.n1 = n1
        self.n2 = n2
        self.n3 = n3
        self.wavelength = wavelength
        self.symmetric = symmetric
        self.mode = mode
        self.width = h
        self.gamma_co = 0
        self.gamma_cl = 0
        self.gamma_km = 0
        
        
    def Source(self, r):
        
        gamma_co, gamma_cl, km = self.modePfofile()
        self.gamma_co = gamma_co
        self.gamma_cl = gamma_cl
        self.km = km
        km=-km
        h = self.width/2
        if (self.symmetric):
            
            u = np.cos(gamma_co*r[1])*np.exp(1j*km*r[0])
            u[r[1]>h] =  np.cos(gamma_co*h) * np.exp( - gamma_cl*(r[1][r[1]>h]-h))  * np.exp(1j* km * r[0][r[1]>h] )
            u[r[1]<-h] = np.cos(gamma_co*h) * np.exp(   gamma_cl*(r[1][r[1]<-h]+h)) * np.exp(1j* km * r[0][r[1]<-h])
            
           
            vx = 1j*km     * np.cos(gamma_co*r[1]) * np.exp(1j*km*r[0])
            vy = -gamma_co * np.sin(gamma_co*r[1]) * np.exp(1j*km*r[0])
            
            vx[r[1] >h] = 1j*km * np.cos(gamma_co*h) * np.exp( - gamma_cl*(r[1][r[1] >h]-h)) * np.exp(1j* km * r[0][r[1] >h])
            vx[r[1]<-h] = 1j*km * np.cos(gamma_co*h) * np.exp(  gamma_cl*(r[1][r[1]<-h]+h))  * np.exp(1j* km * r[0][r[1]<-h])
            
            vy[r[1] >h] = -gamma_cl * np.cos(gamma_co*h) * np.exp( - gamma_cl*(r[1][r[1] >h]-h)) * np.exp(1j*km*r[0][r[1] >h])
            vy[r[1]<-h] =  gamma_cl * np.cos(gamma_co*h) * np.exp(   gamma_cl*(r[1][r[1]<-h]+h)) * np.exp(1j*km*r[0][r[1]<-h])
            
        else:
            
            u = np.sin(gamma_co*r[1])*np.exp(1j*km*r[0])
            u[r[1]>h] = np.sin(gamma_co*h)*np.exp(-gamma_cl(r[1]-h))*np.exp(1j*km*r[0])
            u[r[1]<-h] = np.sin(gamma_co*h)*np.exp(gamma_cl(r[1]+h))*np.exp(1j*km*r[0])
            
           
            vx = 1j*km*np.sin(gamma_co*r[1])*np.exp(1j*km*r[0])
            vy = gamma_co*np.cos(gamma_co*r[1])*np.exp(1j*km*r[0])
            
            vx[r[1] >h] = 1j*km*np.sin(gamma_co*h)*np.exp(-gamma_cl(r[1]-h))*np.exp(1j*km*r[0])
            vx[r[1]<-h] = 1j*km*np.sin(gamma_co*h)*np.exp(gamma_cl(r[1]+h))*np.exp(1j*km*r[0])
            
            vy[r[1] >h] = -gamma_cl*np.sin(gamma_co*h)*np.exp(-gamma_cl(r[1]-h))*np.exp(1j*km*r[0])
            vy[r[1]<-h] =  gamma_cl*np.sin(gamma_co*h)*np.exp(gamma_cl(r[1]+h))*np.exp(1j*km*r[0])
            
            
        return u, vx, vy
    
    def modePfofile(self, y=1, dy=0.1):
        h = self.width/2
        wavelength = self.wavelength
        symmetric = self.symmetric
        mode = self.mode

        def opt_fun(x):
            if (symmetric):
                return np.abs(np.sqrt(x**2-k_cl**2) - nu_wg*np.sqrt(-x**2+k_co**2)*np.tan(np.sqrt(-x**2+k_co**2)*h))
            else:
                return np.abs(nu_wg*np.sqrt(-x**2+k_co**2) + np.sqrt(x**2-k_cl**2)*np.tan(np.sqrt(-x**2+k_co**2)*h))

        def findK():
            
            res = minimize(lambda x: opt_fun(x), x0 = (k_cl+k_co)/2, bounds=Bounds(k_cl, k_co))
            # print(res.success)
            
            return res

        

        

        n_co = self.n3
        n_cl = self.n1

        k_co = 2*np.pi*n_co/wavelength
        k_cl = 2*np.pi*n_cl/wavelength

               

        if mode == 'TE':
            nu_wg = 1 #TE
        elif mode == 'TM':
            nu_wg = (k_cl/k_co)**2
         #TM

        km = findK().x[0]
       
        # km = 13.33535142259915
        gamma_co = np.sqrt(k_co**2 -km**2)
        gamma_cl = np.sqrt(-k_cl**2 +km**2)

        # print('gamma cladding = ' + str(gamma_cl))
        # print('gamma core * tan(gamma_co*h) = ' + str(gamma_co*np.tan(gamma_co*h)))

        # x_w = np.arange(-y-dy, y + 1*dy+1e-15, dy)
        

        # u = x_w*0

        # if (symmetric):
            
        #     u = np.cos(gamma_co*x_w)
            
        #     u[x_w > h] = np.cos(gamma_co*h)*np.exp(-1*gamma_cl*(x_w[x_w > h] -h))
        #     u[x_w < -h] = np.cos(-1*gamma_co*h)*np.exp(1*gamma_cl*(x_w[x_w < -h] +h))
        # else:
        #     u = np.sin(gamma_co*x_w)
            
        #     u[x_w > h] = np.sin(gamma_co*h)*np.exp(-1*gamma_cl*(x_w[x_w > h] -h))
        #     u[x_w < -h] = np.sin(-1*gamma_co*h)*np.exp(1*gamma_cl*(x_w[x_w < -h] +h))
            
        
        # v = (u[2:] - u[0:-2])/2/dy
        
        return gamma_co, gamma_cl, km

class Model():
    
# contains functions and parameters required for simulation


    def __init__(self,
                 wavelength,
                 delta_x,
                 delta_y,
                 alpha,
                 useWindow = False
                                  
                 ):
        self.domains=[]
        self.delta_x = delta_x
        self.delta_y = delta_y
        self.wavelength= wavelength
        self.alpha = alpha
        self.simGraph = []
        self.M = 0
        self.N_src = 0
        self.U = 0
        self.tmp = {}
        self.WA = 0
        
    def addDomain(self, O):
        self.domains.append(O)

    def setSim(self, G):
        
        self.WA = np.copy(self.W(G.x, A, z1, z2))
        
        u, vx, vy = wg.Source( (G.x, G.y) )

        v = vx*G.nx + vy*G.ny

        u[G.x>sourceEnd]  = 0
        v[G.x>sourceEnd]  = 0
        
        self.M = len(G.x)
        
        self.T = np.zeros((2*self.M, 2*self.M))+1e-15j
        self.T_src = np.zeros((2*self.M))+1e-15j
        self.E = np.identity(2*self.M)

        self.E_src = np.concatenate((u, v))

    def concatenateBorders(self, G):
        x = G[0].x
        y = G[0].y
        nx = G[0].nx
        ny = G[0].ny
        lx = G[0].lx
        ly = G[0].ly
        for i in range(len(G)-1):
            x = np.concatenate((x,G[i+1].x))
            y = np.concatenate((y,G[i+1].y))
            nx = np.concatenate((nx,G[i+1].nx))
            ny = np.concatenate((ny,G[i+1].ny))
            lx = np.concatenate((lx,G[i+1].lx))
            ly = np.concatenate((ly,G[i+1].ly))
        
        return Gamma( (x,y) , (nx, ny) , (lx, ly))
    
    def intersectBorderInterval(self, G, interval):
        
        a = min(interval)
        b = max(interval)
        
        c = ( G.x >a ) & ( G.x < b )
       
        return Gamma( (G.x[c], G.y[c]) ,    (G.nx[c], G.ny[c]), (G.lx[c], G.ly[c]) )
    
    def createSamplinPoints(self, pointx, pointy, normal):
     
        
        N = max( int((pointx[1] - pointx[0])/self.delta_x), int((pointy[1] - pointy[0])/self.delta_y)  ) + 1
        
        x = np.linspace(pointx[0] , pointx[1], N)
        y = np.linspace(pointy[0] , pointy[1], N)
        
                      
        lx = np.diff(x)
        ly = np.diff(y)
        
       
        y = y[:-1]+np.abs(np.sign(pointy[1] - pointy[0]))*ly/2
        x = x[:-1]+np.abs(np.sign(pointx[1] - pointx[0]))*lx/2
        
        nx = x*0 + normal[0]
        ny = y*0 + normal[1]
        
        
        return (x , y) , (nx , ny), (lx , ly)
    
    def W(self, z, A, z1, z2):
        
       
        s = (np.abs(z-z1) - alpha*A)/A/(1-alpha)
        W = np.exp(-2*np.exp(-1/np.abs(s)**2)/np.abs(1-s)**2)
        W[s<0]=1
        W[s>1]=0
        W[z>z1]=0

        s = (np.abs(z-z2) - alpha*A)/A/(1-alpha)
        W1 = np.exp(-2*np.exp(-1/np.abs(s)**2)/np.abs(1-s)**2)
        W1[s<0]=1
        W1[s>1]=0
        W1[z<z2]=0

        W=W+W1

        W[ (z>z1) & (z<z2)]=1
        
        return W
    
    def plotBorder(self, O):
 
        plt.scatter(O.G.x, O.G.y)
        
        
    
    def calculateDKSN(self, G, O):
        
        gamma = 1.781
        
        x_m = G.x
        y_m = G.y
        
        M = len(x_m)
        
        
        
        k = O.k
        x_n = O.G.x
        y_n = O.G.y
        
        N = len(x_n)
        
        n_x = np.tile(G.nx, (N,1)).T 
        n_y = np.tile(G.ny, (N,1)).T 
        
                
        n_x_p = np.tile(O.G.nx, (M,1))
        n_y_p = np.tile(O.G.ny, (M,1))

        lx = np.tile(O.G.lx, (M,1))
        ly = np.tile(O.G.ly, (M,1))
        dl = np.sqrt(lx**2 + ly**2)
        
        
        
        
        
        Rx = np.tile(x_m, (N,1)).T - np.tile(x_n, (M,1))
        Ry = np.tile(y_m, (N,1)).T - np.tile(y_n, (M,1))
        
        # Rx1 = Rx + lx/2
        # Ry1 = Ry + ly/2
        # R1 = np.sqrt(Rx1**2 + Ry1**2)
        
        # self.tmp['Rx1'] = Rx1
        # self.tmp['Ry1'] = Ry1
        
        # Rx2 = Rx - lx/2
        # Ry2 = Ry - ly/2
        # R2 = np.sqrt(Rx2**2 + Ry2**2)
        
        R =  np.sqrt(Rx**2 + Ry**2)

        Rx = Rx / R 
        Ry = Ry / R 
        
 
        
        
        
        diagS = -0.25j*dl[R<1e-10]*(1-(np.log(k*gamma*dl[R<1e-10]/4)-1)*2j/np.pi)
        
        # diagN =  -0.125j*k*k*( 1*k*k*(dl[R<1e-10])**3/96 
        #                       - 16j/(np.pi*k*k*dl[R<1e-10]) 
        #                       -dl[R<1e-10]+
        #                       2j*dl[R<1e-10]*(np.log(k*gamma*dl[R<1e-10]/4)-1)/np.pi)
        
        # diagN = -1/dl[R<1e-10]/2/np.pi
        diagN = -0.25*k*k*dl[R<1e-10] * (1j/2 +np.log(k*gamma*dl[R<1e-10]/4)/np.pi - 3/2/np.pi + 1j*0.045j)
        # diagN = -0.25*k*k*dl[R<1e-10] * (1j/2 -np.log(k*gamma*dl[R<1e-10]/2)/np.pi - 1 + 0*1j*0.045j)
        #-0.25j*k**4*dl[R<1e-10]**3 *(  1/4/48 + (np.log(k*gamma*dl[R<1e-10]/4)-9/4)*1j/8/np.pi)
        
        n_x_np = n_x * n_x_p + n_y * n_y_p        
        R_x_np =  Rx * n_x_p + Ry * n_y_p
        
        R_x_n =   Rx * n_x + Ry * n_y
        R_x_l = ( Rx *  lx + Ry * ly)/dl
        
       
        # self.tmp['G']=G
        # self.tmp['O']=O
        # self.tmp['lx'] = lx
        # self.tmp['ly'] = ly    
        # self.tmp['n_x'] = n_x
        # self.tmp['n_x_p'] = n_x_p
        # self.tmp['n_y'] = n_y
        # self.tmp['n_y_p'] = n_y_p
        # self.tmp['Rx'] = Rx
        # self.tmp['Ry'] = Ry
        
        # self.tmp['Rxnp'] = R_x_np
        # self.tmp['Rxn'] = R_x_n
        # self.tmp['Rxl'] = R_x_l
        # self.tmp['R'] = R
        # self.tmp['R1'] = R1
        # self.tmp['R2'] = R2
        
        H20 = 0.25j*dl*   sc.hankel2(0,k*R)
        H21 = 0.25j*dl*k* sc.hankel2(1,k*R)
        
        print ('calculating S matrix')
        Sp = -H20
        
        # Dp = -(sc.hankel2(0,k*R1)-sc.hankel2(0,k*R2))*0.25j * R_x_np / R_x_l
        
        # Kp = (sc.hankel2(0,k*R1)-sc.hankel2(0,k*R2))*0.25j * R_x_n / R_x_l
       
        
        
        # Np = -0.25j*k*(
        #     ( sc.hankel2(0,k*R1)-sc.hankel2(0,k*R2) )*n_x_np/R_x_l/R/k-
        #     2*k*R_x_np*R_x_n* ( sc.hankel2(0,k*R1)-sc.hankel2(0,k*R2) )/R_x_l/R/k +
        #     k*dl*sc.hankel2(0,k*R)*R_x_np*R_x_n)
        
        # Dp[R_x_l==0] = -(sc.hankel1(0,k*R[R_x_l==0]))*0.25j*k * R_x_np[R_x_l==0] *dl[R_x_l==0]
        # Kp[R_x_l==0] = (sc.hankel1(0,k*R[R_x_l==0]))*0.25j*k * R_x_n[R_x_l==0] * dl[R_x_l==0]
        
        # Np[R_x_l==0]  = -0.25j*k*(
        #     ( sc.hankel1(0,k*R[R_x_l==0]) )*dl[R_x_l==0]*n_x_np[R_x_l==0]/R[R_x_l==0]-
        #     2*k*R_x_np[R_x_l==0]*R_x_n[R_x_l==0]* ( sc.hankel1(0,k*R[R_x_l==0]) )/R[R_x_l==0] +
        #     k*dl[R_x_l==0]*sc.hankel2(0,k*R[R_x_l==0])*R_x_np[R_x_l==0]*R_x_n[R_x_l==0])
        
        print ('calculating D matrix')
        Dp = -H21 * R_x_np
        
        print ('calculating K matrix')
        Kp =  H21 * R_x_n
        
        print ('calculating N matrix')
        Np = -( H21*n_x_np/R + k*k*R_x_np*R_x_n* H20 - 2*H21*R_x_np*R_x_n/R)
        
         # self.N = (np.tile(G.nx, (N,1))*G._Rx+np.tile(G.ny, (N,1))*G._Ry) * (sc.hankel2(1,k*G._R1)-sc.hankel2(1,k*G._R2))*0.25j *(np.tile(G.nx, (N,1)).T*G._Rx+np.tile(G.ny, (N,1)).T*G._Ry) / (np.tile(G.lx, (N,1))*G._Rx+np.tile(G.ly, (N,1))*G._Ry)
        print ('applying singularity treatment')
        Dp[R<1e-10] = 0# 0.5
        Kp[R<1e-10] = 0# -0.5
        Sp[R<1e-10] = diagS
        Np[R<1e-10] = diagN
   
        
        
        # self.tmp['D'] = Dp
        # self.tmp['S'] = Sp
        # self.tmp['K'] = Kp
        # self.tmp['N'] = Np
        
        return Dp, Kp, Sp, Np
    
    def calculateT(self, G, O_plus, O_minus, M, Num_plus, Num_minus ):
        
        print('calculating plus potentials.......')
        D_plus, K_plus, S_plus, N_plus = self.calculateDKSN(G, O_plus)
        print('calculating minus potentials.......')
        D_minus, K_minus, S_minus, N_minus = self.calculateDKSN(G, O_minus)
        
        
        print('calculating T matrix.......')
        
        self.T[ M[0]          :             M[1],   Num_minus[0]            : Num_minus[1]]                 += D_minus
        self.T[ M[0]          :             M[1],   Num_plus[0]             : Num_plus[1]  ]                -= D_plus
        
        self.T[ M[0]          :             M[1],   (self.M + Num_minus[0]) : (self.M +  Num_minus[1])]     -= S_minus
        self.T[ M[0]          :             M[1],   (self.M + Num_plus[0] ) : (self.M +  Num_plus[1]) ]     += S_plus
        
        self.T[ (self.M+M[0]) : (self.M + M[1]) ,   Num_minus[0]            : Num_minus[1]]                 += N_minus
        self.T[ (self.M+M[0]) : (self.M + M[1]) ,   Num_plus[0]             : Num_plus[1]]                  -= N_plus
        
        self.T[ (self.M+M[0]) : (self.M + M[1]) ,   (self.M + Num_minus[0]) : (self.M +  Num_minus[1])]     -= K_minus 
        self.T[ (self.M+M[0]) : (self.M + M[1]) ,   (self.M + Num_plus[0])  : (self.M +  Num_plus[1])]      +=  K_plus
        
        
    def applyWindow(self, G):
        
        self.T *= np.tile ( np.concatenate((self.WA,  self.WA)), (self.M*2, 1))
        # self.E = self.E * np.tile ( np.concatenate((self.W(G.x), self.W(G.x))), (self.M*2, 1))
        
    
    def Solve(self):
        B = np.copy(self.T + self.E)
        b = np.copy(-self.T_src - self.E_src)
        
        self.U = np.linalg.solve(B, b)
        
        return self.U[:self.M], self.U[self.M:] 
    
    def calculateT_src(self, G, O_plus, O_minus, M, Num_plus, Num_minus ): 
        
        D_plus, K_plus, S_plus, N_plus = self.calculateDKSN(G, O_plus)
        
        D_minus, K_minus, S_minus, N_minus = self.calculateDKSN(G, O_minus)

        
        
        self.T_src[ M[0]:M[1]] += np.matmul(D_minus,  O_minus.u) 
        self.T_src[ M[0]:M[1]] -= np.matmul(D_plus,   O_plus.u)
        
        self.T_src[ M[0]:M[1]] -= np.matmul(S_minus,  O_minus.v)
        self.T_src[ M[0]:M[1]] += np.matmul(S_plus,   O_plus.v)
        
        self.T_src[ (self.M+M[0]) : (self.M + M[1]) ] += np.matmul(N_minus ,  O_minus.u)
        self.T_src[ (self.M+M[0]) : (self.M + M[1]) ] -= np.matmul(N_plus,   O_plus.u)
        
        self.T_src[ (self.M+M[0]) : (self.M + M[1]) ] -= np.matmul(K_minus,  O_minus.v) 
        self.T_src[ (self.M+M[0]) : (self.M + M[1]) ] +=  np.matmul(K_plus,   O_plus.v)
        
    def rolling_window(self, arr, size):
        shape = arr.shape[:-1] + (arr.shape[-1] - size + 1, size)
        strides = arr.strides + (arr.strides[-1],)
        return np.lib.stride_tricks.as_strided(arr, shape=shape, strides=strides)

    def find_rolling(self, seq, subseq):
        windows = self.rolling_window(seq, len(subseq))
        hits = np.ones((len(seq) - len(subseq) + 1,), dtype=bool)
        for i, x in enumerate(subseq):
            hits &= np.in1d(windows[:, i], [x])
        yield from hits.nonzero()[0]

    def calculateField(self, G, O, O_src):
        u = self.U[:self.M] * self.WA
        v = self.U[self.M:] * self.WA
     
        D, K, S, N = self.calculateDKSN(G, O)
        
        D_src, K, S_src, N = self.calculateDKSN(G, O_src)
        
        return np.matmul(D, u) - np.matmul(S,v) + (np.matmul(D_src, O_src.u) - np.matmul(S_src, O_src.v))
    
 
        
        


    
class Gamma():
    
# Takes a border in some form e.g. number of intervals, parametrized curve etc.
# For each point the normal and tangent vectors

    def __init__(self, 
                 points,            #  the array of points to be used as a border for the plus and minus domain
                 normal,            #  normal to the border at the border point
                 tangent
                 ):   
        #Build sampling points. Can be several on each interval for high order quadratures
        
        self.x = points[0]
        self.y = points[1]
        
      
        self.nx = normal[0]
        self.ny = normal[1]
        
        self.lx = tangent[0]
        self.ly = tangent[1]

    
class Omega():
    
# Used also for the Source subdomain

    def __init__(self, 
                 borders,          #  the list of borders for the domain
                 k,                 #  k vector for the domain
                 wg
                 ):       
        self.G = borders
        self.k = k
        src = wg.Source( (borders.x, borders.y) )
        self.u = src[0]
        self.v = src[1]*borders.nx + src[2]*borders.ny 
       
        
class Test():
        
    def __init__(self
                 ):  
        pass
     
    def checkIdentity(self, m):
        
        
        
        u = np.copy(O3.u) 
        u[O3.G.x<=sourceEnd] = 0
        
        
        v = np.copy(O3.v) 
        v[O3.G.x<=sourceEnd] = 0
        
        
        t = np.matmul(m.E + m.T, np.concatenate((u, v))) +(m.E_src + m.T_src)
        # t+= np.matmul(m.T , np.concatenate((u*m.W(O3.G.x), v*m.W(O3.G.x))))
        
        plt.figure()
        plt.plot(G1323.x, np.abs(t[m.M:]))
        plt.figure()
        plt.plot(G1323.x, np.abs(t[:m.M]))
        return t
        
    def calculateFields (self, 
                                  G,            # Border where the fields are calculated
                                  O_scatter,    # Region with the scattered field to be accounted for
                                  O_src):       # Region with a source: infinite integration is replaced with G_inf
        
        # Calculates the field and normal derrivative on the border G
        
        
        # G_scatter = m.intersectBorderInterval( G_t , np.array([-A/2, A]) )
        # O_scatter = Omega(G_scatter, O_t.k, wg)

        print("############### Calculate potentials for scatter region ########################")
        D,K,S,N = m.calculateDKSN(G, O_scatter)


        print("############### Calculate potentials for source region ########################")
        D_src,K_src,S_src,N_src = m.calculateDKSN(G, O_src)
        
        
        # Calculate the field: phi
        u=0

        u += np.matmul(D_src,  O_src.u) 


        u -= np.matmul(S_src,  O_src.v)
        WA = m.W(O_scatter.G.x, A, z1, z2)
        u += np.matmul(D,      O_scatter.u * WA) 
        u -= np.matmul(S,      O_scatter.v * WA) 


        
       
        # Calculate the derrivative: psi
        
        v=0

        v += np.matmul(N_src,  O_src.u) 


        v -= np.matmul(K_src,  O_src.v)

        v += np.matmul(N,  O_scatter.u * WA ) 
        v -= np.matmul(K,  O_scatter.v * WA) 
        
        return u, v
        
    
    def calculateWaveguideField(self, wg, m):
        # =============================================================================
        # Check if we can get the solution integration the domain with analitically solved field
        # =============================================================================
       
        G1 = Gamma( *m.createSamplinPoints ( 
                                            (solPlane , solPlane) , 
                                            (wavegudeHalfWidth, 1), 
                                            (1, 0) ) 
           )
        
       
        
        G3 = Gamma( *m.createSamplinPoints ( 
                                            (solPlane , solPlane) , 
                                            (- wavegudeHalfWidth, wavegudeHalfWidth), 
                                            (1, 0) ) 
           )
        
     
        
        G2 = Gamma( *m.createSamplinPoints ( 
                                            (solPlane , solPlane) , 
                                            (- 1, -wavegudeHalfWidth), 
                                            (1, 0) ) 
           )
        
        G_tot = m.concatenateBorders( [G2, G3, G1] )
        
        
        u1, v1 = self.calculateFields(G1, O1_scat, O1_src)
        u2, v2 = self.calculateFields(G2, O2_scat, O2_src)
        u3, v3 = self.calculateFields(G3, O3_scat, O3_src)
        
        self.plotFields(np.concatenate((u2,-u3,u1)),np.concatenate((v2,-v3,v1)), G_tot)
        
        return (u2, -u3, u1), (v2, -v3, v1)

    def plotFields(self,u,v,G):
            
            plt.figure()
            plt.plot(G.y, u, 'red')
            
            us, vx, vy = wg.Source( (G.x, G.y) )
    
            plt.plot(G.y, us, 'green')
            plt.show()
            
            plt.figure()
            plt.plot(G.y, v, 'red')
            
            
    
            plt.plot(G.y, vx*G.nx + vy*G.ny, 'green')
            plt.show()
            

  

    def checkEquality(self, wg, m, length, length_w, A_w):
    
        # A_w = 400
        
        # =============================================================================
        # Check if D (phi) - L (psi) is equal on G13 and G1_inf 
        # =============================================================================

        #testing border

        G_test = Gamma( *m.createSamplinPoints ( 
                                                    (0 , 2) , 
                                                    (4, 4), 
                                                    (0, 1) 
                                                ) 
                        ) 


        
        G13_inf = Gamma( *m.createSamplinPoints ( 
                                                    (-length , -simReg) , 
                                                    (wavegudeHalfWidth, wavegudeHalfWidth), 
                                                    (0, 1) 
                                                ) 

        ) 
        
        G23_inf = Gamma( *m.createSamplinPoints ( 
                                                    (-length , -simReg) , 
                                                    (-wavegudeHalfWidth, -wavegudeHalfWidth), 
                                                    (0, -1) 
                                                ) 

        )
        
        G1323_inf = m.concatenateBorders([G13_inf, G23_inf])


        G13_inf_w = Gamma( *m.createSamplinPoints ( 
                                                    (-length_w , -simReg) , 
                                                    (wavegudeHalfWidth, wavegudeHalfWidth), 
                                                    (0, 1) 
                                                ) 

        ) 
        
        G23_inf_w = Gamma( *m.createSamplinPoints ( 
                                                    (-length_w , -simReg) , 
                                                    (-wavegudeHalfWidth, -wavegudeHalfWidth), 
                                                    (0, -1) 
                                                ) 

        )
        
        G1323_inf_w = m.concatenateBorders([G13_inf_w, G23_inf_w])
        
        
        
        O_w = Omega(G1323_inf_w, k3, wg)
        O   = Omega(G1323_inf, k3, wg)
        
        plt.plot(O_w.G.x, m.W(O_w.G.x, A_w))
        
        D, K, S, N = m.calculateDKSN(G_test, O)

        res1_13_phi = np.matmul(D, O.u) - np.matmul(S, O.v ) 

        res1_13_psi = np.matmul(N, O.u) - np.matmul(K, O.v ) 
        
        
        WA = m.W(O_w.G.x, A_w, z1, z2)
        
        D, K, S, N = m.calculateDKSN(G_test, O_w)

        res1_13_w_phi = np.matmul(D, O_w.u * WA) - np.matmul(S, O_w.v * WA) 

        res1_13_w_psi = np.matmul(N, O_w.u * WA) - np.matmul(K, O_w.v * WA) 

        # infinitely long G1inf
       
        O = Omega(G3_inf, k3, wg)  

        D, K, S, N = m.calculateDKSN(G_test, O)

        res2_13_phi = (np.matmul(D, O.u) - np.matmul(S, O.v ) )

        res2_13_psi = (np.matmul(N, O.u) - np.matmul(K, O.v ) )

        plt.figure()
        plt.plot(G_test.x, res1_13_phi, 'blue')
        plt.plot(G_test.x, res2_13_phi,  'green')
        plt.plot(G_test.x, res1_13_w_phi,  'red')

        plt.figure()
        plt.plot(G_test.x, res1_13_psi, 'blue')
        plt.plot(G_test.x, res2_13_psi,  'green')
        plt.plot(G_test.x, res1_13_w_psi,  'red')
        
    def plotResults(self):
        u = np.copy(O3.u) 
        u[O3.G.x<=sourceEnd] = 0
         
         
        v = np.copy(O3.v) 
        v[O3.G.x<=sourceEnd] = 0
         
        plt.figure()
        plt.plot(G13.x, m.W(G13.x,A,z1,z2), linestyle ='dashed', label = 'Window Function')

        plt.plot(G13.x, np.abs(m.E_src[:len(G13.x)]), 'green' , linestyle ='solid', label = 'Source')
        plt.plot(G13.x, np.abs(u[:len(G13.x)]), 'red' , linestyle ='solid',  label = 'Scattered field')
        plt.plot(G13.x, np.abs(residual[:len(G13.x)]), 'blue' , linestyle ='dotted',  label = 'Residual')
        plt.legend()


        plt.figure()
        plt.plot(G13.x, m.W(G13.x,A,z1,z2), linestyle ='dashed', label = 'Window Function')

        plt.plot(G13.x, np.abs(us[:len(G13.x)]), linestyle ='solid', label = 'Found solution, absolute value')

        plt.plot(G13.x, np.abs(u[:len(G13.x)]), 'red' , linestyle ='solid',  label = 'Correct solution, absolute value')
        plt.legend()
        
    def checkBorderEquality(self, G, wg, m):
        
        print("Check equality on the border G13")
        
        u1, v1 = self.calculateFields(G, O2_scat, O2_src)
        u2, v2 = self.calculateFields(G, O3_scat, O3_src)
        # u = np.concatenate((O1_inc.u, O1_scat.u))
        # v = np.concatenate((O1_inc.v, O1_scat.v))
        src = wg.Source( (G.x, G.y) )
        u = src[0]
        v = src[1]*G.nx + src[2]*G.ny 
       
        plt.figure()
        plt.plot(G.x, u1-u2, 'blue')
        plt.plot(G.x, u , 'green')
        
        plt.figure()
        plt.plot(G.x, v1-v2, 'blue')
        plt.plot(G.x, v, 'green')
        
        print(np.max(np.abs(u1-u2 - u)))
        print(np.max(np.abs(v1-v2 - v)))
        
        
        plt.figure()
        plt.plot(G.x, v1-v2 - v, 'blue')
        plt.figure()
        plt.plot(G.x, u1-u2-u, 'green')
        
        plt.figure()
        plt.plot(G.x, u1, 'green')
        plt.plot(G.x, -u2, 'red')
        
        # self.T_src[ M[0]:M[1]] -= np.matmul(D_plus,   O_plus.u)
        
        
        # self.T_src[ M[0]:M[1]] += np.matmul(S_plus,   O_plus.v)
        
        # self.T_src[ (self.M+M[0]) : (self.M + M[1]) ] += np.matmul(N_minus ,  O_minus.u)
        # self.T_src[ (self.M+M[0]) : (self.M + M[1]) ] -= np.matmul(N_plus,   O_plus.u)
        
        # self.T_src[ (self.M+M[0]) : (self.M + M[1]) ] -= np.matmul(K_minus,  O_minus.v) 
        # self.T_src[ (self.M+M[0]) : (self.M + M[1]) ] +=  np.matmul(K_plus,   O_plus.v)
        
# Create a set of intervals where the border conditions will be matched
# Number of intervals is 1 less than the number of points

wavegudeHalfWidth = 0.1
mode_end = 1
solPlane = 3 # the plane to fine the solution at

A=10
z1=0
z2=0

alpha = 0.5
simReg = 10
sourceEnd = -simReg/2

n1 = 1.4
n2 = 1.4
n3 = 4 

wavelength = 1.55

waveguideSymmetric = True
waveguideMode = 'TE'
wg = Waveguide(wavelength, waveguideSymmetric, waveguideMode, 2*wavegudeHalfWidth, n3, n1, n1)
# u, vx, vy = wg.Source( [np.arange(1,7,0.1) , np.arange(1,7,0.1)] )

k1 = 2*np.pi*n1/wavelength
k2 = 2*np.pi*n2/wavelength
k3 = 2*np.pi*n3/wavelength

delta_x = 0.02
delta_y = 0.01

m = Model(
    wavelength,
    delta_x,
    delta_y,
    alpha)

# =============================================================================
# Create simulation borders
# =============================================================================


#         |                         O1
#  G1_inf |
#         |______G13_src_______|______________G13_______________________________
#         |
#         |
#  G3_inf |                   O3
#         |
#         |______G23_src_______|______________G23_______________________________
#  G2_inf |
#         |                   O2


#______________________________________________________________________________
# Create G13




G13 = Gamma( *m.createSamplinPoints ( 
                                        (-simReg , simReg) ,                                  # x interval
                                        (wavegudeHalfWidth , wavegudeHalfWidth),    # y interval
                                        (0, 1)                                      # normal direction
                                    )
            )

#______________________________________________________________________________
# Create G23

G23 = Gamma( *m.createSamplinPoints ( 
                                        (-simReg , simReg) , 
                                        (-wavegudeHalfWidth , -wavegudeHalfWidth), 
                                        (0, -1) 
                                    ) 
            )

#______________________________________________________________________________
# Create G3

G1323 = m.concatenateBorders( [G13, G23] )


#______________________________________________________________________________
# Create G13 incidence

G13_inc = m.intersectBorderInterval( G13 , np.array([-simReg,sourceEnd]) )


#______________________________________________________________________________
# Create G23 incidence
G23_inc = m.intersectBorderInterval( G23 , np.array([-simReg,sourceEnd]) )


#______________________________________________________________________________
# Create G3 incidence

G1323_inc = m.concatenateBorders( [G13_inc, G23_inc] )


# =============================================================================
# Scattered borders
# =============================================================================
#______________________________________________________________________________
# Create G13 scattered

G13_scat = m.intersectBorderInterval( G13 , np.array([sourceEnd,simReg]) )


#______________________________________________________________________________
# Create G23 scattered
G23_scat = m.intersectBorderInterval( G23 , np.array([sourceEnd,simReg]) )


#______________________________________________________________________________
# Create G3 scattered

G1323_scat = m.concatenateBorders( [G13_scat, G23_scat] )



#______________________________________________________________________________
# Create G1_inf
# Normals are inverted to reflect the minus sign befor integral over Inf: integral over inf = - integral over G
G1_inf = Gamma( *m.createSamplinPoints ( 
                                            (-simReg , -simReg) , 
                                            (wavegudeHalfWidth , mode_end), 
                                            (1, 0) 
                                        ) 
            )

#______________________________________________________________________________
# Create G2_inf

G2_inf = Gamma( *m.createSamplinPoints ( 
    (-simReg , -simReg) , 
    (- mode_end, - wavegudeHalfWidth), 
    (1, 0) ) 
    )





#______________________________________________________________________________
# Create G3_inf

G3_inf = Gamma(*m.createSamplinPoints ( 
    (-simReg , -simReg) , 
    (-wavegudeHalfWidth, wavegudeHalfWidth), 
    (-1, 0) ) 
    )






#______________________________________________________________________________
# Create G1_scr

G1_src = m.concatenateBorders( [G1_inf, G13_inc] )

#______________________________________________________________________________
# Create G1_scr

G2_src = m.concatenateBorders( [G2_inf, G23_inc] )

#______________________________________________________________________________
# Create G1_scr

G3_src = m.concatenateBorders( [G3_inf, G1323_inc] )


# =============================================================================
# Create domains
# =============================================================================


O1 = Omega(G13, k1, wg)
O2 = Omega(G23, k2, wg)
O3 = Omega(G1323, k3, wg )

O1_scat = Omega(G13_scat, k1, wg)
O2_scat = Omega(G23_scat, k2, wg)
O3_scat = Omega(G1323_scat, k3, wg)

O1_inc = Omega(G13_inc, k1, wg)
O2_inc = Omega(G23_inc, k2, wg)
O3_inc = Omega(G1323_inc, k3, wg)

O1_src = Omega(G1_src, k1, wg )
O2_src = Omega(G2_src, k2, wg)
O3_src = Omega(G3_src, k3, wg)



# m.plotBorder(O2_src)



m.setSim(G1323)


# G13_s =  m.intersectBorderInterval( G13 , np.array([-A/2,A/2]) )
# G23_s =  m.intersectBorderInterval( G13 , np.array([-A/2,A/2]) )

print("############### T matrix for O1 plus O3 minus ########################")
m.calculateT(G13, O1, O3 , (0, len(G13.x)),            (0, len(G13.x)),            (0, len(G1323.x)) )

print("############### T matrix for O2 plus O3 minus ########################")
m.calculateT(G23, O2, O3 , (len(G23.x), len(G1323.x)), (len(G13.x), len(G1323.x)), (0, len(G1323.x)) )

m.applyWindow(G1323)

print("############### T matrix for O1_src plus O3_src minus ########################")
m.calculateT_src(G13, O1_src, O3_src , (0, len(G13.x)),                       (0, len(G1_src.x)),              (0, len(G3_src.x)) )


print("############### T matrix for O2_src plus O3_src minus ########################")
m.calculateT_src(G23, O2_src, O3_src , (len(G13.x), len(G1323.x)),            (len(G1_src.x), len(G3_src.x)),  (0, len(G3_src.x)) )







#______________________________________________________________________________
# Create solution border 


G = Gamma( *m.createSamplinPoints ( 
                                    (solPlane, solPlane) , 
                                    (-wavegudeHalfWidth, wavegudeHalfWidth), 
                                    (1, 0) ) 
   )







t=Test()

u_wg, v_wg = t.calculateWaveguideField(wg , m)


residual = t.checkIdentity(m)

# print("Max residual = " + str(np.max(np.abs(residual))))

G1 = Gamma( *m.createSamplinPoints ( 
                                            (sourceEnd+10, sourceEnd+20) , 
                                            (-0.1 , -0.1), 
                                            (0, -1) 
                                        ) 
            )
# t.checkBorderEquality(G1, wg, m)

print("############### Calculate the solution ########################")
us, vs = m.Solve()
res = m.calculateField(G, O3, O3_src)
plt.figure()
plt.plot(G.y, res, 'blue')
plt.plot(G.y, -u_wg[1], 'green')
t.plotResults()
# plt.figure()
# plt.plot((m.E_src)[5200:5420])
# plt.plot((m.T_src)[5200:5420])

# plt.figure()
# plt.plot((m.E_src)[5200:5420]+(m.T_src)[5200:5420])
# t.checkEquality(wg,m, 2000, 1000, 1000)