# 2D Waveguide simulation with BIM

## Code 

Implements the approach from the [paper](https://arxiv.org/pdf/1610.04939v1). Used simple collocation approach for integral equation solution.

### Class [Waveguide](Simulation.py?#L30) 

Calculates the waveguide mode, fields and derrivative on the border.

### Class [Model](Simulation.py?#L156)

Implements the routines for layer potential calculation, window function, main equation formation and its solution, operations with borders: concatination and intersection to simplify needed bordes formation 

### Class [Gamma](Simulation.py?#L505)

Makes a border with points, normal and tangent

### Class [Omega](Simulation.py?#L528)

Makes a domain with border and fields and derivatives on that border

### Class [Test](Simulation.py?#L544) 

Performs different validations: 
1. Calculates the residual in the main equation: Ax - b using analitical solution: [checkIdentity](Simulation.py?#L550)
2. Checkes the correct reconstruction of the mode using analitical solution: [calculateWaveguideField](Simulation.py?#L619)
3. Numerically validate the equivalence of integration over infinite waveguide border and perpendicular to waveguide border (Ginf): [checkEquality](Simulation.py?#L678)


## Results

Resul with and without window function:

![](Result_with_window.png)  ![](Result_without_window.png)

Mode profile in the waveguide:

![](Solution.png)

## Background

Waveguides are unbounded and truncation is needed to avoid integration along the infinite border.

Incident mode is truncated via using Green's theorem, see section 3.4 of the [paper](https://arxiv.org/pdf/1610.04939v1) through the equality of the integrals along the infinite waveguide border and artificial border perpendicular to the waveguide with exponential field decay. Method [checkEquality from the class Test](Simulation.py?#L678) checks the identity numerically.

To trancate the scattered field the window function approach is used.

Paper used layer potential formalism for unknown reasons with hypersingular potential N. This approach used [earlier](https://projecteuclid.org/journals/journal-of-integral-equations-and-applications/volume-26/issue-2/A-collocation-method-for-a-hypersingular-boundary-integral-equation-via/10.1216/JIE-2014-26-2-197.full) by Rainer Kress.

<img src = "LP.png" height = "100">

Final equation:

<img src = "FE.png" height = "100">

However, in later works same authors [used different approach](https://arxiv.org/pdf/2110.11419.pdf) for the same problem. 
