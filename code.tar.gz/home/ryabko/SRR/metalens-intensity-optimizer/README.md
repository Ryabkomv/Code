## Phase dispersion space estimation

0) MEEP works only under Linux or WSL (Windows Subsystem for Linux). For a reference, see https://learn.microsoft.com/en-us/windows/wsl/install

1) Install MEEP (MPB is included) following recommendations at https://meep.readthedocs.io/en/latest/Installation/

E.g. to create `conda` environment under Linux (or WSL):

```
$ conda create -n pmp
$ conda activate pmp
$ conda install pymeep="*=mpi_mpich_*" numpy scipy matplotlib jupyter -c conda-forge
```

2) Open & run `3cyl_metaatom_meep.ipynb` notebook.


## Metalens optimization

### How to run code on CPU:

1) Install `conda` environment: 

```
$ conda create -n jax
$ conda activate jax
$ conda install jax -c conda-forge
$ conda install numpy matplotlib jupyter nlopt -c conda-forge 
```

2) Open & run `metalens2d.ipynb` notebook.

### How to run code on NVIDIA GPU:

1) Install CUDA driver following recommendations at https://developer.nvidia.com/cuda-downloads

E.g. for Ubuntu 22.04 LTS use commands:
```
$ wget https://developer.download.nvidia.com/compute/cuda/repos/wsl-ubuntu/x86_64/cuda-keyring_1.1-1_all.deb
$ sudo dpkg -i cuda-keyring_1.1-1_all.deb
$ sudo apt-get update
$ sudo apt-get -y install cuda
```

2) Install `conda` environment: 

```
$ conda create -n jax_cuda
$ conda activate jax_cuda
$ conda install jaxlib=*=*cuda* jax cuda-nvcc -c conda-forge -c nvidia
$ conda install jupyter numpy matplotlib nlopt -c conda-forge 
```

3) Open & run `metalens2d.ipynb` notebook.
