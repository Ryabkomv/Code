import meep as mp 


import time

resolution = 20  # pix/um

abs_size = 20/resolution  # pix / (pix/um)  = um

pml_size = 10/resolution 

Sx = 0 * abs_size + 500/resolution
Sy = 0 * abs_size + 500/resolution
Sz = 0 * pml_size + 64/resolution
cell_size = mp.Vector3(Sx, Sy, Sz)

pml_layers = [mp.PML(pml_size, direction = mp.Z), 
              mp.Absorber(abs_size,direction=mp.X), 
              mp.Absorber(abs_size,direction=mp.Y)]

sources = [mp.Source(mp.ContinuousSource(0.3),mp.Ex,center = mp.Vector3())]

sim = mp.Simulation(cell_size = cell_size,
    boundary_layers = pml_layers,
    geometry = [],
    sources = sources,
    symmetries = [], 
    resolution=resolution,
    eps_averaging=False)

t_cnt = 1000
t0 = time.time()
sim.run(until = t_cnt * 0.5/resolution)
t1 = time.time()
print('Total time = ' + str(t1-t0) + ' s')



