####/****************************
#
# Code is adapted from fdtdz demo notebook 
# here https://colab.research.google.com/gist/jlu-spins/0f3c5459bd4386150ae30b17f7c6a5e3/welcome-to-fdtd-z.ipynb 
# (it's impossible to connect from SRR office)
#
#********************************/

import fdtdz_jax
import jax
import jax.numpy as jnp
import numpy as np
import matplotlib.pyplot as plt

import time

def ramped_sin(omega, width, delay, dt, tt):
  """Sine function with a gradual ramp, inspired by MEEP's continuous source.

  See https://meep.readthedocs.io/en/latest/FAQ/#why-doesnt-the-continuous-wave-cw-source-produce-an-exact-single-frequency-response

  """
  t = omega * np.arange(tt, dtype=np.float32)
  return ((1 + np.tanh(t / width - delay)) / 2) * np.sin(t)

def absorption_profiles(numcells, width, smoothness):
  """1D quadratic profile for adiabatic absorption boundary conditions."""
  center = (numcells - 1) / 2
  offset = np.array([[0], [0.5]], dtype=np.float32)
  pos = np.arange(numcells, dtype=np.float32) + offset
  pos = np.abs(pos - center) - center + width
  pos = np.clip(pos, a_min=0, a_max=None)
  return smoothness * np.power(pos, 2)
  
def cross_profiles(x, y):
  """Combine two 1D absorption profiles into a 2D profile."""
  return np.max(np.meshgrid(x, y, indexing='ij'), axis=0, keepdims=True)

def absorption_mask(xx, yy, width, smoothness):
  """Adiabatic absorption boundary condition in the x-y plane."""
  x = absorption_profiles(xx, width, smoothness)
  y = absorption_profiles(yy, width, smoothness)
  return np.concatenate([cross_profiles(x[0], y[1]), 
                         cross_profiles(x[1], y[0]), 
                         cross_profiles(x[1], y[1])])

def safe_div(x, y):
  return np.zeros_like(x) if y == 0 else x / y

def pml_sigma_values(pml_widths, zz, ln_R = 16.0, m = 4.0):
  """Conductivity values for PML boundary condition along the z-axis."""
  offset = np.array([[0], [0.5]], dtype=np.float32)
  z = np.arange(zz, dtype = np.float32) + offset
  z = np.stack([safe_div(pml_widths[0] - z, pml_widths[0]), 
                safe_div(z + 0.5 - zz + pml_widths[1], pml_widths[1])], axis=-1)
  z = np.max(np.clip(z, a_min=0, a_max=None), axis=-1)
  return ((m + 1) * ln_R * z**m).T

def simulate(xx, yy, tt, src_omega, src_width, src_delay, abs_width, abs_smoothness, pml_widths, use_reduced_precision):
  """Run a simple continuous-wave dipole-source simulation."""
  zz = (128 if use_reduced_precision else 64) - sum(pml_widths)
  epsilon = np.ones((3, xx, yy, zz), np.float32)                                                             
  dt = np.float32(0.5)                                                                                            
  source_field = np.zeros((2, 2, xx, yy, 1), np.float32)                                                        
  source_field[0, 0, xx // 2, yy // 2, 0] = 1
  source_waveform = np.zeros((tt, 2), np.float32)
  source_waveform[:, 0] = ramped_sin(src_omega, src_width, src_delay, dt, tt)
  source_position = (zz - sum(pml_widths)) // 2 + pml_widths[0]
  abs_mask = absorption_mask(xx, yy, abs_width, abs_smoothness)
  pml_kappa = np.ones((zz, 2), np.float32)            
  pml_sigma = pml_sigma_values(pml_widths, zz)
  pml_alpha = 0.05 * np.ones((zz, 2), np.float32)            
  output_steps = (tt - 1, tt, 1)                     
                                                      
  out = fdtdz_jax.fdtdz(                              
      epsilon,                                                                                               
      dt,                                             
      source_field,                                   
      source_waveform,                                
      source_position,                                
      abs_mask,                                
      pml_kappa,                                      
      pml_sigma,                                      
      pml_alpha,
      pml_widths,                                     
      output_steps,                                                                                          
      use_reduced_precision,                          
      # Hacking this in order to try to get something that works for almost
      # any GPU, higher GPUs should modify `launch_params` here to take full
      # advantage of possible performance -- see the `fdtdz()` docstring for
      # more detail.
      launch_params=((2, 4), (8, 8), 4, (8, 6))#((2, 4), (6, 6), 2, (6, 0)) if use_reduced_precision else ((2, 4), (4, 3), 2, (3, 7)),
  )

  ## // fdtdz_jax::_preset_launch_params() 
  # """Returns ``(block, grid, spacing, cc)`` parameters for ``device_kind``."""
  # if device_kind == "Quadro RTX 4000":
  #   return ((2, 4), (6, 6), 2, (7, 5))
  # elif device_kind == "Tesla T4":
  #   return ((2, 4), (8, 5), 2, (7, 5))
  # elif "V100" in device_kind:
  #   return ((2, 4), (10, 8), 2, (7, 0))
  # elif "A100" in device_kind:
  #   return ((2, 4), (12, 9), 4, (8, 0))


  return out

def simulate_and_plot(use_reduced_precision=False):#True): 
  out = simulate(
      xx=500,
      yy=500,
      tt=10000,
      src_omega=0.3,
      src_width=3,
      src_delay=4,
      abs_width=20,
      abs_smoothness=1e-2,
      pml_widths=(10, 10),
      use_reduced_precision=use_reduced_precision,
      )

  plt.figure(figsize=(20, 20))
  plt.imshow(out[0, 0, :, :, 54 if use_reduced_precision else 22],
             vmin=-1e-3, vmax=1e-3, cmap="bwr")
  plt.xlabel("y")
  plt.ylabel("x")

  return out

#
# NOTE: If you happen to be on a Telsa K80 or older GPU that does not support
# reduced precision instructions (compute capability < 6.0, see 
# https://developer.nvidia.com/cuda-gpus) you will have to use 
# `simulate_and_plot(use_reduced_precision=False)`. This runs a smaller
# simulation that uses single-precision (fp32) fields internally.
#

t0 = time.time()
out = simulate_and_plot()
t1 = time.time()
print('Total time = ' + str(t1-t0) + ' s')
#np.save('out.npy',out)

#   grid   
## (4,3) -> 23.27 s
## (8,8) -> 6.5 s