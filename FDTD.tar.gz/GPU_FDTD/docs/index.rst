*fdtd-z* API documentation
==========================


.. autofunction:: fdtdz_jax.fdtdz
